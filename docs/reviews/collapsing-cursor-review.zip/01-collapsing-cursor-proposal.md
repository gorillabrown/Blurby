# BUG-151: Collapsing Narration Cursor

## Context

The narration cursor is a 300px fixed-width band that lerps between word positions. Despite the 350ms lag ceiling, it feels disconnected from the reading experience — it's a floating rectangle that doesn't visually communicate reading progress within a line.

The user wants a **collapsing cursor**: a band anchored to the right edge of the current text line, with its left edge advancing rightward at narration speed. The band shrinks as narration progresses through the line, reaching zero width when the line completes, then snaps to full-width on the next line.

This creates an intuitive "remaining text on this line" indicator that naturally communicates progress.

## Design

**Visual behavior:**
- Right edge: always fixed at the right edge of the current text line
- Left edge: tracks the currently-spoken word's X position (smooth lerp between words)
- Width: `columnRightEdge - leftEdge` (shrinks left-to-right as narration advances)
- On line completion (width → 0): instant snap to next line at full width
- Height: one line height (already measured by `narrationBandLineHeightRef`)

**Example on a 500px-wide column:**
```
Line start:  [████████████████████████████████████████] 500px wide
Mid-line:                    [██████████████████████████] 300px wide
Near end:                                    [██████████] 100px wide
Line done → snap to next line: [████████████████████████████████████████] 500px
```

## Files to modify

### 1. `src/components/FoliatePageView.tsx`

**Add ref for column right edge (~line 458):**
```
narrationColRightXRef = useRef<number>(0)
```

**Update `measureNarrationBandDimensions` (~line 490):**
- Measure the right edge of the first `<p>` element's bounding rect (relative to container)
- Store in `narrationColRightXRef`
- Already measures line height — keep that

**Update `positionNarrationOverlay` (~line 873):**
- Seed: `x = currentWindow.x`, `width = colRight - currentWindow.x`
- If word is on a new line vs. seed, compute fresh `width = colRight - wordX`
- Start the glide loop as before

**Update `ensureAudioProgressGlideLoop` (~line 622):**
- On word change (re-measure): store `from.x` = current word X, `to.x` = next word X
- On each tick: `leftEdge = lerp(from.x, to.x, fraction)`, `width = colRight - leftEdge`
- Detect line change: if `from.y !== to.y`, snap to next line with full width (`x = colLeft, width = colRight - colLeft`)
- Set overlay: `translate3d(leftEdge, y, 0)`, `width = computed`

**Update `ensureNarrationOverlayLoop` (~line 552):**
- Same pattern as audio loop: lerp left edge, compute width from colRight

**Update `applyVisualHighlightByIndex` narration path (~line 808):**
- No structural change — still calls `positionNarrationOverlay` on first entry, truth-sync on subsequent

### 2. `src/styles/global.css`

**Update `.foliate-narration-highlight` (~line 3832):**
- Change gradient direction: strong on left (reading position) → fading right (remaining text)
- Keep border-bottom accent line
- Potentially adjust `transform-origin` to `right top` for natural shrink feel

### 3. `src/constants.ts`

- Remove or repurpose `NARRATION_BAND_PAD_PX` (no longer a fixed width)

### What stays the same

- `audioScheduler.ts` — untouched. 350ms lag ceiling intact.
- `onWordAdvance` callback chain — still fires, still drives word-by-word overlay updates
- `measureNarrationWindow` — still used to get per-word X/Y positions
- `narrationBandLineHeightRef` — still measured once for band height
- `getAudioProgress` — still polled by the audio glide loop for smooth fraction-based interpolation
- Justified text injection in `injectStyles`

## Column right edge measurement

In `measureNarrationBandDimensions`, after finding the first `<p>`:
```
const pRect = firstP.getBoundingClientRect();
const frameRect = frame.getBoundingClientRect();
const containerRect = container.getBoundingClientRect();
narrationColRightXRef.current = frameRect.left + pRect.right - containerRect.left;
```

This gives the right edge of the justified text column in container-relative coordinates — the fixed anchor point for the overlay's right side.

## Verification

1. `npm test` — all 1593 tests pass
2. `npm run dev` — open a justified-text book, start narration
3. Verify: overlay starts full-width on the current line, right edge at column edge
4. Verify: left edge advances smoothly rightward as words are spoken
5. Verify: overlay width decreases smoothly as narration progresses through the line
6. Verify: when a line completes, overlay snaps to full-width on the next line
7. Verify: two-column layout — overlay stays within the correct column
8. Verify: pause/resume — overlay holds position on pause, resumes movement on resume
9. Verify: speed change — left edge speed adjusts when TTS rate changes
