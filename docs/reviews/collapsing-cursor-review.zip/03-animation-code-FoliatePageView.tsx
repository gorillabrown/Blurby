/*
 * SOURCE: src/components/FoliatePageView.tsx
 *
 * Five key functions extracted for review. Line numbers are from the current main branch.
 * These are the functions the collapsing-cursor proposal modifies.
 *
 * Functions included:
 *   1. measureNarrationBandDimensions  (lines 490-518)
 *   2. ensureNarrationOverlayLoop      (lines 552-603)
 *   3. ensureAudioProgressGlideLoop    (lines 622-769)
 *   4. measureNarrationWindow          (lines 824-869)
 *   5. positionNarrationOverlay        (lines 873-949)
 */


// ── 1. measureNarrationBandDimensions (lines 490-518) ────────────────────────
// Called once at narration start. Measures line-height and content width.
// PROPOSAL CHANGE: also measure and store the column's right edge X coordinate.

  const measureNarrationBandDimensions = useCallback(() => {
    const view = viewRef.current;
    if (!view?.renderer) return;
    const contents: Array<{ doc: Document; index: number }> = view.renderer.getContents?.() ?? [];
    if (contents.length === 0) return;
    const doc = contents[0].doc;
    if (!doc) return;

    // Get line-height from the first paragraph or word span available
    const textEl = (doc.querySelector("p, span[data-word-index]")) as HTMLElement | null;
    let lineHeight = 24; // safe fallback
    if (textEl) {
      const computed = doc.defaultView?.getComputedStyle(textEl);
      if (computed) {
        const lhRaw = parseFloat(computed.lineHeight);
        const fsRaw = parseFloat(computed.fontSize);
        lineHeight = isNaN(lhRaw) ? (isNaN(fsRaw) ? 24 : fsRaw * 1.5) : lhRaw;
      }
    }

    // Get content area width from the container (visible reading area), NOT the iframe
    // body which returns the full paginated content width in Foliate's column layout.
    const container = containerRef.current;
    const containerRect = container?.getBoundingClientRect?.();
    const contentWidth = containerRect && containerRect.width > 0 ? containerRect.width : 600;

    narrationBandLineHeightRef.current = lineHeight + 4; // small vertical padding
    narrationBandWidthRef.current = contentWidth;
  }, []);


// ── 2. ensureNarrationOverlayLoop (lines 552-603) ────────────────────────────
// Fallback RAF loop used when audio-progress is unavailable (Web Speech / paused).
// Lerps from current position to target position over the estimated word interval.
// PROPOSAL CHANGE: lerp left edge X, compute width = colRight - leftEdge each tick.

  const ensureNarrationOverlayLoop = useCallback(() => {
    if (narrationOverlayRafRef.current) return;

    const tick = (ts: number) => {
      const overlay = highlightRef.current;
      const target = narrationOverlayTargetRef.current;
      const current = narrationOverlayCurrentRef.current;
      if (!overlay || !target.active) {
        narrationOverlayRafRef.current = 0;
        return;
      }
      const from = narrationOverlaySegmentFromRef.current;
      const duration = Math.max(1, narrationOverlaySegmentDurationRef.current);
      const progress = Math.min(1, (ts - narrationOverlaySegmentStartRef.current) / duration);

      if (!current.ready) {
        current.x = from.x;
        current.y = from.y;
        current.width = from.width;
        current.height = from.height;
        current.ready = true;
      }

      // BUG-151: Use per-word x/width from the 3-word measurement window.
      const fixedHeight = narrationBandLineHeightRef.current > 0 ? narrationBandLineHeightRef.current : Math.min(Math.max(12, from.height), 40);
      const lerp = (fromValue: number, toValue: number) => fromValue + (toValue - fromValue) * progress;
      // BUG-151: Silky glide — lerp X and Y. Width stays fixed at 300px.
      current.x = lerp(from.x, target.x);
      current.y = lerp(from.y, target.y);
      current.width = from.width;
      current.height = fixedHeight;

      overlay.style.transform = `translate3d(${current.x}px, ${current.y}px, 0)`;
      overlay.style.width = `${current.width}px`;
      overlay.style.height = `${fixedHeight}px`;
      overlay.style.opacity = "1";
      overlay.style.display = "block";

      if (progress < 1) {
        narrationOverlayRafRef.current = requestAnimationFrame(tick);
      } else {
        // Snap to target on completion
        current.x = target.x;
        current.y = target.y;
        current.width = target.width;
        current.height = fixedHeight;
        narrationOverlayRafRef.current = 0;
      }
    };

    narrationOverlayRafRef.current = requestAnimationFrame(tick);
  }, []);


// ── 3. ensureAudioProgressGlideLoop (lines 622-769) ──────────────────────────
// Primary RAF loop. Polls getAudioProgress() every frame to get {wordIndex, fraction}.
// Re-measures DOM word positions when wordIndex changes, then lerps X/Y each frame.
// PROPOSAL CHANGE: lerp left edge, compute width = colRight - leftEdge.
//                  On line change (from.y !== to.y): snap to full-width at next line.

  const ensureAudioProgressGlideLoop = useCallback(() => {
    if (narrationAudioProgressRafRef.current) return;

    const tick = () => {
      const overlay = highlightRef.current;
      const getProgress = getAudioProgressRef.current;

      // If no audio progress source, stop the loop — fall back to estimate loop
      if (!overlay || !getProgress) {
        narrationAudioProgressRafRef.current = 0;
        return;
      }

      const report = getProgress();
      if (!report) {
        // Not playing (paused, ended, or Web Speech) — let the loop die naturally.
        // The estimate-based loop will hold the band at its last position.
        narrationAudioProgressRafRef.current = 0;
        return;
      }

      const { wordIndex, fraction } = report;

      // Only re-measure DOM positions when the word changes (not every frame).
      if (wordIndex !== narrationGlideWordRef.current) {
        const view = viewRef.current;
        if (!view?.renderer) {
          narrationAudioProgressRafRef.current = requestAnimationFrame(tick);
          return;
        }

        // Find the document containing the current word
        const contents: Array<{ doc: Document; index: number }> = view.renderer.getContents?.() ?? [];
        let foundDoc: Document | null = null;
        for (const { doc: d } of contents) {
          try {
            if (d?.querySelector?.(`[data-word-index="${wordIndex}"]`)) {
              foundDoc = d;
              break;
            }
          } catch { /* */ }
        }

        if (!foundDoc) {
          narrationAudioProgressRafRef.current = requestAnimationFrame(tick);
          return;
        }

        const measureFn = measureNarrationWindowRef.current;
        if (!measureFn) {
          narrationAudioProgressRafRef.current = requestAnimationFrame(tick);
          return;
        }
        const fromWindow = measureFn(foundDoc, wordIndex);
        if (!fromWindow) {
          narrationAudioProgressRafRef.current = requestAnimationFrame(tick);
          return;
        }

        // Measure next word position — only used for Y-position line detection
        const nextWindow = measureFn(foundDoc, wordIndex + 1);
        const sameLineTolerance = Math.max(8, fromWindow.height * 0.6);
        const staysOnSameLine = nextWindow != null && Math.abs(nextWindow.y - fromWindow.y) <= sameLineTolerance;
        const movesForward = nextWindow != null && nextWindow.x >= fromWindow.x - 4;
        const usableNextWindow = (staysOnSameLine && movesForward) ? nextWindow : null;
        const rail = narrationLineRailRef.current;

        const sameRailLine =
          rail.active &&
          Math.abs(rail.y - fromWindow.y) <= sameLineTolerance;

        // TTS-7R (BUG-145a): Use fixed band dimensions — width and height are constant.
        // BUG-151: Fixed 300px band, word at left edge. Width never changes.
        const fixedHeight = narrationBandLineHeightRef.current > 0 ? narrationBandLineHeightRef.current : Math.min(fromWindow.height, 40);
        const stableY = sameRailLine ? rail.y : fromWindow.y;

        const stableFrom = {
          x: fromWindow.x,
          y: stableY,
          width: NARRATION_BAND_PAD_PX,
          height: fixedHeight,
        };

        const toY = usableNextWindow ? (Math.abs(usableNextWindow.y - fromWindow.y) <= sameLineTolerance ? stableY : usableNextWindow.y) : stableY;
        const toX = usableNextWindow ? usableNextWindow.x : fromWindow.x;
        const stableTo = {
          x: toX,
          y: toY,
          width: NARRATION_BAND_PAD_PX,
          height: fixedHeight,
        };

        narrationLineRailRef.current = {
          y: stableY,
          height: fixedHeight,
          width: NARRATION_BAND_PAD_PX,
          avgStep: sameRailLine ? rail.avgStep : 0,
          active: true,
        };

        narrationGlideFromRef.current = stableFrom;
        narrationGlideToRef.current = stableTo;
        narrationGlideWordRef.current = wordIndex;

        // TTS-7Q: Diagnostics — log when audio cursor diverges from visual word
        if (import.meta.env.DEV) {
          const prevVisual = narrationDiagLastVisualWordRef.current;
          const prevAudio = narrationDiagLastAudioWordRef.current;
          if (prevVisual >= 0 && prevAudio >= 0 && Math.abs(wordIndex - prevVisual) > 2) {
            console.debug(
              `[TTS-7Q] audio/visual drift: audio=${wordIndex} visual=${prevVisual} delta=${wordIndex - prevVisual}`
            );
          }
          narrationDiagLastAudioWordRef.current = wordIndex;
          narrationDiagLastVisualWordRef.current = wordIndex;
        }
      }

      // TTS-7R (BUG-145a): Fixed-size band — only lerp Y for line transitions.
      // X is always 0, width and height are always the fixed measured values.
      const from = narrationGlideFromRef.current;
      const to = narrationGlideToRef.current;
      if (!from || !to) {
        narrationAudioProgressRafRef.current = requestAnimationFrame(tick);
        return;
      }

      const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
      // BUG-151: Silky glide — lerp both X and Y. The 350ms lag ceiling in
      // audioScheduler ensures fraction never outpaces the spoken word.
      const x = lerp(from.x, to.x, fraction);
      const y = lerp(from.y, to.y, fraction);
      const width = from.width;
      const height = narrationBandLineHeightRef.current > 0 ? narrationBandLineHeightRef.current : Math.max(12, from.height);

      narrationOverlayCurrentRef.current = { x, y, width, height, ready: true };

      overlay.style.transform = `translate3d(${x}px, ${y}px, 0)`;
      overlay.style.width = `${width}px`;
      overlay.style.height = `${height}px`;
      overlay.style.opacity = "1";
      overlay.style.display = "block";

      narrationAudioProgressRafRef.current = requestAnimationFrame(tick);
    };

    narrationAudioProgressRafRef.current = requestAnimationFrame(tick);
  }, []); // No deps — uses refs only (measureNarrationWindowRef, getAudioProgressRef, etc.)


// ── 4. measureNarrationWindow (lines 824-869) ─────────────────────────────────
// Given a word index, returns its container-relative {x, y, width, height, wordWidth}.
// The 3-word window logic gathers sibling words on the same line for a wider bounding box.
// PROPOSAL: this function is unchanged — its `x` output becomes the left edge anchor.

  const measureNarrationWindow = useCallback((doc: Document | null, wordIndex: number) => {
    const container = containerRef.current;
    if (!container || !doc) return null;
    const frame = doc.defaultView?.frameElement as HTMLElement | null;
    if (!frame) return null;

    const containerRect = container.getBoundingClientRect();
    const frameRect = frame.getBoundingClientRect();
    const primaryEls = Array.from(doc.querySelectorAll(`[data-word-index="${wordIndex}"]`)) as HTMLElement[];
    if (primaryEls.length === 0) return null;

    const primaryRects = primaryEls
      .map((el) => el.getBoundingClientRect())
      .filter((rect) => rect.width > 0 && rect.height > 0);
    const primaryTop = primaryRects[0]?.top;
    if (primaryRects.length === 0 || primaryTop == null) return null;

    const lineTolerance = Math.max(primaryRects[0].height * 0.65, 10);
    const allRects: DOMRect[] = [];
    for (let offset = 0; offset <= 2; offset++) {
      const els = Array.from(doc.querySelectorAll(`[data-word-index="${wordIndex + offset}"]`)) as HTMLElement[];
      for (const el of els) {
        const rect = el.getBoundingClientRect();
        if (rect.width <= 0 || rect.height <= 0) continue;
        if (Math.abs(rect.top - primaryTop) > lineTolerance) continue;
        allRects.push(rect);
      }
    }
    if (allRects.length === 0) return null;

    const minLeft = Math.min(...allRects.map((rect) => rect.left));
    const minTop = Math.min(...allRects.map((rect) => rect.top));
    const maxRight = Math.max(...allRects.map((rect) => rect.right));
    const maxBottom = Math.max(...allRects.map((rect) => rect.bottom));
    const horizontalPad = 8;
    const verticalPad = 2;
    // BUG-151: wordWidth = primary word only (for band = wordWidth + NARRATION_BAND_PAD_PX)
    const primaryWidth = primaryRects[0].right - primaryRects[0].left;
    return {
      x: frameRect.left + minLeft - containerRect.left - horizontalPad,
      y: frameRect.top + minTop - containerRect.top - verticalPad,
      width: Math.max(16, maxRight - minLeft + horizontalPad * 2),
      height: Math.max(12, maxBottom - minTop + verticalPad * 2),
      wordWidth: primaryWidth,
    };
  }, []);
  // TTS-7Q: Keep the forward-ref in sync so the audio-progress loop can call it
  measureNarrationWindowRef.current = measureNarrationWindow;


// ── 5. positionNarrationOverlay (lines 873-949) ───────────────────────────────
// Entry point called on each word advance (truth-sync path or first-word seed).
// Sets up the initial overlay position and starts the appropriate RAF loop.
// PROPOSAL CHANGE: seed width = colRight - wordX (not NARRATION_BAND_PAD_PX).

  const positionNarrationOverlay = useCallback((doc: Document | null, wordIndex: number) => {
    const overlay = highlightRef.current;
    if (!overlay || !doc) {
      hideNarrationOverlay();
      return;
    }

    const currentWindow = measureNarrationWindow(doc, wordIndex);
    if (!currentWindow) {
      hideNarrationOverlay();
      return;
    }

    // TTS-7Q: Diagnostics — track truth-sync corrections
    if (import.meta.env.DEV) {
      const prevVisual = narrationDiagLastVisualWordRef.current;
      if (prevVisual >= 0 && Math.abs(wordIndex - prevVisual) > 3) {
        narrationDiagTruthSyncCountRef.current++;
        console.debug(
          `[TTS-7Q] truth-sync correction #${narrationDiagTruthSyncCountRef.current}: ` +
          `visual jumped from ${prevVisual} to ${wordIndex} (delta=${wordIndex - prevVisual})`
        );
      }
      narrationDiagLastVisualWordRef.current = wordIndex;
    }

    // BUG-151: Fixed 300px band, focus word at the left edge.
    const fixedHeight = narrationBandLineHeightRef.current > 0 ? narrationBandLineHeightRef.current : Math.min(currentWindow.height, 40);
    const bandX = currentWindow.x;
    const seedWindow = { x: bandX, y: currentWindow.y, width: NARRATION_BAND_PAD_PX, height: fixedHeight };

    // TTS-7Q: If audio-progress is available, start the audio-clock glide loop.
    if (getAudioProgressRef.current) {
      narrationGlideWordRef.current = -1;
      narrationOverlayCurrentRef.current = { ...seedWindow, ready: true };
      overlay.style.transform = `translate3d(${bandX}px, ${currentWindow.y}px, 0)`;
      overlay.style.width = `${NARRATION_BAND_PAD_PX}px`;
      overlay.style.height = `${fixedHeight}px`;
      overlay.style.opacity = "1";
      overlay.style.display = "block";
      // Also update the context-word highlights (3-word window) via the estimate-loop target
      // so truth-sync keeps them accurate even when the audio loop drives the band.
      narrationOverlayTargetRef.current = { ...seedWindow, active: true };
      ensureAudioProgressGlideLoop();
      return;
    }

    // Fallback (no audio progress — Web Speech or paused): wall-clock estimate loop.
    const nextWindow = measureNarrationWindow(doc, wordIndex + 1) || currentWindow;
    const sameLineTolerance = Math.max(8, currentWindow.height * 0.6);
    const staysOnSameLine = Math.abs(nextWindow.y - currentWindow.y) <= sameLineTolerance;
    const targetY = staysOnSameLine ? currentWindow.y : nextWindow.y;
    const targetX = staysOnSameLine ? bandX : nextWindow.x;
    const targetWindow = { x: targetX, y: targetY, width: NARRATION_BAND_PAD_PX, height: fixedHeight };

    const now = performance.now();
    const previousAdvance = narrationOverlayLastAdvanceRef.current;
    const observedInterval = previousAdvance > 0 ? Math.max(70, Math.min(now - previousAdvance, 420)) : 180;
    const smoothedInterval = previousAdvance > 0
      ? narrationOverlayAverageDurationRef.current * 0.65 + observedInterval * 0.35
      : observedInterval;
    narrationOverlayAverageDurationRef.current = smoothedInterval;
    narrationOverlayLastAdvanceRef.current = now;

    narrationOverlayCurrentRef.current = { ...seedWindow, ready: true };
    narrationOverlaySegmentFromRef.current = { ...seedWindow };
    narrationOverlayTargetRef.current = { ...targetWindow, active: true };
    narrationOverlaySegmentStartRef.current = now;
    narrationOverlaySegmentDurationRef.current = smoothedInterval;

    overlay.style.display = "block";
    overlay.style.opacity = "1";
    overlay.style.transform = `translate3d(${bandX}px, ${currentWindow.y}px, 0)`;
    overlay.style.width = `${NARRATION_BAND_PAD_PX}px`;
    overlay.style.height = `${fixedHeight}px`;
    ensureNarrationOverlayLoop();
  }, [ensureNarrationOverlayLoop, ensureAudioProgressGlideLoop, hideNarrationOverlay, measureNarrationWindow]);
