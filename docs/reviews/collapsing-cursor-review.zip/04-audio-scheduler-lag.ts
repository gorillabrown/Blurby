/*
 * SOURCE: src/utils/audioScheduler.ts
 *
 * Two extracts relevant to the collapsing-cursor proposal:
 *
 *   A. startWordTimer() — lines 245-300
 *      The word-boundary ticker. Applies NARRATION_CURSOR_LAG_MS as a hard ceiling
 *      so the visual cursor cannot outpace the spoken audio. This function is
 *      UNCHANGED by the proposal — the lag ceiling must remain intact.
 *
 *   B. getAudioProgress() — lines 460-503 (comment block) + 474-503 (function)
 *      Computes continuous {wordIndex, fraction} from AudioContext.currentTime.
 *      The proposal's audio glide loop polls this every RAF frame to drive the
 *      left-edge interpolation. Also UNCHANGED by the proposal.
 */


// ── A. startWordTimer (lines 245-300) ────────────────────────────────────────

  function startWordTimer(): void {
    clearWordTimer();
    if (!callbacks || !audioCtx || currentWordBoundaries.length === 0) return;

    // BUG-151: Lag offset — the cursor clock runs behind the audio clock by this
    // amount so the visual cursor never outpaces the actual spoken word.
    const cursorLagSec = NARRATION_CURSOR_LAG_MS / 1000;

    function tick(): void {
      if (stopped || !callbacks || !audioCtx) return;
      const now = audioCtx.currentTime;

      // Don't process boundaries until audio has actually started playing
      if (playbackStartTime !== null && now < playbackStartTime) {
        wordRafHandle = requestAnimationFrame(tick);
        return;
      }

      // BUG-151: Use lagged time for boundary comparison — cursor must not
      // exceed audioTime - cursorLagSec. This is the hard ceiling.
      const cursorNow = now - cursorLagSec;

      // Advance past ALL boundaries we've crossed in this tick.
      let advancedAny = false;
      while (nextWordBoundaryIdx < currentWordBoundaries.length &&
             currentWordBoundaries[nextWordBoundaryIdx].time <= cursorNow) {
        const advancedWordIndex = currentWordBoundaries[nextWordBoundaryIdx].wordIndex;
        callbacks.onWordAdvance(advancedWordIndex);
        advancedAny = true;
        nextWordBoundaryIdx++;

        truthSyncCounter++;
        if (truthSyncCounter >= truthSyncInterval) {
          truthSyncCounter = 0;
          callbacks.onTruthSync?.(advancedWordIndex);
        }
      }
      if (advancedAny) {
        // Sliding window: prune consumed boundaries to prevent unbounded growth
        if (nextWordBoundaryIdx >= 100) {
          currentWordBoundaries = currentWordBoundaries.slice(nextWordBoundaryIdx);
          nextWordBoundaryIdx = 0;
        }
      }

      // Keep polling on animation frames while boundaries remain. This is
      // smoother under renderer load than setTimeout-based wakeups and lets
      // AudioContext.currentTime remain the single source of truth.
      if (nextWordBoundaryIdx < currentWordBoundaries.length) {
        wordRafHandle = requestAnimationFrame(tick);
      }
    }

    wordRafHandle = requestAnimationFrame(tick);
  }


// ── B. getAudioProgress (lines 460-503) ──────────────────────────────────────
/*
   * TTS-7Q: Compute continuous audio progress from AudioContext.currentTime.
   *
   * Looks up the current and next word boundaries in the pre-computed timeline to
   * produce a fractional position [0.0, 1.0) within the current word interval.
   * This gives callers a continuous progress rail without any new DOM work or state.
   *
   * Returns null when:
   * - Not playing / no AudioContext
   * - No word boundaries have been scheduled yet
   * - Audio hasn't started (before playbackStartTime)
   *
   * The returned wordIndex is the CANONICAL audio cursor (scheduler-authoritative).
   * Visual band code must never write this back to pause/resume/save anchors.
   */
  function getAudioProgress(): AudioProgressReport | null {
    if (stopped || !audioCtx || currentWordBoundaries.length === 0) return null;
    if (playbackStartTime !== null && audioCtx.currentTime < playbackStartTime) return null;

    // BUG-151: Use lagged time — cursor must not exceed audioTime - lag.
    const cursorLagSec = NARRATION_CURSOR_LAG_MS / 1000;
    const now = Math.max(0, audioCtx.currentTime - cursorLagSec);
    // If lag pushes us before the first boundary, no progress to report yet
    if (currentWordBoundaries.length > 0 && now < currentWordBoundaries[0].time) return null;
    const boundaries = currentWordBoundaries;
    const total = boundaries.length;
    if (total === 0) return null;

    // Find the most recently crossed boundary (the word audio is currently speaking).
    // nextWordBoundaryIdx tracks the NEXT boundary not yet fired; so the current word
    // is at index (nextWordBoundaryIdx - 1), clamped to [0, total-1].
    const currentIdx = Math.max(0, Math.min(nextWordBoundaryIdx - 1, total - 1));
    const current = boundaries[currentIdx];

    // Compute fraction from current boundary start to next boundary start.
    const nextBoundary = currentIdx + 1 < total ? boundaries[currentIdx + 1] : null;
    let fraction = 0;
    if (nextBoundary) {
      const intervalSec = nextBoundary.time - current.time;
      if (intervalSec > 0) {
        fraction = Math.min(1, Math.max(0, (now - current.time) / intervalSec));
      }
    } else {
      // Last boundary — hold at 0 (no next word to interpolate toward)
      fraction = 0;
    }
  }
