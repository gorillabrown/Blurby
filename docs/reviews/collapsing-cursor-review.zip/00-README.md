# Collapsing Narration Cursor — Third-Party Review Package

**Prepared:** 2026-04-06
**Project:** Blurby (v1.39.0)
**Proposal:** BUG-151 Collapsing Narration Cursor

---

## What This Package Is

This package contains everything a third-party reviewer needs to evaluate the
collapsing narration cursor proposal for the Blurby EPUB reader app.

Blurby is an Electron + React 19 speed-reading app with a Kokoro TTS narration
mode. When narrating, it shows a highlight band over the current spoken word
inside a Foliate.js EPUB iframe. The proposal changes that band from a fixed
300px-wide rectangle to a dynamic width that shrinks left-to-right as the TTS
engine progresses through each line.

---

## Files in This Package

| File | Contents |
|------|----------|
| `01-collapsing-cursor-proposal.md` | The full design spec — what changes, where, and why |
| `02-current-overlay-css.css` | Current CSS for `.foliate-narration-highlight` (lines 3829-3851 of `global.css`) |
| `03-animation-code-FoliatePageView.tsx` | Five key animation functions extracted from `FoliatePageView.tsx` |
| `04-audio-scheduler-lag.ts` | Two extracts from `audioScheduler.ts` — the lag-ceiling ticker and `getAudioProgress()` |
| `05-narration-constants.ts` | All TTS/narration constants from `constants.ts`, with proposal annotations |
| `06-settings-types.ts` | `BlurbySettings` and `LayoutSpacing` interfaces from `types.ts` |

---

## Architecture Context

**Overlay rendering pipeline (current):**

```
AudioContext.currentTime
  └─ audioScheduler.startWordTimer()
       └─ NARRATION_CURSOR_LAG_MS = 350ms ceiling applied
            └─ onWordAdvance(wordIndex)
                 └─ FoliatePageView.positionNarrationOverlay()
                      ├─ measureNarrationWindow(doc, wordIndex) → {x, y, width, height}
                      └─ ensureAudioProgressGlideLoop()  [if Kokoro active]
                           └─ getAudioProgress() → {wordIndex, fraction}
                                └─ lerp(from.x, to.x, fraction)   ← RAF per frame
                                     └─ overlay.style.transform = translate3d(x, y, 0)
                                        overlay.style.width = NARRATION_BAND_PAD_PX (300px fixed)
```

**Overlay rendering pipeline (proposed):**

```
AudioContext.currentTime
  └─ [unchanged — lag ceiling intact]
       └─ onWordAdvance(wordIndex)
            └─ positionNarrationOverlay()
                 ├─ measureNarrationWindow(doc, wordIndex) → {x, y, ...}
                 ├─ narrationColRightXRef.current  ← measured once at start
                 └─ ensureAudioProgressGlideLoop()
                      └─ getAudioProgress() → {wordIndex, fraction}
                           └─ leftEdge = lerp(from.x, to.x, fraction)
                                └─ overlay.style.transform = translate3d(leftEdge, y, 0)
                                   overlay.style.width = colRight - leftEdge  ← dynamic!
```

---

## Key Technical Questions for the Reviewer

1. **Column right edge stability.** `narrationColRightXRef` is measured once at narration
   start from the first `<p>` element. Does this survive scroll/page-turn events within
   Foliate's column layout? What invalidation strategy is appropriate?

2. **Two-column layout.** In a two-column EPUB, each column has a different right edge.
   `measureNarrationBandDimensions` currently picks `contents[0].doc`. Is one measurement
   sufficient, or does the right edge need to be measured per-word from the word's
   containing document/column?

3. **CSS `transition` vs. JS width.** The current CSS has `transition: transform 80ms ease`.
   The proposal changes `width` every RAF frame. Should `will-change: width` be added?
   Should the CSS transition be removed from `width` to avoid fighting the JS animation?

4. **Line-completion detection.** The proposal detects line completion when `from.y !== to.y`
   and snaps to full width. This relies on `measureNarrationWindow` returning a Y that
   differs by more than `sameLineTolerance` (8px or 60% of line height). Is this robust
   for all font sizes and line heights?

5. **Gradient direction.** The current gradient is symmetric (soft on both edges). The
   proposal suggests inverting to strong-left / fade-right. What gradient best communicates
   "remaining text on this line" while remaining legible at all accent colors?

6. **`NARRATION_BAND_PAD_PX` removal.** This constant is currently used in 4 places inside
   `ensureAudioProgressGlideLoop` (stableFrom.width, stableTo.width, narrationLineRailRef.width)
   and in `positionNarrationOverlay` (seedWindow.width, overlay.style.width, targetWindow.width).
   All six must be replaced with the dynamic `colRight - leftEdge` calculation.

---

## Source File Locations (for reference)

All paths relative to the Blurby repo root:

- `src/components/FoliatePageView.tsx` — EPUB reader component + all narration overlay logic
- `src/styles/global.css` — All CSS (single file, ~4000 lines)
- `src/utils/audioScheduler.ts` — Kokoro audio scheduling + word boundary tracking
- `src/constants.ts` — All tunable constants (single source of truth)
- `src/types.ts` — TypeScript interfaces for settings, documents, etc.
