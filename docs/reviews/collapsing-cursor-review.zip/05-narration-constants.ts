/*
 * SOURCE: src/constants.ts — lines 60-113 (TTS and narration constants)
 *
 * REVIEWER NOTES:
 *
 *   NARRATION_BAND_PAD_PX = 300
 *     The proposal replaces this fixed-width constant with a computed value:
 *     width = narrationColRightXRef.current - leftEdge
 *     This constant will either be removed or repurposed (e.g., as a minimum
 *     band width guard) after the collapsing cursor is implemented.
 *
 *   NARRATION_CURSOR_LAG_MS = 350
 *     This constant is UNCHANGED by the proposal. It remains the hard ceiling
 *     that prevents the visual cursor from outpacing audio playback. The lag
 *     applies identically whether the band is fixed-width or collapsing.
 *
 *   All other TTS_* constants below are included for completeness — the proposal
 *   does not touch them.
 */

// ── TTS (Text-to-Speech) ──────────────────────────────────────────────────────
/** Number of words per TTS utterance chunk — larger = smoother speech, smaller = tighter cursor sync */
export const TTS_CHUNK_SIZE = 40;
/** Maximum TTS speech rate — capped at 1.5x for narration pipeline (NAR-2) */
export const TTS_MAX_RATE = 1.5;
/** Minimum TTS speech rate */
export const TTS_MIN_RATE = 0.5;
/** Baseline WPM that corresponds to TTS rate 1.0 */
export const TTS_RATE_BASELINE_WPM = 150;
/** Maximum WPM allowed when TTS narration is active */
export const TTS_WPM_CAP = 400;
/** Step size for TTS rate adjustment via Up/Down arrows */
export const TTS_RATE_STEP = 0.1;
/** Between-chunk rhythm pause: comma, semicolon endings.
 *  Kokoro audio already includes ~50-100ms natural trailing silence,
 *  so these values ADD to that — keep them short to avoid stacking. */
export const TTS_PAUSE_COMMA_MS = 100;
/** Between-chunk rhythm pause: clause endings (colon, closing parenthesis) */
export const TTS_PAUSE_CLAUSE_MS = 150;
/** Between-chunk rhythm pause: sentence endings (. ! ?) */
export const TTS_PAUSE_SENTENCE_MS = 400;
/** Between-chunk rhythm pause: paragraph boundaries (>2 sentences) */
export const TTS_PAUSE_PARAGRAPH_MS = 800;
/** Number of pre-generated audio chunks in the rolling queue */
export const TTS_QUEUE_DEPTH = 5;
/** TTS-7F: Target opening cache coverage in milliseconds (5 minutes of narration) */
export const ENTRY_COVERAGE_TARGET_MS = 300_000;
/** Paragraphs with this many or fewer sentences are treated as dialogue (minimal pause) */
export const TTS_DIALOGUE_SENTENCE_THRESHOLD = 2;
/** Footnote narration behavior */
export const TTS_FOOTNOTE_MODE = "skip" as const;

// ── TTS Pipeline (NAR-2) ─────────────────────────────────────────────────────
/** Chunk 1 word count — generates in ≤1s for fast cold start */
export const TTS_COLD_START_CHUNK_WORDS = 13;
/** Steady-state chunk size after ramp-up completes */
export const TTS_CRUISE_CHUNK_WORDS = 148;
/** Crossfade overlap at chunk boundaries — eliminates splice artifacts (ms) */
export const TTS_CROSSFADE_MS = 8;
/** TTS-7O: Cursor truth-sync interval — re-snap visual cursor to scheduler position every N words */
export const TTS_CURSOR_TRUTH_SYNC_INTERVAL = 12;
/** Forward pre-schedule target in words (~2 paragraphs of buffered audio) */
export const TTS_FORWARD_WORDS = 300;
/** TTS-7P: Rolling pause planner — words ahead of the current cursor to plan */
export const TTS_PLANNER_WINDOW_WORDS = 400;
/** TTS-7P: Rolling pause planner — minimum words per planned chunk (prohibits tiny fragments) */
export const TTS_PLANNER_MIN_CHUNK_WORDS = 10;
/** BUG-151: Fixed narration overlay band width in pixels
 *  PROPOSAL: This will be replaced by dynamic width = colRight - leftEdge */
export const NARRATION_BAND_PAD_PX = 300;
/** BUG-151: Cursor lag behind audio clock (ms). Compensates for heuristic word
 *  boundary timing — ensures the visual cursor never outpaces spoken audio.
 *  The word timer and getAudioProgress both use (audioTime - lag) as the
 *  effective clock, creating a hard ceiling the cursor cannot exceed.
 *  PROPOSAL: Unchanged — still 350ms. */
export const NARRATION_CURSOR_LAG_MS = 350;
