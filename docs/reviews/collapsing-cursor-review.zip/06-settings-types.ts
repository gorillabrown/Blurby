/*
 * SOURCE: src/types.ts
 *
 * Two types extracted for review:
 *
 *   LayoutSpacing — lines 105-109
 *     Controls line/character/word spacing in the EPUB reader.
 *     Included because justified text layout (settings.justifiedText) is
 *     a prerequisite for accurate column-right-edge measurement in the proposal.
 *
 *   BlurbySettings — lines 111-174 (full interface)
 *     Included so the reviewer can see all settings that affect the narration
 *     overlay: ttsEnabled, ttsEngine, ttsRate, justifiedText, layoutSpacing.
 *
 * The proposal adds no new fields to either type — column right edge is stored
 * in a React ref (narrationColRightXRef), not in persisted settings.
 */


// ── LayoutSpacing (lines 105-109) ────────────────────────────────────────────

export interface LayoutSpacing {
  line: number;
  character: number;
  word: number;
}


// ── BlurbySettings (lines 111-174) ───────────────────────────────────────────

export interface BlurbySettings {
  schemaVersion: number;
  wpm: number;
  sourceFolder: string | null;
  folderName: string;
  recentFolders: string[];
  theme: "dark" | "light" | "blurby" | "eink" | "system";
  launchAtLogin: boolean;
  focusTextSize: number;
  accentColor: string | null;
  fontFamily: string | null;
  compactMode: boolean;
  readingMode: "focus" | "flow" | "narration" | "page";
  focusMarks: boolean;
  readingRuler: boolean;
  focusSpan: number;
  flowTextSize: number;
  rhythmPauses: RhythmPauses;
  layoutSpacing: LayoutSpacing;
  justifiedText: boolean;     // force text-align: justify in EPUB reader (default true)
  initialPauseMs: number;     // pause before first word advances (default 3000)
  punctuationPauseMs: number; // extra dwell on punctuation words (default 1000)
  viewMode: "list" | "grid";
  // Flow mode settings
  flowWordSpan: number; // how many words to highlight at once in Flow mode (3-5, default 3)
  flowCursorStyle: "underline" | "highlight"; // flow cursor visual style (default: underline)
  // E-ink display optimization settings
  einkWpmCeiling: number;
  einkRefreshInterval: number;
  einkPhraseGrouping: boolean;
  // TTS settings
  ttsEnabled: boolean;
  ttsEngine: "web" | "kokoro"; // which TTS backend to use
  ttsVoiceName: string | null; // SpeechSynthesisVoice.name (web) or Kokoro voice ID
  ttsRate: number; // 0.5-2.0, default 1.0
  // TTS pause timing (user-adjustable via settings)
  ttsPauseCommaMs?: number;
  ttsPauseClauseMs?: number;
  ttsPauseSentenceMs?: number;
  ttsPauseParagraphMs?: number;
  ttsDialogueSentenceThreshold?: number;
  ttsFootnoteMode?: "skip" | "read";
  // Last-used reading mode (Space bar starts this mode from Page view)
  lastReadingMode: "focus" | "flow" | "narration";
  // Cloud sync settings
  syncIntervalMinutes: number;
  syncOnMeteredConnection: boolean;
  // Sprint 23: First-run onboarding
  firstRunCompleted?: boolean;
  // Sprint 25C: Library layout settings
  defaultSort?: string;
  defaultViewMode?: "grid" | "list";
  libraryCardSize?: "small" | "medium" | "large";
  libraryCardSpacing?: "compact" | "cozy" | "roomy";
  // TD-02: Import pipeline
  useLegacyRenderer?: boolean;   // opt-in for legacy word-by-word renderer
  // NAR-4: TTS cache settings
  ttsCacheEnabled?: boolean;     // background caching of Reading Now books (default true)
  // TTS-6E: Pronunciation overrides
  pronunciationOverrides?: PronunciationOverride[];
  // TTS-6L: Narration profiles
  narrationProfiles?: NarrationProfile[];
  activeNarrationProfileId?: string | null;  // null = use flat settings (no profile)
}
