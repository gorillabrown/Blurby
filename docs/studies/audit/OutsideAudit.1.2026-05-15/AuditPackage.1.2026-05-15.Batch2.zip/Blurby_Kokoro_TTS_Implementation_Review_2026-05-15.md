# Kokoro TTS Implementation Review — 2026-05-15

## Methodology

This review reads every line of the 17 TTS source files listed in the review prompt (Tiers 1-4, totaling ~7,200 lines) and evaluates implementation quality against the standard set by five independent findings documents covering nine external TTS/reader codebases. It is an **implementation-quality review**, not an architecture review — the findings already cover architecture. The question throughout is: does the actual code match the quality patterns demonstrated by abogen, readest, RealtimeTTS, sioyek, and others, and is it structured to absorb the seven remaining sprints?

**Final consolidation note:** this version reconciles the broad 6-agent implementation review with the branch-aware risk review. Where the two differed, this document separates **current functional adequacy** from **next-sprint fragility**. In particular, `useNarration` remains adequate as shipping orchestration, but fragile at the `TTS-EVENT-SYNC-1` boundary; the provider registry is solid as metadata, but incomplete as runtime dispatch infrastructure; and the pipeline is clean on cache-miss generation, but still needs cache-hit timing identity parity before event-sync should depend on it.

## Assumption Archaeology

| # | Assumption | Classification |
|---|-----------|----------------|
| A1 | Kokoro is the sole active engine; dormant engine code can be ignored for quality assessment | **Working assumption.** ENGINE-DORMANCY-1 hasn't shipped yet. Until it does, dormant code still loads, still has IPC handlers, and still consumes cognitive budget in useNarration. |
| A2 | The five findings documents represent the correct quality bar | **Verified truth.** They cover 9 codebases systematically and the adversarial review validated their strategic direction. |
| A3 | The audio pipeline is Blurby's strongest asset | **Verified truth.** Every findings doc praises it. The code confirms: generation ID guards at every await boundary, fail-closed timing validation, pre-scheduled gapless playback via Web Audio. |
| A4 | The normalizer's 12 transforms are sufficient for current needs | **Working assumption.** They cover English prose well. NORMALIZER-ENRICH-1 will add 9 more. The pipeline is extensible (3-touch pattern) but the current 12 miss currency-in-context (`$1.2 million`), heteronyms, and several patterns abogen handles at 2,378 lines of normalization. |
| A5 | The TTS-SYNC-1 and TTS-DIAG-1 branches will merge cleanly | **Working assumption.** Both passed full test suites on their branches, but they are not yet on `main`. The highlightSyncController and timingMetadataStore exist only on unmerged branches. |
| A6 | The untyped main-process JS files are safe because the renderer types enforce the contract | **Working assumption (risky).** There is no compile-time enforcement across the IPC boundary. The renderer declares TypeScript interfaces (`TtsCacheStructuredIdentity`, `TtsTimingSidecar`) but `tts-cache.js` operates on bare objects with minimal runtime validation. |
| A7 | Linear scans (O(n) section lookup, O(n) timing store queries) are acceptable at current scale | **Verified truth for now.** Books have hundreds of sections and narration produces dozens of chunks per session. But TTS-RENDER-MAP-1 will increase query frequency, and very long books could stress these paths. |
| A8 | Cache hits are equivalent to fresh generation for timing identity | **Unproven assumption.** `generationPipeline.ts` assigns `chunkId` and `timingTruth` to freshly generated chunks from cache identity (integration branch lines 506-511), but renderer-side `loadCachedChunk` currently returns audio, words, timestamps, and duration only (`src/utils/ttsCache.ts` lines 47-54). On the integration branch, scheduler metadata then falls back to `words:start-end` when `chunkId` is absent (`audioScheduler.ts` lines 580-589). Cache miss and cache hit can therefore describe the same chunk with different timing-record IDs unless `TTS-PIPELINE-1` rehydrates identity on read. |
| A9 | Normalizer transform extensibility implies alignment-map readiness | **False if taken literally.** Adding transforms is easy under the current `TransformFn = (text: string) => string` pattern (`segmentNormalizer.ts` line 48), but `TTS-EVENT-SYNC-1` / `TTS-RENDER-MAP-1` need `normalizedToOriginalMap`. Reliable alignment requires a transform-result contract, not just more string transforms. |

## Constraint Classification

| Constraint | Classification | Implication |
|-----------|---------------|-------------|
| Electron main process must stay CommonJS | **Genuine** (Electron limitation) | `tts-cache.js`, `tts-engine.js`, `tts-worker.js`, `ipc/tts.js` cannot use TypeScript without a build step for main. Type safety must come from runtime validation or JSDoc. |
| 7 sprints remain on the conveyor | **Genuine** (roadmap commitment) | No time for major refactors. All recommendations must fit within existing sprint scopes or be deferred. |
| kokoro-js is a patch-package fork | **Genuine** (LL-089) | Word timestamps depend on a patched duration tensor. Upstream changes could break the patch. 4-layer validation mitigates but doesn't eliminate this risk. |
| `useNarration` must remain a single hook | **Artificial** (convention, not requirement) | The hook is 1,784 lines with 33 refs and 5 strategy memos. It could be decomposed further, but the existing extraction (REFACTOR-1A pulled out 5 hooks) has already reduced the worst coupling. The remaining complexity is genuine orchestration logic. |
| The dual state channel (stateRef + dispatch) must be preserved | **Artificial but load-bearing** | This pattern exists because React's batched dispatch is async but narration callbacks need synchronous state reads. Removing it would require a fundamentally different state architecture (e.g., external store with synchronous reads). Not feasible within the remaining sprints. |
| Cache must support both v1 and v2 schemas | **Genuine** (backward compatibility) | Users have v1 cached audio. Destructive migration was explicitly rejected per LL-115. |

---

## Module Reviews

### 1. useNarration — The Orchestrator (1,784 lines)

#### What It Does Well

**Generation ID discipline (LL-031).** The `generationIdRef` pattern is applied consistently throughout. Every config change (rate, voice, engine) that could produce stale async results increments the generation ID before dispatching the change. Callbacks check `myGenId === generationIdRef.current` at every await boundary. This pattern is cited by LL-031 and LL-033 and the code follows both faithfully.

**Strategy isolation.** Five engine strategies (web, kokoro, qwen, nano, pocket-tts) are instantiated via `useMemo` with stable dependency arrays. Each strategy implements the `TtsStrategy` interface from `narration.ts`. The hook never reaches into strategy internals — it calls `speakChunk`, `stop`, `pause`, `resume` through the contract. This is cleaner than readest's `TTSController` which mixes orchestration with engine-specific SSML generation.

**Cleanup thoroughness.** The unmount effect (lines 1663-1673) stops all five strategies and clears ownership refs. Every `useEffect` that registers IPC listeners returns a cleanup function. Rate-change debounce timers are cleared on subsequent calls. No dangling listener or timer path was found.

**Resume anchor persistence (LL-073).** The `resumeAnchorRef` is cleared only by mode start or explicit user selection, never by passive events. This directly implements the lesson from BUG-135.

#### What the Findings Envision

All five findings documents recommend a richer `TTSProvider` interface with declarative capabilities, a `TTSProviderRegistry` that resolves providers by capability query, and strategy dispatch driven by registry metadata rather than `if (engine === "kokoro")` branches. The Compass review proposes a 14-method `TTSClient` interface inspired by readest. The deep-research report emphasizes `NarrationJob` with explicit `generationId` as a first-class type.

The adversarial review (BC-2, G2) correctly notes that the registry exists (`ttsProviderRegistry.ts`) but `useNarration` doesn't use it for dispatch — it still has manual engine-name branches in `startCursorDriven` (lines 1132-1278), `speakNextChunk` (lines 957-1095), `applyRateChange` (lines 1422-1500), and `pause`/`resume` (lines 1502-1622).

#### Implementation Gaps

**Dual state channel.** The `stateRef.current = { ...stateRef.current, ... }` pattern appears at ~25 locations throughout the file. Every reducer dispatch must be mirrored by a manual stateRef overwrite. If any path misses the overwrite, async callbacks read stale state. This is the most structurally fragile pattern in the codebase — it's not a bug today, but it's the highest-probability source of future narration state bugs.

**ERROR action nuclear option** (`narration.ts` line 180). Any error dispatched through the reducer sets `kokoroReady: false` AND `qwenReady: false` regardless of which engine caused the error. If a Nano error triggers ERROR, Kokoro loses its readiness status until the next `SYNC_KOKORO_STATUS` event. This is overly aggressive for a multi-engine system, though with Kokoro as the sole active engine the blast radius is currently limited.

**Registry/runtime dormancy mismatch.** The provider registry marks MOSS-Nano and Pocket TTS as `selectable: true` (lines 94-151 of `ttsProviderRegistry.ts`), but the runtime gates Nano behind `experimentalNano` (line 493 of `useNarration.ts`) and Pocket TTS has no gate at all. If the settings UI reads selectability from the registry, these dormant engines could appear selectable when no runtime path can use them.

**NarrationState name collision.** The hook exports `NarrationState` (lines 38-52) as a UI-facing projection, while `types/narration.ts` exports a different `NarrationState` (lines 48-63) as the reducer state machine. The hook imports the reducer's version as `ReducerState` (line 7) but never uses that alias. Two exported interfaces with the same name but different shapes invites misuse by downstream consumers.

**Qwen retirement is code-incomplete.** Despite being `selectable: false` in the registry, all Qwen runtime code paths remain: status monitoring (lines 550-573), streaming probe (lines 577-584), warming path (lines 1158-1234), chunk dispatch (lines 1070-1079), pause/resume branches, and rate-change handling. This is approximately 200 lines of actively maintained dead code that ENGINE-DORMANCY-1 will address.

#### Stabilization Debt

- **Legacy `speak` function** (lines 1098-1122): Uses raw `SpeechSynthesisUtterance` directly, bypassing the strategy/reducer pattern. Reads `state.speed` from render-time state rather than stateRef, which can be stale in async context.
- **Qwen streaming probe is one-shot** (lines 577-584): `qwenStreamingReadyRef` is set once on mount and never updated. If the streaming sidecar becomes available after mount, the non-streaming strategy is used permanently.
- **Generation ownership duplication**: Nano (lines 333-347) and Pocket TTS (lines 349-362) have identical ownership/generation patterns that could be extracted into a shared helper.
- **Silent `.catch(() => {})` on status probes** (lines 526, 554, 613): Violates LL-066's zero-tolerance stance on bare catches, though these are mount-time probes where failure is expected during engine unavailability.

#### Sprint Impact

**TTS-EVENT-SYNC-1** must refactor the RAF→event transition inside this file. The `onTruthSync` callback (currently wired through scheduler callbacks at line 277 patterns) needs promotion to primary highlight trigger. The dual state channel makes this refactor higher-risk — any new callback that reads state must correctly use `stateRef.current`, not the reducer snapshot. The Phase 0 gate (baseline latency measurement) added by the adversarial review remediation mitigates this by ensuring the RAF path is preserved as fallback.

**ENGINE-DORMANCY-1** will remove ~200 lines of dormant engine code from this file, improving readability and reducing the cognitive surface for subsequent sprints.

#### Verdict: ADEQUATE

The orchestrator is large but well-structured for what it does. The generation ID discipline is exemplary. The dual state channel is architectural debt that's too expensive to fix within the remaining sprints, but it's a known pattern that works correctly today. The dormant engine code inflates the file but will be addressed by ENGINE-DORMANCY-1. No blocking issue exists for the conveyor, but the correct operational label is **functionally adequate, structurally fragile at the event-sync boundary**. `TTS-EVENT-SYNC-1` should be dispatched only after `ENGINE-DORMANCY-1` and `TTS-INTEGRATE-1` remove stale branch assumptions and reduce dispatch surface.

---

### 2. Audio Pipeline (generationPipeline + audioScheduler + narrationPlanner + kokoroStrategy)

#### What It Does Well

**Generation ID guards are airtight.** `generationPipeline.ts` captures `myGenId` at line 265 and checks `active && myGenId === generationId` at every async boundary (lines 335, 401, 426-428, 436, 440-441, 508, 527, 573, 582, 591, 599, 602). No stale result can escape. The `schedulerEpoch` in `audioScheduler.ts` (line 191) provides the same guarantee on the playback side. This exceeds every external codebase reviewed — RealtimeTTS has no equivalent guard.

**Word timing validation is defense-in-depth.** `audioScheduler.ts` `validateWordTimestamps` (lines 319-345) checks: array length matches word count, all values finite and non-negative, endTime >= startTime, monotonic startTimes, word string matches, overshoot tolerance (min 40ms or 5% of duration), and zero-duration word threshold (>20% with >2 zeros). Only timestamps that pass all checks are marked `isTrustedWordTiming: true`. This is more thorough than any validation found in the external codebases.

**Pre-scheduled gapless playback.** The scheduler uses `source.start(chunkStartTime)` (line 575) to schedule chunks at precise future times on the Web Audio timeline. Crossfade overlap is achieved by starting the next chunk at `boundaryTime = endTime - crossfadeSec` (line 578). Both chunks play simultaneously during the crossfade window. This is architecturally superior to readest's approach of creating a new `HTMLAudioElement` per sentence (Issue #1777).

**The planner is clean functional code.** `narrationPlanner.ts` (333 lines) is pure computation with no I/O, no state, no side effects. It produces chunk boundaries and silence durations from word arrays and paragraph breaks. The multi-pass boundary search (`findBestBoundary`, lines 257-299) tries backward, forward, expanded backward, expanded forward, then clamps — ensuring every chunk has a legal boundary without ever failing. This is more sophisticated than abogen's deterministic chunk model, which uses fixed sentence boundaries without tolerance-based search.

**kokoroStrategy is a clean integration layer.** At 362 lines, it bridges pipeline, scheduler, cache, and rate plan without leaking implementation details. The `queueMicrotask` for `acknowledgeChunk` (line 234) ensures the scheduler has queued the chunk before releasing the pipeline for backpressure — a subtle correctness detail.

#### What the Findings Envision

The literature review recommends RealtimeTTS-style `playback-buffered-seconds` backpressure (the pipeline checks `scheduler.getBufferedSeconds()` before issuing the next IPC). The deep-research report emphasizes content-addressed cache keys and deterministic segment IDs flowing through the pipeline. The Compass review recommends `AsyncIterable<AudioChunk>` as the engine contract and `MediaSource`-backed playback.

#### Implementation Gaps

**No outbound backpressure from scheduler to pipeline.** The pipeline's `pendingChunks` counter (line 275 of generationPipeline.ts) throttles emission, but it counts chunks, not buffered audio duration. The scheduler has no `getBufferedSeconds()` method. With Kokoro's ~3-5x realtime generation speed on CPU, the pipeline can outpace playback during long narration sessions, accumulating scheduled-but-unplayed audio on the Web Audio timeline.

**Unbounded pause buffer.** When paused, the pipeline continues generating and accumulates chunks in `pauseBuffer` (line 321 of generationPipeline.ts). For very long pauses during large documents, memory can grow without bound. On resume (lines 655-663), all buffered chunks flush synchronously without backpressure checks, potentially bursting the scheduler.

**Dangling promise.** `runPipeline` at line 622 of generationPipeline.ts is async but called without `.catch()`. The internal try/catch is thorough, making this low-risk, but adding `.catch(config.onError)` would close the gap.

**Linear crossfade, not equal-power.** `applyCrossfade` (lines 295-311 of audioScheduler.ts) uses linear ramps (`sample[i] *= i / crossfadeSamples`). Equal-power crossfade (`sqrt`-based) would be more acoustically neutral at the crossover point. The difference is likely inaudible at the configured crossfade duration, but it's a quality gap vs. professional audio tooling.

**Single `any` cast in kokoroStrategy.** Line 183: `(result as any).durationMs`. The IPC return type for `kokoroGenerate` doesn't declare `durationMs`. This is the only type-safety gap in the entire pipeline — the IPC type should be extended.

**Two `as any` casts in audioScheduler** (lines 383, 419): Dev telemetry pushes objects with extra fields not in `ChunkTimingTelemetry`. The interface should be widened.

**Cache-hit timing identity is not yet equivalent to cache-miss identity.** On fresh generation, the integration branch attaches `chunkId` and `timingTruth` from cache identity to the `ScheduledChunk` (`generationPipeline.ts` lines 506-511). On cache read, renderer `loadCachedChunk` reconstructs audio, `durationMs`, `words`, `startIdx`, and `wordTimestamps`, but does not rehydrate `chunkId`, `segmentId`, `timingTruth`, or sidecar-derived classification (`src/utils/ttsCache.ts` lines 47-54). The integration-branch scheduler then records timing metadata with fallback `chunkId: words:start-end` and inferred `timingTruth` (`audioScheduler.ts` lines 580-589). That makes generated playback and cached replay observably different to diagnostics/highlight sync even when they represent the same v2 cache identity.

#### Stabilization Debt

- No TODO or FIXME comments found in any of the four files.
- `narrationPlanner.ts` `findParagraphBounds` (lines 104-117) iterates the entire `paragraphBreaks` set twice per call. O(n) per planned chunk within the ~400-word window. Not a bottleneck today but would benefit from a sorted array + binary search if window size grows.
- The "parallel prefetch" at generationPipeline.ts lines 558-579 fires chunks 0 and 1 concurrently, but the Kokoro worker is single-session ONNX. The parallelism eliminates IPC serialization only. The naming is slightly misleading.

#### Sprint Impact

**TTS-EVENT-SYNC-1:** The scheduler's RAF-based `startWordTimer` (lines 429-489 of audioScheduler.ts) is the target for event-driven replacement. The `onTruthSync` callback (lines 464-468) fires every `TTS_CURSOR_TRUTH_SYNC_INTERVAL` words and would become the primary highlight trigger. The Phase 0 gate ensures baseline latency measurement before the RAF path is demoted. The scheduler's `getAudioProgress` (lines 765-802) would remain as the smooth interpolation source for visual cursor motion. The code is structured to absorb this change cleanly **after** `TTS-INTEGRATE-1` lands and cache-hit identity parity is tested.

**NORMALIZER-ENRICH-1:** The pipeline passes text through `normalizeForSpeech` in kokoroStrategy.ts (line 175). Adding 9 transforms to the normalizer requires no pipeline changes — the normalizer's output shape (`SegmentNormalizationResult`) is stable and the pipeline consumes only the `normalizedText` field. This is clean for speech quality, but not sufficient for render-map work: if `normalizedToOriginalMap` is expected soon, the transform contract should become alignment-aware before the nine transforms expand the surface area.

**TTS-RENDER-MAP-1:** The pipeline currently receives words via `config.getWords()` and emits `ScheduledChunk` objects with `startIdx` and `wordCount`. A word-index→DOM-position lookup table would be built externally and consulted by the highlight controller, not by the pipeline itself. No pipeline changes required.

#### Verdict: SOLID

The audio pipeline is Blurby's strongest implementation. Generation ID discipline, word timing validation, and pre-scheduled gapless playback exceed every reviewed external codebase. The backpressure gap and pause buffer are real but bounded-risk issues that don't block any queued sprint. The three `any`/`as any` casts are minor debt.

---

### 3. Text & Identity (segmentNormalizer + tts-cache + highlightSyncController + timingMetadataStore)

#### What It Does Well

**The normalizer is cleanly functional** (387 lines). Twelve transforms, each a pure `(text: string) => string` function, run through `applyTracked` which records which transforms fired. The `normalizationHash` (lines 367-374) is a composite content address capturing version, locale, source text, normalized text, pronunciation overrides, and transform sequence. Adding a new transform touches exactly 3 places: the `SegmentNormalizationTransformId` union, the transform function, and one `applyTracked` call. No other file needs to change. This extensibility pattern is better than Coqui's `english_cleaners` chain (which requires import changes) and comparable to abogen's approach.

**The cache is genuinely content-addressed** (658 lines). `tts-cache.js` implements a dual-key architecture: `identityHash` (SHA-256 of full identity including documentLocator) for disk path and manifest lookup, plus `contentKey` (SHA-256 of content-relevant fields only) for cross-book deduplication. `resolveReadTarget` (lines 258-263) tries exact match first, then content-indexed lookup. This meets the ttsreader `SHA256(text+lang+voice+rate)` pattern recommended by the Compass review and exceeds it by separating book-scoped identity from content-addressed lookup.

**The highlight sync controller is fail-closed** (82 lines). It never invents an active word when timing is untrusted. The `resolve()` function checks timing classification and only emits `mode: "word"` with a specific `activeWordIndex` when the record has `timingClassification: "trusted"` and the word index falls within the chunk range. Otherwise it falls back to chunk-level sync. This implements the principle from LL-075 and LL-078.

**The timing metadata store has strict classification** (117 lines). `classifyTiming` (lines 39-45) requires `timingTruth === "word-native"` AND non-empty timestamps AND length matching `chunkEndIdx - chunkStartIdx`. This word-count match gate is stricter than the cache's check (which only validates individual timestamp structure). Defense in depth.

#### What the Findings Envision

The literature review and deep-research report both recommend a three-text-layer model per segment: user-visible, original extracted, normalized synthesis text. The adversarial review (BC-2) identifies that segment identity is distributed across `SegmentNormalizationResult`, `TtsCacheIdentityV2`, and `PlannedChunk` and asks whether this distribution is coherent or fragmented. All findings recommend a unified `NarrationSegment` or `DocumentSegment` domain type. The Compass review proposes `sha1(${docId}:${cfi}:${sentenceIndex})` as the canonical segment ID. abogen's `chunk_text` produces deterministic IDs like `chap0000_p0000_s0000`.

#### Implementation Gaps

**`tts-cache.js` is the weakest type-safety link.** The entire 658-line file is untyped CommonJS JavaScript. The renderer declares TypeScript interfaces (`TtsCacheStructuredIdentity`, `TtsCacheWriteTimingMetadata`, `TtsTimingSidecar`) but the cache implementation validates identity objects only by checking `schemaVersion === TTS_CACHE_SCHEMA_VERSION` (line 67-69 — any object with `{schemaVersion: 2}` passes). The `writeChunk` function accepts 8 positional parameters (line 298) with no shape validation on `timingMetadata`. The IPC handler in `ipc/tts.js` line 354 mirrors this: `(_, bookId, voiceId, startIdx, pcmData, sampleRate, durationMs, wordCount, timingMetadata)` — eight positional args where mis-ordering is undetectable at compile time.

**Triple-storage of `timingTruth` in the cache.** Each chunk write stores `timingTruth` in three places: the identity object, the timing sidecar, and the manifest chunk metadata (lines 196, 212, 353 of tts-cache.js). `sourceTextHash`, `normalizedTextHash`, `normalizerVersion`, and `pronunciationOverrideHash` are also duplicated between the identity object and chunk metadata. If any write path updates one copy but not all three, consistency breaks silently.

**Inconsistent trusted-timing criteria between cache and store.** `tts-cache.js` classifies timing as trusted when `timingTruth === "word-native"` AND timestamps are non-empty AND each validates individually (lines 197-201). `timingMetadataStore.ts` classifies as trusted when `timingTruth === "word-native"` AND timestamps are non-empty AND `timestamps.length === chunkEndIdx - chunkStartIdx` (line 43). The store is stricter — it requires word-count match. A chunk could be cached as "trusted" but classified as "heuristic" by the store if the timestamp count doesn't match the declared word count.

**No alignment-aware transform contract yet.** The normalizer's extensibility is real for speech output, but each transform currently accepts and returns only a string (`segmentNormalizer.ts` line 48), and `applyTracked` records only transform IDs (`segmentNormalizer.ts` lines 248-257). `normalizedToOriginalMap` cannot be bolted on reliably after many destructive regex transforms unless transforms can report how they changed spans.

**The normalizer's 32-bit FNV-1a hash** (`stableSegmentTextHash`, lines 171-178) has a collision space of ~4 billion values. Adequate for per-book segment deduplication but tight if the cache grows to cross-book scale. The cache's content key uses SHA-256 (line 106), so the hash is only used within the `normalizationHash` composite — collision risk is mitigated by the composite structure.

#### Stabilization Debt

- `highlightSyncController.ts` and `timingMetadataStore.ts` exist only on the unmerged `sprint/tts-sync-1-highlight-controller` branch. They are not yet on `main`. ENGINE-DORMANCY-1 → TTS-INTEGRATE-1 will merge them.
- `queryWord` and `querySegment` in the timing store are O(n) linear scans over all stored records. Acceptable at current scale (dozens of chunks per session) but would need indexing if chunk counts grow significantly.
- `loadManifest` (lines 42-52 of tts-cache.js): bare `catch {}` swallows all errors and resets to defaults. Loses error diagnostics on corrupt manifests.
- `deleteEntryFiles` (line 277 of tts-cache.js): `.catch(() => {})` swallows FS errors. Violates LL-066 in spirit, though file cleanup failures are genuinely non-fatal.

#### Sprint Impact

**NORMALIZER-ENRICH-1** adds 9 transforms to `segmentNormalizer.ts`. The pipeline is extensible: add a type literal, write the function, add one `applyTracked` call. No changes to the normalizer's output shape, cache identity, or timing metadata are needed for speech-only enrichment. **Conditional absorption:** if the conveyor keeps `TTS-EVENT-SYNC-1` / `TTS-RENDER-MAP-1` close behind, add an alignment-aware transform-result contract first or explicitly defer `normalizedToOriginalMap`.

**TTS-EVENT-SYNC-1** promotes `onTruthSync` to primary highlight trigger and removes RAF polling from the hot path. The `highlightSyncController.ts` is already structured for this — its `resolve()` function makes decisions based on timing classification, not on how the decision was triggered. The controller doesn't care whether it's called from an RAF tick or an event callback. **Conditional absorption:** do not begin from canonical `main` until `TTS-INTEGRATE-1` lands; add cache miss-vs-hit timing identity parity before depending on diagnostics/highlight decisions.

**TTS-RENDER-MAP-1** builds a word-index→DOM-position lookup table. The timing metadata store already indexes by `chunkId` and provides `queryWord` by global word index. The render map would be a parallel data structure consumed by the highlight controller alongside the timing store. The controller's `HighlightSyncDecision` already carries `activeWordIndex` and `activeChunkRange` which the render map would use to resolve DOM positions. **Clean absorption with one caveat:** the O(n) `queryWord` may need optimization if the render map queries it frequently.

#### Verdict: ADEQUATE

The normalizer and highlight controller are clean and extensible. The cache is functionally correct and genuinely content-addressed. The type-safety gap in `tts-cache.js` is the most significant implementation weakness in this tier — the untyped 8-parameter IPC boundary is the highest-probability source of silent data corruption. The inconsistent timing classification between cache and store is a latent correctness risk. Neither blocks the conveyor, but the cache's type safety should be addressed opportunistically.

---

### 4. Provider Types & Registry (ttsProvider + ttsProviderRegistry)

#### What It Does Well

**`ttsProvider.ts` is clean and complete** (53 lines). `ProviderCapabilities` has 20 fields covering timing truth, streaming support, word timing, languages, licensing, sample rate, selectability, and experimental gating. The `TimingTruth` type (`"word-native" | "segment-following" | "unreliable-boundary" | "none"`) is the classification vocabulary used throughout the pipeline. The adversarial review (BC-3) noted ~80% overlap with the proposed `TTSProviderCapabilities` from the literature review — the existing type already captures most of what was recommended.

**The registry is data-driven** (187 lines). Five providers are declared as static `TTSProvider` objects with full capability metadata. Query functions (`listTtsProviders`, `listSelectableTtsProviders`, `getTtsProvider`, `getTtsProviderOrThrow`) provide clean lookup without engine-name branching.

#### What the Findings Envision

All findings recommend registry-driven strategy dispatch — `useNarration.ts` should resolve providers via registry metadata rather than `if (engine === "kokoro")` branches. The `createStrategy?` seam on `TTSProvider` (line 49-52) was declared by TTS-REGISTRY-1 as forward-looking infrastructure for exactly this purpose, but it's never implemented by any provider.

#### Implementation Gaps

**The `createStrategy` seam is dead code.** Declared on the `TTSProvider` interface but never implemented. The adversarial review (G2) correctly identifies this: the registry exists but doesn't drive strategy dispatch.

**Dormancy not reflected in registry metadata.** Nano (`selectable: true`) and Pocket TTS (`selectable: true`) are marked as selectable despite being dormant. The `disabledReason` field exists (used by Qwen: `"retired-desktop-v2"`) but is `null` for both dormant engines. ENGINE-DORMANCY-1 should set `selectable: false` and populate `disabledReason` for both.

**`getTtsProviderRegistrySnapshot`** (lines 176-186) uses `{} as Record<TtsEngine, TTSProvider>` — an `as` cast on an empty object that doesn't satisfy the Record constraint until populated. Technically unsafe but functionally benign since the loop immediately fills all keys.

#### Verdict: SOLID

These are small, well-typed files that do their job. The `createStrategy` seam is forward-looking debt that doesn't affect current behavior. The dormancy mismatch is a bookkeeping issue that ENGINE-DORMANCY-1 addresses directly. No blocking issues.

---

## Cross-Cutting Findings

### Error Handling Consistency

**Pattern:** Errors flow through three paths: (1) strategy `onError` callbacks that trigger `deps.onFallbackToWeb()`, (2) reducer `ERROR` actions that set `status: "error"` and clear all engine readiness, (3) IPC `toErrorResponse` wrappers that normalize errors to `{ error, reason, status, recoverable }`.

**Strengths:** Every IPC handler wraps its body in try/catch and returns normalized error responses — no handler throws to the caller. The pipeline's `onError` callback triggers Web Speech fallback cleanly. Error types are enriched with `reason`, `recoverable`, and `status` fields in `tts-engine.js` (line 85).

**Weaknesses:** The reducer's ERROR action (narration.ts line 180) is a nuclear option that clears all engine readiness. Error classification is inferred from string lookups rather than a reason-code enum — the literature review (gap #22) recommends a formal error taxonomy. Silent `.catch(() => {})` appears on 6+ mount-time status probes, violating LL-066's spirit but practically acceptable for probes that expect failures during engine unavailability.

**Comparison:** RealtimeTTS can fall back to alternate engines on failure. readest's `TTSController.error()` treats abort as normal (not an error). Blurby's fallback-to-Web-Speech pattern is correct but the undifferentiated ERROR action means a Nano failure penalizes Kokoro readiness — unnecessary coupling that ENGINE-DORMANCY-1 will mitigate by removing the dormant paths.

### The "NarrationSegment" Question

**Assessment: The distributed identity model is coherent but has one genuine fragmentation point.**

The three types serve distinct concerns:
- `SegmentNormalizationResult` owns text identity (original/normalized text, hashes, transforms, locale, version)
- `TtsCacheIdentityV2` owns cache identity (provider, voice, rate, model version, sample rate, timing truth, document locator + all normalizer fields)
- `PlannedChunk` owns boundary identity (startIdx, endIdx, boundaryType, silenceMs, isDialogue)

This is **coherent separation of concerns**, not fragmentation. Each type owns its domain. The cache identity correctly includes normalizer fields because the same text normalized differently (different version, different locale) should produce a different cache entry.

**The genuine fragmentation point** is the triple-storage of `timingTruth` within `tts-cache.js` (identity object, timing sidecar, manifest chunk metadata) and the inconsistent timing classification criteria between cache and timing metadata store. These are implementation-level fragmentation, not type-level.

**Recommendation: Keep distributed. Do NOT add a unification sprint.** A unified `NarrationSegment` type would be a fourth representation that other modules would need to construct and destructure, adding coupling without reducing fragmentation. Instead, the remaining sprints should: (1) harmonize timing classification criteria between cache and store (adopt the store's stricter word-count-match gate in the cache), and (2) reduce `timingTruth` storage in the cache from 3 copies to 1 authoritative location (the timing sidecar, with other locations derived on read).

### Testing Coverage vs. Findings Recommendations

The codebase has 2,397 tests across 150 files. Test coverage is strong for:
- Word timing validation (audioScheduler tests)
- Normalizer transforms (golden fixtures in segmentNormalizer tests)
- Pipeline generation ID guards (generationPipeline tests)
- Highlight sync decisions (highlightSyncController tests on branch)
- Cache v1/v2 read/write (tts-cache tests)

**Blind spots identified by the findings:**
- No end-to-end pipeline trace test (planner → normalizer → cache identity → timing sidecar consistency). The adversarial review (R2) specifically recommends this.
- No golden segmentation corpus for OCR text, poetry, tables, or footnotes (adversarial review R3).
- No explicit cache replay parity test verifies that cache miss and cache hit produce the same `chunkId`, `timingTruth`, timing classification, and highlight decision. This is the most important addition to `TTS-PIPELINE-1` because the cache-hit path is where identity can drift.
- No long-form drift regression suite with CI gate (the eval harness exists but runs ad-hoc).
- No cross-boundary chunk flow test (what happens when a chunk spans a section boundary?).

### Dead Code & Legacy Paths

**Qwen:** ~200 lines in `useNarration.ts` (status monitoring, streaming probe, warming, dispatch, pause/resume, rate change). 8 stub IPC handlers in `ipc/tts.js`. Dead validation branches in `narrationContinuity.ts` (lines 84-89). Type union entries in `narrateDiagnostics.ts`. Total: ~250 lines of code that ENGINE-DORMANCY-1 will remove.

**MOSS-Nano:** Strategy creation gated behind `experimentalNano`, but `speakNextChunkNano` (lines 761-882 of useNarration.ts) is 120 lines of fully implemented code. 5 live IPC handlers in `ipc/tts.js` that call into the real engine module. The engine module is `require()`-ed unconditionally on app startup (line 81 of ipc/tts.js). ENGINE-DORMANCY-1 should gate the `require()` and set `selectable: false` in the registry.

**Pocket TTS:** Strategy is always created (line 508-518 of useNarration.ts) with no gate. `speakNextChunkPocket` (lines 884-955) is 70 lines. 5 live IPC handlers. Same unconditional `require()`. Same registry mismatch.

**Total dormant code:** ~450 lines in useNarration.ts + ~75 lines of IPC handlers + ~20 lines of dead validation branches = ~545 lines. ENGINE-DORMANCY-1 will meaningfully simplify the codebase.

---

## End-to-End Data Flow Traces

### Trace 1: Cold-Start First Chunk

1. User opens book, presses Play → `useNarration.startCursorDriven()` (line 1127)
2. Engine is "kokoro" → checks `kokoroStatus` → if not ready, dispatches `WARM` and calls `api.kokoroPreload()` (line 1256)
3. Kokoro becomes ready → auto-start effect fires (line 587-596) → calls `startCursorDriven` again
4. `kokoroStrategy.speakChunk(startIdx, words, ...)` (line 264 of kokoroStrategy.ts)
5. Strategy creates scheduler, creates pipeline, calls `pipeline.start(startIdx)` (line 301)
6. Pipeline enters `buildOpeningRampPlan` (line 157 of generationPipeline.ts) → produces 4-chunk geometric ramp plan
7. First chunk: `produceChunk` → resolves chunk end via planner → `buildChunkText` joins words → `config.generateFn(text, voice, speed, words)` (line 439)
8. `generateFn` in kokoroStrategy (line 175) → `normalizeForSpeech(text)` → `resolveKokoroRatePlan(speed, voice)` → `api.kokoroGenerate(normalizedText, voice, rateBucket, chunkWords)`
9. IPC invoke `"tts-kokoro-generate"` (line 104 of ipc/tts.js) → `ttsEngine.generate(text, voice, speed, words)` (line 816 of tts-engine.js)
10. Engine posts `{ type: "generate", id, text, voice, speed, words }` to worker (line 824)
11. Worker calls `ttsInstance.generate(text, { voice, speed, words })` (line 157 of tts-worker.js) → kokoro-js produces PCM + wordTimestamps
12. Worker posts `{ type: "result", id, audio: f32, sampleRate, durationMs, wordTimestamps }` via Transferable (zero-copy)
13. Engine resolves pending promise → IPC returns `{ audio, sampleRate, durationMs, wordTimestamps }` to renderer
14. Pipeline receives result → validates audio/sampleRate → appends silence samples based on planner boundary → constructs `ScheduledChunk` with word timestamps
15. `config.onChunkReady(chunk)` → kokoroStrategy `onChunkReady` (line 195) → `segmentKokoroChunk` splits for tempo → `scheduler.scheduleChunk(segment)` for each
16. Scheduler: `applyTempoStretchIfNeeded` → `applyCrossfade` (no fade-in on first chunk) → create `AudioBuffer` → `source.start(chunkStartTime)` → `computeWordBoundaries` from real timestamps → `startWordTimer` begins RAF polling
17. `pipeline.acknowledgeChunk()` via `queueMicrotask` releases backpressure for next chunk

**Type narrowing gaps found:** At step 14, the cache identity check `typeof cacheIdentity === "object"` (line 514 of generationPipeline.ts) is loose — it doesn't narrow to `TtsCacheIdentityV2`. At step 12, the worker duck-types the kokoro-js return (`result.audio || result`, line 158 of tts-worker.js). Both are minor.

**Timing metadata flow:** Word timestamps survive the full chain: kokoro-js → worker → engine → IPC → renderer → pipeline → scheduler → `computeWordBoundaries`. The scheduler validates them thoroughly (step 16) before trusting them. The pipeline also writes them to cache (lines 517-523 of generationPipeline.ts) via `config.onCacheChunk`. **No timing loss point found.**

### Trace 2: Mid-Narration Pause/Resume

1. User presses Pause → `useNarration.pause()` (line 1502)
2. Dispatches `PAUSE` to reducer (sets status to `"paused"`)
3. For Kokoro: calls `kokoroStrategy.pause()` (line 314 of kokoroStrategy.ts)
4. Strategy: `scheduler.pause()` first → then `pipeline.pause()`
5. Scheduler: suspends AudioContext, clears word timer (RAF stops)
6. Pipeline: sets `paused = true`. Generation continues — chunks accumulate in `pauseBuffer`
7. User presses Resume → `useNarration.resume()` (line 1530)
8. Dispatches `RESUME` to reducer (sets status to `"speaking"`)
9. Calls `kokoroStrategy.resume()` (line 319)
10. Strategy: `pipeline.resume()` first → then `scheduler.resume()`
11. Pipeline resume flushes all `pauseBuffer` chunks via `config.onChunkReady` synchronously — **no backpressure check**
12. Scheduler: resumes AudioContext, restarts word timer

**Concern found at step 11:** If many chunks accumulated during a long pause, the flush floods the scheduler. The scheduler accepts them all (it has no queue depth limit). They're scheduled on the Web Audio timeline for sequential playback, so this doesn't cause audible problems, but it means memory spikes proportional to pause duration. For a 30-minute pause in a long book, this could accumulate hundreds of MB of decoded PCM in AudioBuffer objects.

**State consistency:** The pause/resume ordering (scheduler-first on pause, pipeline-first on resume) is correct. The stateRef is updated before strategy calls at both pause (line 1520) and resume (line 1553). No desync found.

### Trace 3: Cached Replay of the Same Chunk

1. The pipeline resolves the same planned chunk and rebuilds the same structured v2 cache identity.
2. `config.isCached(startIdx, cacheIdentity)` returns true, so `config.loadCached(startIdx, cacheIdentity)` replaces fresh generation.
3. Renderer `loadCachedChunk` reads the cache entry and returns a `ScheduledChunk` with audio, sample rate, duration, words, `startIdx`, and `wordTimestamps`.
4. That returned chunk currently does not carry the v2 identity fields that fresh generation attaches: `chunkId`, `segmentId`, and `timingTruth`.
5. The integration-branch scheduler records timing metadata using fallback `chunkId: words:start-end` and infers timing truth from `wordTimestamps`.
6. Highlight sync and diagnostics can therefore see a different timing-record ID on cached replay than on first playback.

**Concern found:** cache read/write correctness is covered, and sidecars preserve timing, but the renderer wrapper does not yet rehydrate the scheduled playback identity from the sidecar/cache identity. `TTS-PIPELINE-1` should add a miss-vs-hit parity test before `TTS-EVENT-SYNC-1` relies on timing metadata as visual truth.

---

## Ranked Action Items

| # | Priority | Item | Affected Sprint | Effort | Risk if Ignored |
|---|----------|------|----------------|--------|-----------------|
| 1 | **P1** | Land `ENGINE-DORMANCY-1` and `TTS-INTEGRATE-1` before dispatching event-sync work from canonical main | ENGINE-DORMANCY-1, TTS-INTEGRATE-1 | S | Downstream sprints start from branch reality rather than product reality |
| 2 | **P1** | Harmonize timing classification criteria: adopt timingMetadataStore's word-count-match gate in tts-cache.js `buildTimingSidecar` (lines 197-201) | TTS-INTEGRATE-1 | 30 min | Silent trusted/heuristic disagreement between cache reads and store queries |
| 3 | **P1** | Rehydrate cache-hit timing identity into `ScheduledChunk`: `chunkId`, `segmentId`, `timingTruth`, and sidecar-derived metadata; add miss-vs-hit parity test | TTS-PIPELINE-1, TTS-EVENT-SYNC-1 | 1-2 hrs | Diagnostics and highlight sync decisions differ between first playback and cached replay |
| 4 | **P1** | Set `selectable: false` and `disabledReason` for nano and pocket-tts in ttsProviderRegistry.ts | ENGINE-DORMANCY-1 | 10 min | Settings UI could display dormant engines as available |
| 5 | **P1** | Fix `(result as any).durationMs` cast in kokoroStrategy.ts line 183 — extend the IPC return type to include `durationMs` | TTS-INTEGRATE-1 | 15 min | Type-safety gap at the strategy-IPC boundary |
| 6 | **P2** | Change normalizer transforms from plain `string -> string` to an alignment-aware result contract before adding render-map-dependent `normalizedToOriginalMap` | TTS-EVENT-SYNC-1, NORMALIZER-ENRICH-1 | M | Normalization quality improves while word-to-DOM sync becomes harder to prove |
| 7 | **P2** | Add `.catch(config.onError)` to the dangling `runPipeline` call at generationPipeline.ts line 622 | TTS-PIPELINE-1 | 5 min | Potential unhandled rejection on edge-case pipeline failure |
| 8 | **P2** | Widen `ChunkTimingTelemetry` interface to include `realTimestamps` and `timestampSource` fields, remove `as any` at audioScheduler.ts lines 383, 419 | TTS-PIPELINE-1 | 15 min | Dev telemetry type debt |
| 9 | **P2** | Add backpressure check to pipeline resume flush (generationPipeline.ts lines 655-663) — check `pendingChunks < queueDepth` before each `onChunkReady` call | TTS-PIPELINE-1 | 30 min | Memory spike on resume after long pause |
| 10 | **P2** | Reduce `timingTruth` storage in tts-cache.js from 3 copies to 1 authoritative location (timing sidecar), derive in manifest on read | TTS-PIPELINE-1 | 1 hr | Triple-storage consistency risk grows as timing-dependent features ship |
| 11 | **P2** | Add runtime shape validation for structured identity in tts-cache.js `isStructuredIdentity` (line 67-69) — validate required fields beyond just `schemaVersion` | TTS-PIPELINE-1 | 30 min | Any object with `{schemaVersion: 2}` passes identity check |
| 12 | **P3** | Scope ERROR action in narration.ts reducer to only clear the engine that errored, not all engines (line 180) | Post-conveyor | 30 min | Cross-engine readiness pollution (mitigated by Kokoro-only posture) |
| 13 | **P3** | Extract shared ownership helper for nano/pocket-tts generation ownership patterns in useNarration.ts (lines 333-362) | ENGINE-DORMANCY-1 | 20 min | Duplication (but both paths will be dormant) |
| 14 | **P3** | Add end-to-end pipeline trace test (planner → normalizer → cache identity → timing sidecar → highlight sync decision) | TTS-PIPELINE-1 | 2-4 hrs | Testing blind spot for cross-module contract consistency |
| 15 | **P3** | Refactor `TtsStrategy.speakChunk` from 7 positional parameters to options object | Post-conveyor | 1-2 hrs | Positional parameter ordering errors in 6 strategy implementations |

---

## Validation Architecture

### Minimal Testable Propositions

1. **Timing classification consistency:** Write a test that generates a chunk with known word timestamps, writes it to cache, reads it back, feeds it to timingMetadataStore, and asserts both classify the timing identically. If this test fails, item #2 is validated as a real inconsistency.

2. **Cache miss-vs-hit identity parity:** Generate one Kokoro chunk cold, persist it, replay the same chunk from cache, and assert identical `chunkId`, `segmentId`, `timingTruth`, timing classification, and highlight-sync decision. If this fails, item #3 is validated and should block `TTS-EVENT-SYNC-1`.

3. **Normalizer alignment contract:** Add a fixture where normalization expands text length (`$1.2 million`, dates, ordinals, abbreviations) and assert that each normalized token can map back to a source span. If this cannot be expressed with the current `TransformFn`, item #6 is validated.

4. **Pause buffer memory:** Instrument the pipeline to log `pauseBuffer.length` on resume. Narrate a 10,000-word passage, pause for 60 seconds, resume. If `pauseBuffer` exceeds 20 chunks, the unbounded buffer concern (item #9) is real and measurable.

5. **Registry/runtime dormancy agreement:** Write a test that asserts: for every provider where `registry.selectable === true`, the runtime path in useNarration can actually instantiate its strategy. If this fails for nano or pocket-tts, item #4 is validated.

### Validation Cost-Benefit

- **Cost of testing before acting:** 4-6 hours for propositions 1-5.
- **Cost of acting on current analysis if wrong:** Items #2, #4, and #5 are low-risk fixes. Item #3 is slightly broader because it changes cache-read `ScheduledChunk` shape. Item #6 is the only structural change and should be bounded by fixtures before implementation.
- **Recommendation:** Items #1, #2, #4, and #5 are cheap enough to fix without further proof. Items #3 and #6 should be validated with propositions #2 and #3 before `TTS-EVENT-SYNC-1` or `NORMALIZER-ENRICH-1` proceed.

## Remaining Uncertainty

1. **The unmerged branches.** `highlightSyncController.ts` and `timingMetadataStore.ts` were analyzed on their feature branches. The actual merge via TTS-INTEGRATE-1 may introduce conflicts or behavioral changes not visible in isolation. The MOSS Nano probe test failure blocking TTS-INTEGRATE-1 is addressed by ENGINE-DORMANCY-1.

2. **Long-form drift under real conditions.** The word timing validation is thorough in unit tests, but no CI-gated long-form drift regression suite exists. The eval harness (TTS-EVAL-1/2) captures metrics but runs ad-hoc. Whether timing drift accumulates over 30+ minutes of continuous narration is an empirical question that this code review cannot answer.

3. **IPC serialization cost for large audio.** The worker uses `Transferable` for zero-copy PCM transfer to the engine thread, but the IPC from main process to renderer uses Electron's structured clone. For 40-word chunks at 24kHz, this is ~4 seconds of audio (~384KB). Acceptable, but if chunk sizes increase (NORMALIZER-ENRICH-1 could produce longer chunks due to better sentence detection), this cost grows linearly.

4. **kokoro-js patch stability.** The word timestamp patch relies on surfacing the duration tensor from kokoro-js internals. Upstream kokoro-js releases could change the internal structure. The 4-layer validation (LL-089) detects breakage but doesn't prevent it. A second review pass would quantify the exact API surface the patch depends on.

5. **Cache growth at scale.** The content-addressed dual-key cache has no size-based eviction policy. `getCacheInfo()` reports total bytes, and `evictBook` / `evictBookVoice` provide manual eviction. But there's no automatic LRU or size cap. For heavy users with many books, cache could grow to multiple GB.
