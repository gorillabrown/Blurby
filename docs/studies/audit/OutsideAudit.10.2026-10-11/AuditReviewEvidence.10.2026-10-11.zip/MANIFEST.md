# D4 review evidence

Source response SHA256: 892f09139654ee5ee2f4286f82a246722d3c3278a8e35b024068fc7674de6bcb
Report SHA256: 582c0dc39bce9f27d7cb299e102b4754e59b03c6fd6e4d295ee95ecfa953cb2c

The original response package remains required for source and pre-existing controls.

| Entry | Files |
|---|---:|
| 00_D4_report.zip | 2 |
| 01_fresh_specialist_reviews.zip | 2 |
| 02_custody_verification.zip | 3 |
