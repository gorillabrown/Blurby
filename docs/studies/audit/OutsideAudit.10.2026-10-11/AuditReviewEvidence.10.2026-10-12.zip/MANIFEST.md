# D4b evidence

Response package SHA256: dcb9896840edde8238375bbbdce5586dcceb4266cb46a76034cca81588edf2d7
Fresh D4b report SHA256: 9ff0eae7fff003154bd6ab91130169d7217683d8871d3210a223a013c359e11a

The delta package remains required for proposed source and recorded controls.

| Entry | Files |
|---|---:|
| 00_D4b_report.zip | 2 |
| 01_fresh_subset_reviews.zip | 2 |
| 02_custody_verification.zip | 2 |
