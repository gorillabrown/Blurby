import { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { formatTime, formatDisplayTitle } from "../utils/text";
import { MIN_WPM, MAX_WPM, WPM_STEP, EINK_SEARCH_DEBOUNCE_MS, NEW_LIBRARY_DAYS, SEARCH_BLUR_DELAY_MS, FOLIATE_MIN_ENGAGEMENT_POSITION } from "../constants";
import { BlurbyDoc, BlurbySettings, SyncStatusValue, ToastState } from "../types";
import { useTheme } from "./ThemeProvider";
import { triggerCoachHint } from "./HotkeyCoach";
import AddEditPanel from "./AddEditPanel";
import DocCard from "./DocCard";
import DocGridCard from "./DocGridCard";
import StatsPanel from "./StatsPanel";
import RecentFolders from "./RecentFolders";
import CloudSyncIndicator from "./CloudSyncIndicator";
import blurbyIcon from "../assets/blurby-icon.png";

const api = window.electronAPI;

interface LibraryViewProps {
  library: BlurbyDoc[];
  settings: BlurbySettings;
  wpm: number;
  isMac: boolean;
  folderName: string;
  loadingContent: boolean;
  toast: ToastState | null;
  onOpenDoc: (doc: BlurbyDoc, mode?: string) => void;
  onAddDoc: (title: string, content: string, editingId?: string | null) => void;
  onAddDocFromUrl: (url: string) => Promise<{ doc?: BlurbyDoc; error?: string }>;
  onDeleteDoc: (id: string) => void;
  onResetProgress: (id: string) => void;
  onSelectFolder: () => void;
  onSwitchFolder: (folder: string) => void;
  onSetWpm: (wpm: number) => void;
  onSetFolderName: (name: string) => void;
  onToggleFavorite: (id: string) => void;
  onArchiveDoc: (id: string) => void;
  onUnarchiveDoc: (id: string) => void;
  onToggleFlap: () => void;
  onSettingsChange: (patch: Partial<BlurbySettings>) => void;
  focusedDocId?: string | null;
  selectedIds?: Set<string>;
  selectionMode?: boolean;
  onToggleSelect?: (docId: string) => void;
  onMarkDocsSeen?: (docIds: string[]) => void;
}

export default function LibraryView({
  library, settings, wpm, isMac, folderName, loadingContent, toast,
  onOpenDoc, onAddDoc, onAddDocFromUrl, onDeleteDoc, onResetProgress,
  onSelectFolder, onSwitchFolder, onSetWpm, onSetFolderName,
  onToggleFavorite, onArchiveDoc, onUnarchiveDoc, onToggleFlap, onSettingsChange,
  focusedDocId, selectedIds, selectionMode, onToggleSelect, onMarkDocsSeen,
}: LibraryViewProps) {
  const { theme, setTheme } = useTheme();
  const [tab, setTab] = useState("all"); // "all" | "new" | "favorites" | "archived"
  const NEW_DAYS = NEW_LIBRARY_DAYS;
  const [showAdd, setShowAdd] = useState(false);
  const [showUrl, setShowUrl] = useState(false);
  const [rescanning, setRescanning] = useState(false);

  const handleRescan = async () => {
    setRescanning(true);
    try {
      await api.rescanFolder();
    } finally {
      setRescanning(false);
    }
  };
  const [urlInput, setUrlInput] = useState("");
  const [urlError, setUrlError] = useState("");
  const [newTitle, setNewTitle] = useState("");
  const [newText, setNewText] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showStats, setShowStats] = useState(false);
  const [showRecent, setShowRecent] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const [editFolder, setEditFolder] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [debouncedSearchQuery, setDebouncedSearchQuery] = useState("");
  const [searchFocused, setSearchFocused] = useState(false);
  const [searchIndex, setSearchIndex] = useState(-1);
  const [sortBy, setSortBy] = useState(settings.defaultSort || "author"); // "alpha" | "author" | "newest" | "oldest"

  // E-ink: debounce search to 500ms to reduce repaints
  const isEinkTheme = settings.theme === "eink";
  useEffect(() => {
    if (!isEinkTheme) {
      setDebouncedSearchQuery(searchQuery);
      return;
    }
    const timer = setTimeout(() => setDebouncedSearchQuery(searchQuery), EINK_SEARCH_DEBOUNCE_MS);
    return () => clearTimeout(timer);
  }, [searchQuery, isEinkTheme]);
  const [typeFilter, setTypeFilter] = useState<"all" | "articles" | "books" | "pdfs">("all");
  const [updateReady, setUpdateReady] = useState<string | null>(null);
  const [launchAtLogin, setLaunchAtLogin] = useState(false);

  useEffect(() => {
    const unsub = api.onUpdateDownloaded?.((version) => setUpdateReady(version));
    return () => unsub?.();
  }, []);

  useEffect(() => {
    if (settings.theme && settings.theme !== theme) setTheme(settings.theme);
  }, [settings.theme]);

  useEffect(() => {
    api.getLaunchAtLogin?.().then((v) => setLaunchAtLogin(v));
  }, []);

  // Scroll focused card into view when keyboard focus changes
  const prevFocusedRef = useRef<string | null | undefined>(null);
  useEffect(() => {
    if (!focusedDocId || focusedDocId === prevFocusedRef.current) return;
    prevFocusedRef.current = focusedDocId;
    const el = document.querySelector<HTMLElement>(`[data-doc-id="${focusedDocId}"]`);
    el?.scrollIntoView({ block: "nearest", behavior: "smooth" });
  }, [focusedDocId]);

  const isPdf = (d: BlurbyDoc) => d.ext === ".pdf";
  const isArticle = (d: BlurbyDoc) => d.source === "url" || d.source === "manual";
  const isBook = (d: BlurbyDoc) => !isArticle(d) && !isPdf(d);

  // Filter and sort library
  const filteredLibrary = useMemo(() => {
    let docs = library;
    if (tab === "favorites") docs = docs.filter((d) => d.favorite);
    else if (tab === "archived") docs = docs.filter((d) => d.archived);
    else if (tab === "new") {
      const cutoff = Date.now() - NEW_DAYS * 24 * 60 * 60 * 1000;
      docs = docs.filter((d) => !d.archived && (d.created || 0) >= cutoff);
    }
    else docs = docs.filter((d) => !d.archived);
    if (typeFilter === "articles") docs = docs.filter(isArticle);
    else if (typeFilter === "books") docs = docs.filter(isBook);
    else if (typeFilter === "pdfs") docs = docs.filter(isPdf);
    const effectiveSearch = isEinkTheme ? debouncedSearchQuery : searchQuery;
    if (effectiveSearch) docs = docs.filter((d) => d.title.toLowerCase().includes(effectiveSearch.toLowerCase()));

    return [...docs];
  }, [library, tab, typeFilter, searchQuery, debouncedSearchQuery, isEinkTheme]);

  // BUG-067 + READINGS-4A: IntersectionObserver to track "new" cards seen in viewport
  // Cards must be visible for >=1 second before marking as seen (debounce via setTimeout + Map)
  const seenDocIdsRef = useRef<Set<string>>(new Set());
  const seenTimersRef = useRef<Map<string, ReturnType<typeof setTimeout>>>(new Map());
  useEffect(() => {
    const scrollContainer = document.querySelector(".library-scroll");
    if (!scrollContainer) return;
    const timers = seenTimersRef.current;
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          const docId = (entry.target as HTMLElement).dataset.docId;
          if (!docId) continue;
          if (entry.isIntersecting) {
            // Start 1s timer if not already running
            if (!timers.has(docId)) {
              const timer = setTimeout(() => {
                seenDocIdsRef.current.add(docId);
                timers.delete(docId);
              }, 1000);
              timers.set(docId, timer);
            }
          } else {
            // Card scrolled out of view — cancel timer
            const existing = timers.get(docId);
            if (existing) {
              clearTimeout(existing);
              timers.delete(docId);
            }
          }
        }
      },
      { root: scrollContainer, threshold: 0.5 }
    );
    // Observe all unread cards
    const unreadCards = scrollContainer.querySelectorAll<HTMLElement>(".doc-grid-card-unread, .doc-card-unread");
    unreadCards.forEach((card) => observer.observe(card));
    return () => {
      observer.disconnect();
      // Clean up any pending timers
      for (const timer of timers.values()) clearTimeout(timer);
      timers.clear();
    };
  }, [filteredLibrary]);

  // Flush seen docs when navigating away from library
  const flushSeenDocs = useCallback(() => {
    if (seenDocIdsRef.current.size > 0 && onMarkDocsSeen) {
      onMarkDocsSeen(Array.from(seenDocIdsRef.current));
      seenDocIdsRef.current.clear();
    }
  }, [onMarkDocsSeen]);

  // Wrap onOpenDoc to flush seen docs before navigating
  const handleOpenDocWithSeen = useCallback((doc: BlurbyDoc, mode?: string) => {
    flushSeenDocs();
    onOpenDoc(doc, mode);
  }, [onOpenDoc, flushSeenDocs]);

  // Wrap onToggleFlap to flush seen docs
  const handleToggleFlapWithSeen = useCallback(() => {
    flushSeenDocs();
    onToggleFlap();
  }, [onToggleFlap, flushSeenDocs]);

  const { activeLibrary, totalWords, newCount, favCount, archivedCount, articleCount, bookCount, pdfCount } = useMemo(() => {
    const active = library.filter((d) => !d.archived);
    const cutoff = Date.now() - NEW_DAYS * 24 * 60 * 60 * 1000;
    return {
      activeLibrary: active,
      totalWords: active.reduce((a, d) => a + (d.wordCount || 0), 0),
      newCount: active.filter((d) => (d.created || 0) >= cutoff).length,
      favCount: library.filter((d) => d.favorite).length,
      archivedCount: library.filter((d) => d.archived).length,
      articleCount: active.filter(isArticle).length,
      bookCount: active.filter(isBook).length,
      pdfCount: active.filter(isPdf).length,
    };
  }, [library]);

  // Live search results (limited to 8 for the dropdown)
  const searchResults = useMemo(() => searchQuery
    ? library.filter((d) => {
        const q = searchQuery.toLowerCase();
        return d.title.toLowerCase().includes(q) || (d.author || "").toLowerCase().includes(q);
      }).slice(0, 8)
    : [], [searchQuery, library]);

  // formatDisplayTitle imported from utils/text

  // Split filtered docs into reading now vs not started
  // FOLIATE_MIN_ENGAGEMENT_POSITION filters out tiny rounding artifacts from initial EPUB onRelocate
  const { readingNow, notStarted } = useMemo(() => {
    // "Reading Now" always sorted by closest-to-finished (highest progress % first)
    const rn = filteredLibrary
      .filter((d) => (d.position || 0) >= FOLIATE_MIN_ENGAGEMENT_POSITION && (d.wordCount ? (d.position || 0) < d.wordCount : true))
      .sort((a, b) => {
        const pctA = a.wordCount > 0 ? (a.position || 0) / a.wordCount : 0;
        const pctB = b.wordCount > 0 ? (b.position || 0) / b.wordCount : 0;
        if (pctB !== pctA) return pctB - pctA;
        return a.title.localeCompare(b.title);
      });

    // "Not Started" sorted by user's chosen sort
    const ns = filteredLibrary
      .filter((d) => (d.position || 0) < FOLIATE_MIN_ENGAGEMENT_POSITION);

    // Apply sort to Not Started
    if (sortBy === "alpha") {
      ns.sort((a, b) => a.title.localeCompare(b.title));
    } else if (sortBy === "newest") {
      ns.sort((a, b) => (b.created || 0) - (a.created || 0));
    } else if (sortBy === "oldest") {
      ns.sort((a, b) => (a.created || 0) - (b.created || 0));
    } else if (sortBy === "author") {
      ns.sort((a, b) => {
        const authorA = (a.author || a.authorFull || "").trim();
        const authorB = (b.author || b.authorFull || "").trim();
        const lastA = authorA.split(/\s+/).pop() || "";
        const lastB = authorB.split(/\s+/).pop() || "";
        if (!lastA && !lastB) return a.title.localeCompare(b.title);
        if (!lastA) return 1;
        if (!lastB) return -1;
        const cmp = lastA.localeCompare(lastB, undefined, { sensitivity: "base" });
        return cmp !== 0 ? cmp : a.title.localeCompare(b.title);
      });
    }

    return { readingNow: rn, notStarted: ns };
  }, [filteredLibrary, sortBy]);

  // Library layout CSS class modifiers
  const cardSize = settings.libraryCardSize || "medium";
  const cardSpacing = settings.libraryCardSpacing || "cozy";
  const gridClassName = `doc-grid doc-grid-size-${cardSize} doc-grid-spacing-${cardSpacing}`;
  const listClassName = `doc-list doc-list-spacing-${cardSpacing}`;

  const handleAddDoc = async () => {
    if (editMetaMode && editingId) {
      // Metadata-only save (file-based docs — update title + author)
      const doc = library.find(d => d.id === editingId);
      if (doc) {
        doc.title = newTitle.trim() || doc.title;
        doc.author = newAuthor.trim() || doc.author;
        api.updateDocProgress(doc.id, doc.position || 0); // triggers library save
      }
      setNewTitle(""); setNewAuthor(""); setShowAdd(false); setEditingId(null); setEditMetaMode(false);
      return;
    }
    if (!newTitle.trim()) return;
    await onAddDoc(newTitle.trim(), newText.trim(), editingId);
    setNewTitle(""); setNewText(""); setShowAdd(false); setEditingId(null);
  };

  const handleAddFromUrl = async () => {
    const url = urlInput.trim();
    if (!url) return;
    try { new URL(url); } catch { setUrlError("Please enter a valid URL."); return; }
    setUrlError("");
    const result = await onAddDocFromUrl(url);
    if (result?.error) { setUrlError(result.error); }
    else { setUrlInput(""); setShowUrl(false); setUrlError(""); }
  };

  const [newAuthor, setNewAuthor] = useState("");
  const [editMetaMode, setEditMetaMode] = useState(false);

  const startEdit = useCallback((doc: BlurbyDoc) => {
    setEditingId(doc.id);
    setNewTitle(doc.title);
    setNewAuthor(doc.author || "");
    // For file-based docs, open metadata editor (no content editing)
    if (doc.filepath) {
      setEditMetaMode(true);
      setShowAdd(true);
    } else {
      setEditMetaMode(false);
      setNewText(doc.content || "");
      setShowAdd(true);
    }
  }, []);

  const handleCancelDelete = useCallback(() => setConfirmDelete(null), []);
  const handleOpenScroll = useCallback((d: BlurbyDoc) => handleOpenDocWithSeen(d, "scroll"), [handleOpenDocWithSeen]);
  const handleOpenNewWindow = useCallback((d: BlurbyDoc) => window.electronAPI.openReaderWindow(d.id), []);

  const handleLaunchToggle = async () => {
    const next = !launchAtLogin;
    await api.setLaunchAtLogin(next);
    setLaunchAtLogin(next);
  };

  const handleExport = async () => {
    const path = await api.exportLibrary();
    if (path) alert(`Exported to ${path}`);
  };

  const handleImport = async () => {
    const result = await api.importLibrary();
    if (result?.error) alert(result.error);
    else if (result) alert(`Imported ${result.added} new document${result.added !== 1 ? "s" : ""}`);
  };

  return (
    <div className="library-container" id="main-content" role="main" aria-label="Library">
      <div className={`library-titlebar ${isMac ? "library-titlebar--mac" : "library-titlebar--win"}`} />

      {loadingContent && (
        <div className="library-loading" role="status">
          <span className="library-loading-text">Loading...</span>
        </div>
      )}

      {toast && (
        <div className="toast" role="status" aria-live="polite">
          <span>{toast.message}</span>
          {toast.action && (
            <button className="toast-action" onClick={toast.action.onClick}>
              {toast.action.label}
            </button>
          )}
        </div>
      )}

      {updateReady && (
        <div className="update-banner" role="alert">
          <span>Blurby {updateReady} ready to install</span>
          <button onClick={() => api.installUpdate()} className="btn-fill update-banner-restart-btn">restart</button>
        </div>
      )}

      <div className="library-scroll">
        {/* Sticky top section: header + filter tabs + divider line */}
        <div className="library-sticky-top">
        <div className="library-header">
          <div className="library-header-left">
            <button className="hamburger-btn library-hamburger-btn" onClick={handleToggleFlapWithSeen} aria-label="Open menu" title="Menu (Tab)">
              <img src={blurbyIcon} alt="" width="48" height="48" className="library-hamburger-icon" aria-hidden="true" />
            </button>
            <div>
              {editFolder ? (
                <input
                  autoFocus value={folderName}
                  onChange={(e) => onSetFolderName(e.target.value)}
                  onBlur={() => setEditFolder(false)}
                  onKeyDown={(e) => e.key === "Enter" && setEditFolder(false)}
                  className="library-folder-input"
                  aria-label="Library name"
                />
              ) : (
                <h1
                  onClick={() => setEditFolder(true)}
                  className="library-folder-title"
                  title="Click to rename"
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => e.key === "Enter" && setEditFolder(true)}
                >{folderName}</h1>
              )}
              <p className="library-stats">
                {activeLibrary.length} {activeLibrary.length === 1 ? "reading" : "readings"}
                {totalWords > 0 && <> · {formatTime(totalWords, wpm)} total at {wpm} wpm</>}
                {settings.sourceFolder && <> · <span className="library-folder-name">{settings.sourceFolder.split(/[/\\]/).pop()}</span></>}
              </p>
            </div>
          </div>
          <div className="library-actions">
            <CloudSyncIndicator onOpenSettings={() => onToggleFlap()} />
            <button
              className="btn"
              onClick={() => { triggerCoachHint("search"); setSearchFocused(true); }}
              aria-label="Search library"
              title="Search (/ key)"
            >
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
              </svg>
            </button>
            <button
              className="view-toggle-btn btn"
              title={settings.viewMode === "grid" ? "Switch to list view" : "Switch to grid view"}
              aria-label={settings.viewMode === "grid" ? "List view" : "Grid view"}
              onClick={() => onSettingsChange({ viewMode: settings.viewMode === "grid" ? "list" : "grid" })}
            >
              {settings.viewMode === "grid" ? (
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                  <line x1="8" y1="6" x2="21" y2="6" /><line x1="8" y1="12" x2="21" y2="12" /><line x1="8" y1="18" x2="21" y2="18" />
                  <line x1="3" y1="6" x2="3.01" y2="6" /><line x1="3" y1="12" x2="3.01" y2="12" /><line x1="3" y1="18" x2="3.01" y2="18" />
                </svg>
              ) : (
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                  <rect x="3" y="3" width="7" height="7" /><rect x="14" y="3" width="7" height="7" />
                  <rect x="3" y="14" width="7" height="7" /><rect x="14" y="14" width="7" height="7" />
                </svg>
              )}
            </button>
            <button onClick={() => setShowStats(!showStats)} className="btn" title="Reading stats" aria-label="Show reading statistics" aria-expanded={showStats}>
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="library-stats-icon" aria-hidden="true">
                <path d="M18 20V10" /><path d="M12 20V4" /><path d="M6 20v-6" />
              </svg>
            </button>
            <div className="library-folder-btn-wrap">
              <button onClick={() => setShowRecent(!showRecent)} className="btn" aria-label="Select folder" aria-expanded={showRecent}>
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="library-icon-btn-svg" aria-hidden="true">
                  <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
                </svg>
                folder
              </button>
              {showRecent && (
                <RecentFolders
                  recentFolders={settings.recentFolders}
                  currentFolder={settings.sourceFolder}
                  onSwitch={onSwitchFolder}
                  onBrowse={onSelectFolder}
                  onClose={() => setShowRecent(false)}
                />
              )}
            </div>
            <button
              onClick={handleRescan}
              disabled={!settings.sourceFolder || rescanning}
              className="btn"
              aria-label="Rescan folder"
              title="Rescan folder for new items and covers"
            >
              {rescanning ? "..." : "⟳"}
            </button>
            <button onClick={() => { setShowUrl(true); setUrlInput(""); setUrlError(""); }} className="btn" aria-label="Add from URL">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="library-icon-btn-svg" aria-hidden="true">
                <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
                <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
              </svg>
              url
            </button>
            <button onClick={() => { setShowAdd(true); setEditingId(null); setNewTitle(""); setNewText(""); }} className="btn-fill" aria-label="Add document">+ add</button>
          </div>
        </div>

        {/* Tabs + Sort row */}
        <div className="library-tabs-row">
        <div className="library-tabs" role="tablist">
          <button
            className={`library-tab${tab === "all" ? " library-tab-active" : ""}`}
            onClick={() => setTab("all")}
            role="tab"
            aria-selected={tab === "all"}
          >all ({activeLibrary.length})</button>
          <button
            className={`library-tab${tab === "new" ? " library-tab-active" : ""}`}
            onClick={() => setTab("new")}
            role="tab"
            aria-selected={tab === "new"}
          >new ({newCount})</button>
          <button
            className={`library-tab${tab === "favorites" ? " library-tab-active" : ""}`}
            onClick={() => setTab("favorites")}
            role="tab"
            aria-selected={tab === "favorites"}
          >favorites ({favCount})</button>
          <button
            className={`library-tab${tab === "archived" ? " library-tab-active" : ""}`}
            onClick={() => setTab("archived")}
            role="tab"
            aria-selected={tab === "archived"}
          >archived ({archivedCount})</button>
          <span className="library-tab-divider" aria-hidden="true" />
          <button
            className={`library-tab${typeFilter === "all" ? " library-tab-active" : ""}`}
            onClick={() => setTypeFilter("all")}
            role="tab"
            aria-selected={typeFilter === "all"}
          >all types</button>
          <button
            className={`library-tab${typeFilter === "articles" ? " library-tab-active" : ""}`}
            onClick={() => setTypeFilter("articles")}
            role="tab"
            aria-selected={typeFilter === "articles"}
          >articles ({articleCount})</button>
          <button
            className={`library-tab${typeFilter === "books" ? " library-tab-active" : ""}`}
            onClick={() => setTypeFilter("books")}
            role="tab"
            aria-selected={typeFilter === "books"}
          >books ({bookCount})</button>
          <button
            className={`library-tab${typeFilter === "pdfs" ? " library-tab-active" : ""}`}
            onClick={() => setTypeFilter("pdfs")}
            role="tab"
            aria-selected={typeFilter === "pdfs"}
          >PDFs ({pdfCount})</button>
        </div>
        {/* Sort dropdown removed from tabs row — now inline with "Not Started" section label */}
        </div>{/* close library-tabs-row */}
        </div>{/* close library-sticky-top */}

        {showStats && <StatsPanel wpm={wpm} onClose={() => setShowStats(false)} />}

        {/* Floating search input — appears when search icon clicked or / pressed */}
        {searchFocused && (
          <div className="library-search-floating">
            <input
              autoFocus
              placeholder="Search readings..."
              value={searchQuery}
              onChange={(e) => { setSearchQuery(e.target.value); setSearchIndex(-1); }}
              onBlur={() => setTimeout(() => { if (!searchQuery) setSearchFocused(false); }, SEARCH_BLUR_DELAY_MS)}
              onKeyDown={(e) => {
                if (e.key === "Escape") {
                  setSearchQuery("");
                  setSearchIndex(-1);
                  setSearchFocused(false);
                  return;
                }
                if (!searchQuery || searchResults.length === 0) return;
                if (e.key === "ArrowDown") {
                  e.preventDefault();
                  setSearchIndex((prev) => Math.min(prev + 1, searchResults.length - 1));
                } else if (e.key === "ArrowUp") {
                  e.preventDefault();
                  setSearchIndex((prev) => Math.max(prev - 1, -1));
                } else if (e.key === "Enter" && searchIndex >= 0) {
                  e.preventDefault();
                  handleOpenDocWithSeen(searchResults[searchIndex]);
                  setSearchQuery("");
                  setSearchIndex(-1);
                  setSearchFocused(false);
                }
              }}
              className="library-search"
              aria-label="Search library"
            />
            {searchQuery && (
              <div className="search-dropdown">
                {searchResults.length > 0 ? (
                  searchResults.map((doc, idx) => (
                    <div
                      key={doc.id}
                      className={`search-result-item${idx === searchIndex ? " search-result-active" : ""}`}
                      onMouseDown={() => { handleOpenDocWithSeen(doc); setSearchQuery(""); setSearchIndex(-1); setSearchFocused(false); }}
                    >
                      <span className="search-result-title">{formatDisplayTitle(doc.title)}</span>
                      {doc.author && <span className="search-result-author">{doc.author}</span>}
                      <span className="search-result-meta">{doc.ext?.slice(1) || doc.source}</span>
                    </div>
                  ))
                ) : (
                  <div className="search-result-empty">No results</div>
                )}
              </div>
            )}
          </div>
        )}

        {showUrl && (
          <div className="add-edit-panel">
            <div className="url-input-row">
              <input
                autoFocus placeholder="Paste article URL..."
                value={urlInput}
                onChange={(e) => { setUrlInput(e.target.value); setUrlError(""); }}
                onKeyDown={(e) => e.key === "Enter" && handleAddFromUrl()}
                className="library-search"
                aria-label="Article URL"
              />
              <button
                onClick={handleAddFromUrl}
                disabled={!urlInput.trim() || loadingContent}
                className="btn-fill url-fetch-btn"
                style={{ '--url-fetch-opacity': urlInput.trim() && !loadingContent ? 1 : 0.3 } as React.CSSProperties}
              >{loadingContent ? "fetching..." : "fetch"}</button>
              <button onClick={() => { setShowUrl(false); setUrlError(""); }} className="btn">cancel</button>
            </div>
            {urlError && <div className="url-error" role="alert">{urlError}</div>}
          </div>
        )}

        {showAdd && (
          <AddEditPanel
            newTitle={newTitle} newText={newText} editingId={editingId}
            onTitleChange={setNewTitle} onTextChange={setNewText}
            onSave={handleAddDoc}
            onCancel={() => { setShowAdd(false); setEditingId(null); setEditMetaMode(false); }}
            metaMode={editMetaMode}
            newAuthor={newAuthor}
            onAuthorChange={setNewAuthor}
          />
        )}

        {/* Empty states per tab */}
        {filteredLibrary.length === 0 && !showAdd && (
          <div className="library-empty">
            {tab === "all" && (
              <>
                <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" className="library-empty-icon" aria-hidden="true">
                  <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" /><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" />
                </svg>
                <p className="library-empty-title">Your library is empty</p>
                <p className="library-empty-subtitle">Pick a source folder, drop files, or add text manually</p>
              </>
            )}
            {tab === "favorites" && <p className="library-empty-hint">No favorites yet — star documents to see them here</p>}
            {tab === "archived" && <p className="library-empty-hint">No archived documents — completed readings auto-archive here</p>}
          </div>
        )}

        {/* Document list / grid — sectioned by Reading Now / Not Started */}
        {settings.viewMode === "grid" ? (
          <>
            {readingNow.length > 0 && (
              <>
                <div className="library-section-label">Reading Now</div>
                <div className={gridClassName} role="list">
                  {readingNow.map((doc) => (
                    <DocGridCard key={doc.id} doc={doc} onOpen={handleOpenDocWithSeen} onToggleFavorite={onToggleFavorite} onArchive={onArchiveDoc} onDelete={onDeleteDoc}
                      onResetProgress={onResetProgress}
                      onEditMetadata={startEdit}
                      focused={focusedDocId === doc.id}
                      selected={selectedIds?.has(doc.id) || false}
                      selectionMode={selectionMode}
                      onToggleSelect={onToggleSelect}
                    />
                  ))}
                </div>
              </>
            )}
            {notStarted.length > 0 && (
              <>
                <div className="library-section-label library-section-label--flex">
                  <span>Not Started</span>
                  {notStarted.length > 1 && (
                    <select
                      className="sort-select"
                      value={sortBy}
                      onChange={(e) => setSortBy(e.target.value)}
                      aria-label="Sort not started"
                    >
                      <option value="author">A-Z by author</option>
                      <option value="alpha">A-Z by title</option>
                      <option value="newest">newest first</option>
                      <option value="oldest">oldest first</option>
                    </select>
                  )}
                </div>
                <div className={gridClassName} role="list">
                  {notStarted.map((doc) => (
                    <DocGridCard key={doc.id} doc={doc} onOpen={handleOpenDocWithSeen} onToggleFavorite={onToggleFavorite} onArchive={onArchiveDoc} onDelete={onDeleteDoc}
                      onResetProgress={onResetProgress}
                      onEditMetadata={startEdit}
                      focused={focusedDocId === doc.id}
                      selected={selectedIds?.has(doc.id) || false}
                      selectionMode={selectionMode}
                      onToggleSelect={onToggleSelect}
                    />
                  ))}
                </div>
              </>
            )}
          </>
        ) : (
          <>
            {readingNow.length > 0 && (
              <>
                <div className="library-section-label">Reading Now</div>
                <div className={listClassName} role="list">
                  {readingNow.map((doc) => (
                    <DocCard
                      key={doc.id} doc={doc} wpm={wpm} confirmDelete={confirmDelete}
                      onOpen={handleOpenDocWithSeen} onReset={onResetProgress} onEdit={startEdit}
                      onDelete={onDeleteDoc}
                      onConfirmDelete={setConfirmDelete}
                      onCancelDelete={handleCancelDelete}
                      onToggleFavorite={onToggleFavorite}
                      onArchive={onArchiveDoc}
                      onUnarchive={onUnarchiveDoc}
                      onOpenScroll={handleOpenScroll}
                      onOpenNewWindow={handleOpenNewWindow}
                      focused={focusedDocId === doc.id}
                      selected={selectedIds?.has(doc.id) || false}
                      selectionMode={selectionMode}
                      onToggleSelect={onToggleSelect}
                    />
                  ))}
                </div>
              </>
            )}
            {notStarted.length > 0 && (
              <>
                <div className="library-section-label library-section-label--flex">
                  <span>Not Started</span>
                  {notStarted.length > 1 && (
                    <select
                      className="sort-select"
                      value={sortBy}
                      onChange={(e) => setSortBy(e.target.value)}
                      aria-label="Sort not started"
                    >
                      <option value="author">A-Z by author</option>
                      <option value="alpha">A-Z by title</option>
                      <option value="newest">newest first</option>
                      <option value="oldest">oldest first</option>
                    </select>
                  )}
                </div>
                <div className={listClassName} role="list">
                  {notStarted.map((doc) => (
                    <DocCard
                      key={doc.id} doc={doc} wpm={wpm} confirmDelete={confirmDelete}
                      onOpen={handleOpenDocWithSeen} onReset={onResetProgress} onEdit={startEdit}
                      onDelete={onDeleteDoc}
                      onConfirmDelete={setConfirmDelete}
                      onCancelDelete={handleCancelDelete}
                      onToggleFavorite={onToggleFavorite}
                      onArchive={onArchiveDoc}
                      onUnarchive={onUnarchiveDoc}
                      onOpenScroll={handleOpenScroll}
                      onOpenNewWindow={handleOpenNewWindow}
                      focused={focusedDocId === doc.id}
                      selected={selectedIds?.has(doc.id) || false}
                      selectionMode={selectionMode}
                      onToggleSelect={onToggleSelect}
                    />
                  ))}
                </div>
              </>
            )}
          </>
        )}

        {/* Footer */}
        <div className="library-footer">
          <div className="library-speed">
            <span>speed</span>
            <input
              type="range" min={MIN_WPM} max={MAX_WPM} step={WPM_STEP} value={wpm}
              onChange={(e) => onSetWpm(Number(e.target.value))}
              className="library-speed-slider"
              aria-label="Reading speed"
            />
            <span className="library-speed-label">{wpm} wpm</span>
          </div>
          <div className="library-footer-actions">
            <label className="launch-toggle" title="Start Blurby when computer starts">
              <input
                type="checkbox"
                checked={launchAtLogin}
                onChange={handleLaunchToggle}
              />
              <span className="launch-toggle-label">start at login</span>
            </label>
            <button onClick={handleExport} className="btn library-change-folder" aria-label="Backup library">backup</button>
            <button onClick={handleImport} className="btn library-change-folder" aria-label="Restore library">restore</button>
            {settings.sourceFolder && (
              <button onClick={onSelectFolder} className="btn library-change-folder">change folder</button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
