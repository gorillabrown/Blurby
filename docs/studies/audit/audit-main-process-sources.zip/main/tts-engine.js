// main/tts-engine.js — Kokoro TTS engine (worker thread wrapper)
// All inference runs in a worker thread so the main Electron process never blocks.

const { Worker } = require("worker_threads");
const path = require("path");
const fs = require("fs/promises");
const { KOKORO_SAMPLE_RATE, TTS_IDLE_TIMEOUT_MS, TTS_MODEL_LOAD_TIMEOUT_MS } = require("./constants");

let worker = null;
let modelReady = false;
let loadingPromise = null;
let requestId = 0;
const pending = new Map(); // id → { resolve, reject }

// Progress/status callbacks
let onProgressCb = null;
let onLoadingCb = null;

const SAMPLE_RATE = KOKORO_SAMPLE_RATE;

// Idle unload timer — terminate worker after inactivity
let idleTimer = null;
const IDLE_TIMEOUT_MS = TTS_IDLE_TIMEOUT_MS;

function resetIdleTimer() {
  if (idleTimer) clearTimeout(idleTimer);
  idleTimer = setTimeout(() => {
    if (worker) {
      worker.terminate();
      worker = null;
      modelReady = false;
      loadingPromise = null;
    }
  }, IDLE_TIMEOUT_MS);
}

/** Notify renderer that Kokoro is loading (used after idle timeout re-warm). */
function sendLoadingSignal(loading) {
  if (onLoadingCb) onLoadingCb(loading);
  try {
    const { BrowserWindow } = require("electron");
    const win = BrowserWindow.getAllWindows()[0];
    if (win && !win.isDestroyed()) {
      win.webContents.send("tts-kokoro-loading", loading);
    }
  } catch { /* non-fatal */ }
}

function getWorker(cacheDir) {
  if (worker) return worker;
  const { app } = require("electron");
  const workerOpts = {};
  if (app.isPackaged) {
    // In packaged app, unpacked modules live in app.asar.unpacked/node_modules/
    const unpackedModules = path.join(process.resourcesPath, "app.asar.unpacked", "node_modules");
    workerOpts.workerData = { modulePath: unpackedModules };
    workerOpts.env = { ...process.env, NODE_PATH: unpackedModules };
  }
  worker = new Worker(path.join(__dirname, "tts-worker.js"), workerOpts);

  worker.on("message", (msg) => {
    switch (msg.type) {
      case "progress":
        if (onProgressCb) onProgressCb(msg.value);
        break;
      case "model-ready":
        modelReady = true;
        if (onLoadingCb) onLoadingCb(false);
        break;
      case "warm-up-done":
        // Model fully primed
        break;
      case "load-error":
        console.error("[kokoro] Worker load failed:", msg.error);
        if (msg.stack) console.error("[kokoro] Stack:", msg.stack);
        loadingPromise = null;
        // Forward error to renderer so UI can show it
        {
          const { BrowserWindow } = require("electron");
          const win = BrowserWindow.getAllWindows()[0];
          if (win && !win.isDestroyed()) {
            win.webContents.send("tts-kokoro-download-error", msg.error);
          }
        }
        break;
      case "result": {
        const p = pending.get(msg.id);
        if (p) {
          pending.delete(msg.id);
          if (msg.error) p.reject(new Error(msg.error));
          else p.resolve({ audio: msg.audio, sampleRate: msg.sampleRate, durationMs: msg.durationMs });
        }
        break;
      }
      case "voices": {
        const p = pending.get(msg.id);
        if (p) {
          pending.delete(msg.id);
          p.resolve(msg.voices || []);
        }
        break;
      }
    }
  });

  worker.on("error", (err) => {
    // Reject all pending requests
    for (const [id, p] of pending) {
      p.reject(err);
    }
    pending.clear();
    // Reset engine state so next call creates a fresh worker
    worker = null;
    modelReady = false;
    loadingPromise = null;
  });

  // Start loading model in the worker
  worker.postMessage({ type: "load", cacheDir });
  return worker;
}

/**
 * Ensure the worker is started and model is loading/loaded.
 * @param {(progress: number) => void} [onProgress]
 * @returns {Promise<void>}
 */
async function ensureReady(onProgress) {
  if (modelReady) { resetIdleTimer(); return; }
  if (loadingPromise) return loadingPromise;

  onProgressCb = onProgress || null;

  try {
    const { app } = require("electron");
    const cacheDir = path.join(app.getPath("userData"), "models");
    await fs.mkdir(cacheDir, { recursive: true });

    const w = getWorker(cacheDir);

    // Wait for model-ready message or timeout — whichever comes first
    loadingPromise = Promise.race([
      new Promise((resolve) => {
        const handler = (msg) => {
          if (msg.type === "model-ready") {
            w.off("message", handler);
            resolve();
          }
        };
        w.on("message", handler);
      }),
      new Promise((_, reject) => {
        setTimeout(() => reject(new Error("Kokoro model load timed out")), TTS_MODEL_LOAD_TIMEOUT_MS);
      }),
    ]);

    await loadingPromise;
  } catch (err) {
    loadingPromise = null;
    throw err;
  }
}

/**
 * Generate speech audio for text. Runs in worker thread — never blocks main.
 */
async function generate(text, voice = "af_bella", speed = 1.0) {
  if (!modelReady) {
    sendLoadingSignal(true);
    await ensureReady();
    sendLoadingSignal(false);
  }
  resetIdleTimer();

  const id = ++requestId;
  return new Promise((resolve, reject) => {
    pending.set(id, { resolve, reject });
    worker.postMessage({ type: "generate", id, text, voice, speed });
  });
}

/**
 * List available Kokoro voices.
 */
async function listVoices() {
  if (!modelReady) await ensureReady();
  const id = ++requestId;
  return new Promise((resolve, reject) => {
    pending.set(id, { resolve, reject });
    worker.postMessage({ type: "list-voices", id });
  });
}

function isModelReady() { return modelReady; }

async function downloadModel(onProgress) {
  await ensureReady(onProgress);
}

/**
 * Pre-load model (call when reader opens, before user hits N).
 */
async function preload() {
  try { await ensureReady(); } catch { /* non-fatal */ }
}

/**
 * Set loading state callback (for UI notification).
 */
function setLoadingCallback(cb) { onLoadingCb = cb; }

module.exports = { generate, listVoices, isModelReady, downloadModel, preload, setLoadingCallback, SAMPLE_RATE };
