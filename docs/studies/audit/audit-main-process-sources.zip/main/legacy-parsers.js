// main/legacy-parsers.js — Legacy plain-text extraction fallback
// CommonJS only — Electron main process
/** @deprecated Legacy text extraction. New docs use epub-converter.js. Kept for pre-conversion backward compatibility. */

const path = require("path");
const fsPromises = require("fs/promises");
const {
  PDF_PARSE_TIMEOUT_MS,
  MIN_PRINTABLE_RATIO,
  MIN_TEXT_LENGTH,
  MAX_MOBI_TEXT_BYTES,
  EPUB_HEADING_MAX_LENGTH,
  EPUB_CHAPTER_CACHE_MAX,
} = require("./constants");

// ── Lazy-loaded heavy modules (cached after first require) ─────────────────
let _cheerio, _admZip, _pdfParse, _canvas;
function getCheerio() { if (!_cheerio) { _cheerio = require("cheerio"); } return _cheerio; }
function getAdmZip() { if (!_admZip) { _admZip = require("adm-zip"); } return _admZip; }
function getPDFParse() { if (!_pdfParse) { _pdfParse = require("pdf-parse"); } return _pdfParse; }
function getCanvas() { if (!_canvas) { try { _canvas = require("@napi-rs/canvas"); } catch { _canvas = null; } } return _canvas; }

// ── MOBI/PDB helpers (needed by extractContent) ───────────────────────────

function palmDocDecompress(data) {
  let output = Buffer.alloc(4096 * 2);
  let pos = 0;

  function ensureCapacity(need) {
    if (pos + need > output.length) {
      const newBuf = Buffer.alloc(Math.max(output.length * 2, pos + need));
      output.copy(newBuf);
      output = newBuf;
    }
  }

  let i = 0;
  while (i < data.length) {
    const byte = data[i++];
    if (byte === 0) {
      ensureCapacity(1);
      output[pos++] = 0;
    } else if (byte >= 1 && byte <= 8) {
      ensureCapacity(byte);
      for (let j = 0; j < byte && i < data.length; j++) {
        output[pos++] = data[i++];
      }
    } else if (byte >= 9 && byte <= 0x7f) {
      ensureCapacity(1);
      output[pos++] = byte;
    } else if (byte >= 0xc0) {
      ensureCapacity(2);
      output[pos++] = 0x20; // space
      output[pos++] = byte ^ 0x80;
    } else {
      // byte 0x80-0xBF: LZ77 back-reference
      if (i >= data.length) break;
      const next = data[i++];
      const distance = ((byte << 8) | next) >> 3 & 0x7ff;
      const length = (next & 0x07) + 3;
      ensureCapacity(length);
      for (let j = 0; j < length; j++) {
        const srcPos = pos - distance;
        output[pos++] = srcPos >= 0 ? output[srcPos] : 0;
      }
    }
  }
  return output.slice(0, pos).toString("utf-8");
}

function parseMobiContent(buffer) {
  try {
    if (buffer.length < 78) return null;
    const numRecords = buffer.readUInt16BE(76);
    if (numRecords < 2) return null;

    const recordOffsets = [];
    for (let i = 0; i < numRecords; i++) {
      const offset = buffer.readUInt32BE(78 + i * 8);
      recordOffsets.push(offset);
    }

    const rec0Start = recordOffsets[0];
    if (rec0Start + 16 > buffer.length) return null;

    const compression = buffer.readUInt16BE(rec0Start);
    const textRecordCount = buffer.readUInt16BE(rec0Start + 8);

    const encryption = buffer.readUInt16BE(rec0Start + 12);
    if (encryption !== 0) {
      console.log("MOBI file is DRM-encrypted, cannot extract text");
      return null;
    }

    if (compression === 17480) {
      console.log("MOBI file uses HUFF/CDIC compression (unsupported)");
      return null;
    }

    const maxTextBytes = MAX_MOBI_TEXT_BYTES;

    const textParts = [];
    let totalBytes = 0;
    for (let i = 1; i <= textRecordCount && i < numRecords; i++) {
      const start = recordOffsets[i];
      const end = (i + 1 < numRecords) ? recordOffsets[i + 1] : buffer.length;
      if (start >= buffer.length || end > buffer.length || start >= end) continue;
      const recordData = buffer.slice(start, end);

      if (compression === 1) {
        textParts.push(recordData.toString("utf-8"));
      } else if (compression === 2) {
        textParts.push(palmDocDecompress(recordData));
      } else {
        textParts.push(recordData.toString("utf-8"));
      }
      totalBytes += (textParts[textParts.length - 1] || "").length;
      if (totalBytes > maxTextBytes) break;
    }

    const html = textParts.join("");
    let text = html
      .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, "")
      .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, "")
      .replace(/<head[^>]*>[\s\S]*?<\/head>/gi, "")
      .replace(/<br\s*\/?>/gi, "\n")
      .replace(/<\/p>/gi, "\n\n")
      .replace(/<\/div>/gi, "\n")
      .replace(/<\/h[1-6]>/gi, "\n\n")
      .replace(/<[^>]+>/g, "")
      .replace(/&nbsp;/gi, " ")
      .replace(/&amp;/gi, "&")
      .replace(/&lt;/gi, "<")
      .replace(/&gt;/gi, ">")
      .replace(/&quot;/gi, '"')
      .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n)))
      .replace(/\r\n/g, "\n")
      .replace(/ {2,}/g, " ")
      .replace(/\n{3,}/g, "\n\n")
      .trim();
    return text || null;
  } catch (err) {
    console.error("MOBI parse error:", err.message);
    return null;
  }
}

// ── EPUB chapter cache (local to this module) ─────────────────────────────
const epubChapterCache = new Map();

function epubChapterCacheSet(key, value) {
  if (epubChapterCache.has(key)) epubChapterCache.delete(key);
  epubChapterCache.set(key, value);
  if (epubChapterCache.size > EPUB_CHAPTER_CACHE_MAX) {
    const oldest = epubChapterCache.keys().next().value;
    epubChapterCache.delete(oldest);
  }
}

// ── Plain-text fallback ───────────────────────────────────────────────────
async function readFileContentAsync(filepath) {
  try { return await fsPromises.readFile(filepath, "utf-8"); } catch { return null; }
}

/**
 * @deprecated Use epub-converter.js convertToEpub() for new imports. This function remains for pre-conversion docs loaded via load-doc-content.
 *
 * Extract plain text content from a file. Supports PDF, EPUB, MOBI/AZW3, HTML, and plain text.
 * Returns a string on success, { userError } on user-facing failures, or null on empty/unreadable files.
 */
async function extractContent(filepath) {
  const ext = path.extname(filepath).toLowerCase();
  try {
    if (ext === ".pdf") {
      if (!globalThis.DOMMatrix) {
        try {
          const canvas = getCanvas();
          if (canvas) {
            globalThis.DOMMatrix = canvas.DOMMatrix;
            globalThis.ImageData = canvas.ImageData;
            globalThis.Path2D = canvas.Path2D;
          } else { throw new Error("canvas not available"); }
        } catch (canvasErr) {
          console.log("Note: @napi-rs/canvas not available, using polyfills for PDF parsing. Run 'npm rebuild @napi-rs/canvas' if PDF extraction has issues.");
          globalThis.DOMMatrix = globalThis.DOMMatrix || class DOMMatrix { constructor() { this.a=1;this.b=0;this.c=0;this.d=1;this.e=0;this.f=0; } };
          globalThis.ImageData = globalThis.ImageData || class ImageData { constructor(w,h) { this.width=w;this.height=h;this.data=new Uint8ClampedArray(w*h*4); } };
          globalThis.Path2D = globalThis.Path2D || class Path2D { };
        }
      }
      const { PDFParse } = getPDFParse();
      const buffer = await fsPromises.readFile(filepath);
      const parser = new PDFParse({ data: new Uint8Array(buffer) });
      let timeoutId;
      const timeout = new Promise((_, reject) => {
        timeoutId = setTimeout(() => reject(new Error("PDF parse timeout")), PDF_PARSE_TIMEOUT_MS);
      });
      try {
        const result = await Promise.race([parser.getText({ pageJoiner: "\n\n" }), timeout]);
        clearTimeout(timeoutId);
        const text = result.text || "";
        const printableRatio = text.replace(/[\x00-\x1f\x7f-\x9f]/g, "").length / (text.length || 1);
        if (printableRatio < MIN_PRINTABLE_RATIO || text.length < MIN_TEXT_LENGTH) {
          console.log(`PDF extraction yielded non-text content for ${filepath} (${Math.round(printableRatio*100)}% printable)`);
          return { userError: "Could not read this PDF — it may be image-based or contain no selectable text." };
        }
        return text;
      } catch (err) {
        clearTimeout(timeoutId);
        const isEncrypted = err.message && (err.message.toLowerCase().includes("encrypt") || err.message.toLowerCase().includes("password"));
        const isTimeout = err.message && err.message.includes("timeout");
        const userMessage = isEncrypted
          ? "Could not read this PDF — the file is encrypted or password-protected."
          : isTimeout
            ? "Could not read this PDF — it timed out. The file may be very large or corrupted."
            : "Could not read this PDF — the file may be encrypted or corrupted.";
        console.error(`PDF extraction failed for ${filepath}:`, err.message);
        return { userError: userMessage };
      } finally {
        try { await parser.destroy(); } catch { /* Best-effort cleanup */ }
      }
    }
    if (ext === ".epub") {
      let zip;
      try {
        const AdmZip = getAdmZip();
        zip = new AdmZip(filepath);
      } catch (err) {
        const msg = err.message || "";
        const userMessage = msg.toLowerCase().includes("invalid") || msg.toLowerCase().includes("zip")
          ? "Could not open this EPUB — the file appears to be a corrupted ZIP archive."
          : "Could not open this EPUB — the file may be corrupted.";
        console.error(`EPUB ZIP open failed for ${filepath}:`, msg);
        return { userError: userMessage };
      }
      const AdmZip = getAdmZip();
      const cheerio = getCheerio();
      const entries = zip.getEntries();
      const containerEntry = entries.find((e) => e.entryName.endsWith("container.xml"));
      let opfPath = "";
      if (containerEntry) {
        const $ = cheerio.load(containerEntry.getData().toString("utf-8"), { xmlMode: true });
        opfPath = $("rootfile").attr("full-path") || "";
      }
      const opfEntry = entries.find((e) => e.entryName === opfPath);
      if (!opfEntry) {
        const userMessage = opfPath
          ? `Could not open this EPUB — the content manifest (${opfPath}) is missing or invalid.`
          : "Could not open this EPUB — missing content.opf (the file structure is invalid).";
        console.error(`EPUB missing OPF for ${filepath}: opfPath=${opfPath || "(none)"}`);
        return { userError: userMessage };
      }
      const spineIds = [];
      const manifestMap = new Map();
      const hrefToId = new Map();
      let tocHref = null;
      let ncxHref = null;
      if (opfEntry) {
        const opfDir = opfPath.includes("/") ? opfPath.substring(0, opfPath.lastIndexOf("/") + 1) : "";
        const $ = cheerio.load(opfEntry.getData().toString("utf-8"), { xmlMode: true });
        $("manifest item").each((_, el) => {
          const id = $(el).attr("id");
          const href = $(el).attr("href");
          const mediaType = $(el).attr("media-type") || "";
          if (id && href) {
            const fullHref = opfDir + href;
            manifestMap.set(id, fullHref);
            hrefToId.set(fullHref, id);
            if ($(el).attr("properties")?.includes("nav")) tocHref = fullHref;
            if (mediaType === "application/x-dtbncx+xml") ncxHref = fullHref;
          }
        });
        $("spine itemref").each((_, el) => {
          const idref = $(el).attr("idref");
          if (idref) spineIds.push(idref);
        });
        const spineToc = $("spine").attr("toc");
        if (spineToc && !ncxHref) ncxHref = manifestMap.get(spineToc);
      }

      const tocMap = new Map();
      try {
        if (tocHref) {
          const navEntry = entries.find((e) => e.entryName === tocHref);
          if (navEntry) {
            const navDir = tocHref.includes("/") ? tocHref.substring(0, tocHref.lastIndexOf("/") + 1) : "";
            const $ = cheerio.load(navEntry.getData().toString("utf-8"));
            $('nav[*|type="toc"] a, nav#toc a, nav.toc a').each((_, el) => {
              const href = $(el).attr("href");
              const title = $(el).text().trim();
              if (href && title) {
                const fullHref = navDir + href.split("#")[0];
                tocMap.set(fullHref, title);
              }
            });
          }
        }
        if (tocMap.size === 0 && ncxHref) {
          const ncxEntry = entries.find((e) => e.entryName === ncxHref);
          if (ncxEntry) {
            const ncxDir = ncxHref.includes("/") ? ncxHref.substring(0, ncxHref.lastIndexOf("/") + 1) : "";
            const $ = cheerio.load(ncxEntry.getData().toString("utf-8"), { xmlMode: true });
            $("navPoint").each((_, el) => {
              const title = $(el).find("> navLabel > text").first().text().trim();
              const src = $(el).find("> content").attr("src");
              if (title && src) {
                const fullSrc = ncxDir + src.split("#")[0];
                tocMap.set(fullSrc, title);
              }
            });
          }
        }
      } catch (tocErr) {
        if (!tocErr.message?.includes("Namespaced attributes")) {
          console.log("EPUB TOC parse error (non-fatal):", tocErr.message);
        }
      }

      const texts = [];
      const chapters = [];
      let charOffset = 0;
      const processedPaths = new Set();
      for (const id of spineIds) {
        const href = manifestMap.get(id);
        if (!href) continue;
        const entry = entries.find((e) => e.entryName === href);
        if (!entry || processedPaths.has(href)) continue;
        processedPaths.add(href);
        const $ = cheerio.load(entry.getData().toString("utf-8"));
        $("script, style").remove();
        $(".pb, .pagebreak, [role='doc-pagebreak'], [epub\\:type='pagebreak']").remove();
        $("p, div, h1, h2, h3, h4, h5, h6, br, li, blockquote, tr, dt, dd, figcaption, section, article").each((_, el) => {
          $(el).before("\n");
          $(el).after("\n");
        });
        $("h1, h2, h3, h4, h5, h6").each((_, el) => {
          $(el).after("\n");
        });
        $("li").each((_, el) => {
          $(el).prepend("• ");
        });
        let text = $("body").text().trim();
        text = text.replace(/Edition:\s*current;\s*Page:\s*\[[^\]]*\]/g, "");
        text = text.replace(/\n{3,}/g, "\n\n").trim();
        if (!text) continue;

        const chapterTitle = tocMap.get(href);
        if (chapterTitle) {
          chapters.push({ title: chapterTitle, charOffset });
        } else {
          const heading = $("h1, h2").first().text().trim();
          if (heading && heading.length < EPUB_HEADING_MAX_LENGTH) {
            chapters.push({ title: heading, charOffset });
          }
        }

        texts.push(text);
        charOffset += text.length + 2;
      }

      const fullText = texts.join("\n\n") || null;
      if (fullText && chapters.length > 1) {
        epubChapterCacheSet(filepath, chapters);
      }
      return fullText;
    }
    if (ext === ".mobi" || ext === ".azw3" || ext === ".azw") {
      const buffer = await fsPromises.readFile(filepath);
      const text = parseMobiContent(buffer);
      if (text && text.length > MIN_TEXT_LENGTH) return text;
      return null;
    }
    if (ext === ".html" || ext === ".htm") {
      const html = await fsPromises.readFile(filepath, "utf-8");
      const cheerio = getCheerio();
      const $ = cheerio.load(html);
      $("script, style, nav, footer, header, aside").remove();
      $("p, div, h1, h2, h3, h4, h5, h6, br, li, blockquote, tr, dt, dd, section, article").each((_, el) => {
        $(el).before("\n"); $(el).after("\n");
      });
      $("h1, h2, h3, h4, h5, h6").each((_, el) => { $(el).after("\n"); });
      $("li").each((_, el) => { $(el).prepend("• "); });
      let htmlText = $("body").text().trim() || $.text().trim() || null;
      if (htmlText) htmlText = htmlText.replace(/\n{3,}/g, "\n\n").trim();
      return htmlText;
    }
    // Plain text formats
    return await readFileContentAsync(filepath);
  } catch (err) {
    console.log(`Content extraction failed for ${filepath}, falling back to plain text:`, err.message);
    const ext2 = path.extname(filepath).toLowerCase();
    if (ext2 === ".pdf" || ext2 === ".epub") {
      return { userError: "Could not read this file — it may be corrupted or in an unsupported format." };
    }
    return await readFileContentAsync(filepath);
  }
}

module.exports = { extractContent };
