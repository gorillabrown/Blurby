import type { TtsEngine } from "../types";
import type { TTSProvider } from "../types/ttsProvider";

export const TTS_PROVIDER_IDS = ["web", "kokoro", "qwen", "nano", "pocket-tts"] as const satisfies readonly TtsEngine[];

const PROVIDERS = [
  {
    id: "web",
    capabilities: {
      id: "web",
      label: "System",
      selectable: true,
      defaultEngine: false,
      experimental: false,
      disabledReason: null,
      offline: false,
      requiresSidecar: false,
      canStream: false,
      providesWordTimings: false,
      emitsWordBoundaryEvents: false,
      timingTruth: "unreliable-boundary",
      canBlendVoices: false,
      supportsVoiceCloning: false,
      supportedLanguages: [],
      sampleRate: null,
      license: "platform",
      cacheable: false,
      statusKind: "browser",
    },
    copy: {
      buttonLabel: "System",
      posture: "System voices remain available as a fallback/reach layer, but boundary events are not timing truth.",
      readyHint: "Using system Web Speech voices.",
      blockedHint: "System voice availability depends on the host browser/runtime.",
    },
  },
  {
    id: "kokoro",
    capabilities: {
      id: "kokoro",
      label: "Kokoro",
      selectable: true,
      defaultEngine: true,
      experimental: false,
      disabledReason: null,
      offline: true,
      requiresSidecar: false,
      canStream: false,
      providesWordTimings: true,
      emitsWordBoundaryEvents: true,
      timingTruth: "word-native",
      canBlendVoices: false,
      supportsVoiceCloning: false,
      supportedLanguages: ["en"],
      sampleRate: 24000,
      license: "model-specific",
      cacheable: true,
      statusKind: "local-model",
    },
    copy: {
      buttonLabel: "Kokoro (Default)",
      posture: "Kokoro is the default and operational floor.",
      readyHint: "Using default Kokoro voices.",
      blockedHint: "Kokoro needs local model, tokenizer, config, and voice assets before playback.",
    },
  },
  {
    id: "qwen",
    capabilities: {
      id: "qwen",
      label: "Qwen AI",
      selectable: false,
      defaultEngine: false,
      experimental: true,
      disabledReason: "retired-desktop-v2",
      offline: true,
      requiresSidecar: true,
      canStream: true,
      providesWordTimings: false,
      emitsWordBoundaryEvents: false,
      timingTruth: "none",
      canBlendVoices: false,
      supportsVoiceCloning: false,
      supportedLanguages: [],
      sampleRate: 24000,
      license: "model-specific",
      cacheable: false,
      statusKind: "disabled",
    },
    copy: {
      buttonLabel: "Qwen AI (Retired)",
      posture: "Qwen is retired for Desktop v2 and remains disabled.",
      readyHint: "Qwen is disabled and should not be used for live narration.",
      blockedHint: "Qwen remains disabled unless a separate future approval reactivates it.",
    },
  },
  {
    id: "nano",
    capabilities: {
      id: "nano",
      label: "MOSS-Nano",
      selectable: false,
      defaultEngine: false,
      experimental: true,
      disabledReason: "engine-dormant",
      offline: true,
      requiresSidecar: true,
      canStream: false,
      providesWordTimings: false,
      emitsWordBoundaryEvents: false,
      timingTruth: "segment-following",
      canBlendVoices: false,
      supportsVoiceCloning: false,
      supportedLanguages: ["en"],
      sampleRate: 24000,
      license: "model-specific",
      cacheable: true,
      statusKind: "disabled",
    },
    copy: {
      buttonLabel: "MOSS-Nano (Dormant)",
      posture: "MOSS-Nano is dormant for this Kokoro-focused architecture phase and remains disabled at the settings boundary.",
      readyHint: "MOSS-Nano is dormant and unavailable for live narration.",
      blockedHint: "Reactivation requires explicitly changing provider registry posture and re-enabling settings selection.",
    },
  },
  {
    id: "pocket-tts",
    capabilities: {
      id: "pocket-tts",
      label: "Pocket TTS",
      selectable: false,
      defaultEngine: false,
      experimental: true,
      disabledReason: "engine-dormant",
      offline: true,
      requiresSidecar: true,
      canStream: false,
      providesWordTimings: false,
      emitsWordBoundaryEvents: false,
      timingTruth: "segment-following",
      canBlendVoices: false,
      supportsVoiceCloning: true,
      supportedLanguages: ["en"],
      sampleRate: 24000,
      license: "model-specific",
      cacheable: true,
      statusKind: "disabled",
    },
    copy: {
      buttonLabel: "Pocket TTS (Dormant)",
      posture: "Pocket TTS is dormant for this Kokoro-focused architecture phase and remains disabled at the settings boundary.",
      readyHint: "Pocket TTS is dormant and unavailable for live narration.",
      blockedHint: "Reactivation requires explicitly changing provider registry posture and re-enabling settings selection.",
    },
  },
] as const satisfies readonly TTSProvider[];

const PROVIDER_BY_ID = new Map<TtsEngine, TTSProvider>(
  PROVIDERS.map((provider) => [provider.id, provider]),
);

export function listTtsProviders(): readonly TTSProvider[] {
  return PROVIDERS;
}

export function listSelectableTtsProviders(): readonly TTSProvider[] {
  return PROVIDERS.filter((provider) => provider.capabilities.selectable);
}

export function getTtsProvider(id: TtsEngine): TTSProvider | undefined {
  return PROVIDER_BY_ID.get(id);
}

export function getTtsProviderOrThrow(id: TtsEngine): TTSProvider {
  const provider = getTtsProvider(id);
  if (!provider) throw new Error(`Unknown TTS provider: ${id}`);
  return provider;
}

export function getTtsProviderRegistrySnapshot() {
  const providers = PROVIDERS.reduce((acc, provider) => {
    acc[provider.id] = provider;
    return acc;
  }, {} as Record<TtsEngine, TTSProvider>);

  return {
    defaultProviderId: PROVIDERS.find((provider) => provider.capabilities.defaultEngine)?.id ?? null,
    providers,
  };
}
