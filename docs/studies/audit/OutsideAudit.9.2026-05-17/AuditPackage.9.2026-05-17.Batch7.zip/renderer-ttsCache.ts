// src/utils/ttsCache.ts — Renderer-side TTS cache interface (NAR-2)
//
// Thin wrapper over the IPC cache API. Reads cached PCM chunks from disk
// via main process, provides them as ScheduledChunk objects ready for the
// audio scheduler.

import type { ScheduledChunk } from "./audioScheduler";
import {
  classifyTiming,
  type TtsCacheIdentity,
  type TtsCacheIdentityV2,
  type TtsCacheWriteTimingMetadata,
} from "../types/ttsCache";

const api = window.electronAPI;

const BOUNDARY_TYPES = new Set<NonNullable<ScheduledChunk["boundaryType"]>>([
  "comma",
  "clause",
  "sentence",
  "paragraph",
  "none",
]);

function asBoundaryType(value: unknown): ScheduledChunk["boundaryType"] | undefined {
  if (typeof value !== "string") return undefined;
  return BOUNDARY_TYPES.has(value as NonNullable<ScheduledChunk["boundaryType"]>)
    ? (value as NonNullable<ScheduledChunk["boundaryType"]>)
    : undefined;
}

function isStructuredIdentity(identity: TtsCacheIdentity): identity is TtsCacheIdentityV2 {
  return typeof identity === "object"
    && identity !== null
    && (identity as TtsCacheIdentityV2).schemaVersion === 2;
}

/**
 * Check if a chunk is cached on disk.
 */
export async function isCached(bookId: string, voiceId: TtsCacheIdentity, startIdx: number): Promise<boolean> {
  if (!api?.ttsCacheHas) return false;
  return api.ttsCacheHas(bookId, voiceId, startIdx);
}

/**
 * Load a cached chunk from disk and return it as a ScheduledChunk.
 * Uses the full word array plus startIdx to reconstruct the exact nonzero-start
 * span stored at cache-write time instead of relying on a caller-provided tail slice.
 * Returns null on cache miss or error.
 */
export async function loadCachedChunk(
  bookId: string,
  voiceId: TtsCacheIdentity,
  startIdx: number,
  allWords: string[],
): Promise<ScheduledChunk | null> {
  if (!api?.ttsCacheRead) return null;

  const result = await api.ttsCacheRead(bookId, voiceId, startIdx);
  if (!result || result.miss || result.error) return null;
  if (!result.audio || !result.sampleRate || !result.durationMs) return null;

  const audio = result.audio instanceof Float32Array
    ? result.audio
    : new Float32Array(result.audio);

  // TTS-7A: Use real word count from cache entry when available.
  // Fall back to the remaining full-context words for legacy entries without wordCount.
  const wordCount = result.wordCount ?? Math.max(0, allWords.length - startIdx);
  const chunkWords = allWords.slice(startIdx, startIdx + wordCount);
  const sidecarTiming = result.timing ?? null;
  const fallbackWordTimestamps = Array.isArray(result.wordTimestamps) ? result.wordTimestamps : null;
  const timingClassification = sidecarTiming
    ? classifyTiming({
      timingTruth: sidecarTiming.timingTruth,
      wordTimestamps: sidecarTiming.wordTimestamps ?? null,
      chunkStartIdx: sidecarTiming.chunkStartIdx,
      chunkEndIdx: sidecarTiming.chunkEndIdx,
    })
    : null;
  const trustedWordTimestamps = sidecarTiming
    ? (timingClassification === "trusted"
      ? (sidecarTiming.wordTimestamps ?? fallbackWordTimestamps)
      : null)
    : fallbackWordTimestamps;
  const cacheChunkId = isStructuredIdentity(voiceId)
    ? voiceId.chunkId
    : (sidecarTiming?.identityHash
      ? `cache:${sidecarTiming.identityHash}:${sidecarTiming.chunkStartIdx ?? startIdx}`
      : undefined);
  const timingTruth = sidecarTiming?.timingTruth ?? (trustedWordTimestamps ? "word-native" : undefined);

  return {
    audio,
    sampleRate: result.sampleRate,
    durationMs: result.durationMs,
    words: chunkWords,
    startIdx,
    wordTimestamps: trustedWordTimestamps ?? null,
    boundaryType: asBoundaryType(sidecarTiming?.boundaryType ?? undefined),
    timingTruth,
    chunkId: cacheChunkId,
  };
}

/**
 * Write a generated chunk to the disk cache (fire-and-forget).
 * TTS-7A: stores real wordCount so cache hits return correct metadata.
 */
export function cacheChunk(
  bookId: string,
  voiceId: TtsCacheIdentity,
  startIdx: number,
  audio: Float32Array,
  sampleRate: number,
  durationMs: number,
  wordCount?: number,
  timingMetadata?: TtsCacheWriteTimingMetadata,
): void {
  if (!api?.ttsCacheWrite) return;
  // TTS-7C: Pass Float32Array directly — Electron structured clone preserves typed arrays.
  // Previous Array.from() added ~2x allocation overhead on every cache write (BUG-113).
  api.ttsCacheWrite(bookId, voiceId, startIdx, audio, sampleRate, durationMs, wordCount ?? null, timingMetadata).catch(() => {});
}

/**
 * Get list of cached chunk start indices for a book+voice.
 */
export async function getCachedChunks(bookId: string, voiceId: TtsCacheIdentity): Promise<number[]> {
  if (!api?.ttsCacheChunks) return [];
  return api.ttsCacheChunks(bookId, voiceId);
}

/**
 * Evict all cache for a book (all voices).
 */
export async function evictBook(bookId: string): Promise<void> {
  if (!api?.ttsCacheEvictBook) return;
  await api.ttsCacheEvictBook(bookId);
}

/**
 * Evict cache for a specific book+voice.
 */
export async function evictBookVoice(bookId: string, voiceId: TtsCacheIdentity): Promise<void> {
  if (!api?.ttsCacheEvictVoice) return;
  await api.ttsCacheEvictVoice(bookId, voiceId);
}

/**
 * Get cache size info.
 */
export async function getCacheInfo(): Promise<{ totalBytes: number; totalMB: number; bookCount: number }> {
  if (!api?.ttsCacheInfo) return { totalBytes: 0, totalMB: 0, bookCount: 0 };
  return api.ttsCacheInfo();
}

/**
 * TTS-7F: Get opening cache coverage in milliseconds for a book+voice context.
 * Manifest-only — no PCM loads. Returns 0 if no cache exists.
 */
export async function getOpeningCoverageMs(bookId: string, voiceId: TtsCacheIdentity): Promise<number> {
  if (!(api as any)?.ttsCacheOpeningCoverage) return 0;
  const result = await (api as any).ttsCacheOpeningCoverage(bookId, voiceId);
  return result?.coverageMs ?? 0;
}
