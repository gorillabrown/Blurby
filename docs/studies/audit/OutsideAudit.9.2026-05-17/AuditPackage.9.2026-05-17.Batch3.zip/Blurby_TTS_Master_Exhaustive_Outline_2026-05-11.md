# Blurby TTS Reviews — Master Exhaustive Source-Aware Outline

**Generated:** 2026-05-11  
**Input set:** Four independent Blurby TTS literature/codebase review documents that cover the same topic from different reviewers.

## Source key

- **[A] Direct static/codebase review:** `Blurby_TTS_Literature_Codebase_Review_2026-05-11.md`
  - Treats Blurby as the baseline.
  - States that Blurby was inspected first and external repositories were reviewed as source artifacts, not superior designs.
  - Uses a comparison classification legend: already implemented well, implemented but weaker, partially implemented, missing, not applicable, should avoid.
  - Notes no runtime benchmark or live audio validation was performed.
- **[B] Compass / assumed-Blurby review:** `compass_artifact_wf-255c72a1-1de8-4397-b428-f463db0a63ab_text_markdown.md`
  - Starts with an important caveat: the primary Blurby repository was not retrievable; current-Blurby claims are explicitly `[Blurby-assumed]`.
  - Stronger than other documents in recommending Readest as a near-drop-in architectural template and in treating sentence-level sync as the production baseline.
  - Includes broader product-engine suggestions: Kokoro sidecar choices, MediaSource, two-engine quality swap, EPUB3 Media Overlay export, Edge/Piper/cloud provider options.
- **[C] Deep research report:** `deep-research-report.md`
  - Uses attached audit package docs, not direct current Blurby source, for current-architecture evidence.
  - Emphasizes segment-first/provider-agnostic architecture, sentence-level deterministic scheduling as baseline, and timing metadata separated from rendering.
  - More cautious about Kokoro timing proof and precise word-level promises.
- **[D] Cowork/direct v1.75.1 review:** `TTS_LITERATURE_REVIEW_2026-05-11.md`
  - Most detailed direct-code baseline: Blurby v1.75.1, POSTV2-ENGINE-1, Desktop v2.0 conveyor active.
  - Strongest assertion that Blurby is already best-in-cohort for live long-form narration.
  - Provides the richest gap matrix, proposed interfaces, test matrix, roadmap, and “do not recommend” list.

---

# 1. Consolidated thesis

## 1.1 Strong consensus

1. **Do not rewrite Blurby’s TTS architecture. Preserve and evolve it.**
   - [A] says the existing Kokoro path, Web Audio scheduler, timestamp patch, progressive generation, disk cache, and diagnostics are more production-oriented than most reviewed projects.
   - [C] says the best path is incremental refactor around deterministic segment identity, provider capabilities, scheduler, and timing metadata.
   - [D] says the current engine ⇄ pipeline ⇄ scheduler ⇄ strategy ⇄ hook decomposition is sound and recommended changes are thin abstractions, not rewrites.
   - [B] also recommends a phased roadmap rather than a rewrite, but because it did not access the repo, it requires Phase 0 audit first.

2. **Keep Kokoro as the primary/default or timing baseline.**
   - [A] keeps Kokoro as default and timing baseline due to existing integration, word timing, cacheability, offline operation, and tests.
   - [B] calls Kokoro the incumbent because it is CPU-viable, small enough, Apache-2.0, and exposes English timestamps.
   - [C] treats Kokoro as the best near-term local/offline fit, but wants measured timing validation before overpromising word-level reliability.
   - [D] says no reviewed engine beats Kokoro across quality + offline + timing metadata + packaging + license.

3. **Formalize provider abstraction.**
   - All four recommend a formal `TTSProvider` or provider/client abstraction.
   - Key additions: capability flags, status/health, fallback order, provider registry, model/license metadata, timing truth, and experimental gates.

4. **Adopt deterministic segment identity and text-layer separation.**
   - All four identify abogen’s deterministic chunk IDs and raw/display/normalized text separation as important.
   - [A] proposes `NarrationSegment` with stable ID, source offsets, original text, normalized text, normalizer version, word spans, provider compatibility flags, and structural kind.
   - [C] proposes `DocumentSegment` with locator, display text, source text, synthesis text, offsets, normalization version, and structural role.
   - [D] ties segment identity to cache correctness, timing metadata, and highlight sync.

5. **Add a `SegmentNormalizer`.**
   - [A] identifies normalization as partially implemented and recommends golden tests before expansion.
   - [B] recommends porting pdf-narrator’s `clean_pipeline` and `remove_overlap` to TypeScript.
   - [C] requires a pure, versioned, non-destructive normalization layer that preserves display/source text and applies pronunciation overrides there.
   - [D] calls text normalization the single biggest unrealized opportunity and recommends Coqui + abogen + pdf-narrator patterns.

6. **Add/persist timing metadata separately from audio chunks.**
   - [A] proposes durable `TimingMetadata` with provider/model/normalizer metadata, timing truth, word timestamps, drift, generated time, and version fields.
   - [B] calls `TimingMetadataStore` Blurby’s central differentiator and says no reviewed reader builds it explicitly.
   - [C] separates timing metadata from rendering and highlights provenance/confidence.
   - [D] formalizes `TimingMetadataStore` and recommends provider-capability-driven highlighting.

7. **Use external projects as donors, not replacements.**
   - RealtimeTTS: provider/engine contract, fallback orchestration, queue/backpressure, callbacks; do not embed Python/PyAudio runtime.
   - Readest: reader-oriented controller, Foliate/SSML/mark traversal, controls, media/session ideas; do not copy weaker audio scheduling or cloud dependencies uncritically.
   - abogen: deterministic chunk identity, normalization, pronunciation store, voice formulas, export/subtitle concepts; do not copy batch pipeline into live narration.
   - Sioyek: alignment/line-following and quality-swap ideas; do not copy shell-heavy scripts or platform TTS timing as core truth.
   - Coqui: text cleaners, model/license registry, model metadata; do not use as default embedded runtime.
   - pdf-narrator: extraction/OCR/TOC/normalization ideas; do not copy batch file-per-chapter generation or destructive live normalization.
   - ttsreader: Web Speech caveats, canary probe, content-hash prefetch; do not copy singleton/global implementation or rely on browser boundaries as truth.
   - Ultimate TTS Reader and Markor: mostly negative evidence.

## 1.2 Important differences between reviewers

1. **Blurby source access and confidence differ.**
   - [A] and [D] claim direct code review and detailed baseline knowledge.
   - [B] explicitly did not retrieve the Blurby repo and labels current-code claims `[Blurby-assumed]`.
   - [C] relies on attached audit package docs rather than direct current source and marks this as a risk/open question.

2. **Word-level vs sentence-level production baseline differs.**
   - [A] and [D] treat Blurby’s Kokoro word-level timing path as a current strength and something to preserve.
   - [B] and [C] are more conservative: sentence-level deterministic scheduling is the universal production baseline, with word-level as provider-dependent.
   - Resolution: keep Kokoro word-level mode where validated, but make timing truth explicit and degrade to sentence/segment modes where timing evidence is absent.

3. **Readest adoption intensity differs.**
   - [B] says adopt Readest’s architectural shape wholesale.
   - [A], [C], and [D] recommend selective adoption: TTS client/controller, Foliate traversal, preloading, media controls, and state patterns, but not Readest’s weaker audio element scheduling or Edge dependency.

4. **Web Speech assessment differs.**
   - [B] calls Web Speech a mandatory fallback and suggests universal desktop word-boundary availability.
   - [A] and [D] emphasize Web Speech boundary unreliability, especially for Google voices, and keep it fallback-only with low timing confidence.
   - Resolution: keep Web Speech as a fallback/reach layer, never primary timing authority.

5. **SSML internal representation differs.**
   - [B] and Readest-inspired sections favor foliate-js SSML marks heavily.
   - [D] explicitly says not to adopt SSML as Blurby’s internal segment payload; SSML can be export/provider format, but structured text + normalizer trace is cleaner internally.
   - Resolution: use SSML/marks as adapter/export artifacts; keep internal model structured and typed.

---

# 2. Source provenance and methodology outline

## 2.1 Source set reviewed across documents

1. Current Blurby / audit docs / task baseline.
2. `abogen-main` / denizsafak/abogen.
3. `RealtimeTTS-master` / KoljaB/RealtimeTTS.
4. `readest-main` / readest/readest.
5. `TTS-dev` / Coqui TTS.
6. `sioyek-development` / ahrm/sioyek.
7. `pdf-narrator-main` / mateogon/pdf-narrator.
8. `ttsreader-master` / RonenR/ttsreader.
9. `ultimate-tts-reader-master` / wisehackermonkey/ultimate-tts-reader.
10. `markor-master` / gsantner/markor.
11. User source list file: `Blurby. TTS Model Review.txt`.

## 2.2 Methodology elements to retain

1. Static review; no runtime live audio validation in [A].
2. Inventory pass then deep-code pass in [D].
3. Current Blurby baseline read directly in [D], including:
   - `main/tts-engine.js`
   - `main/ipc/tts.js`
   - `main/tts-cache.js`
   - `main/qwen-streaming-engine.js`
   - `main/tts-worker.js`
   - `main/moss-nano-engine.js`
   - `main/pocket-tts-engine.js`
   - `src/utils/audioScheduler.ts`
   - `src/utils/narrationPlanner.ts`
   - `src/utils/narrationContinuity.ts`
   - `src/hooks/useNarration.ts`
   - `src/hooks/narration/kokoroStrategy.ts`
   - `src/types/narration.ts`
   - `src/constants.ts`
   - `main/constants.js`
   - TTS-related tests, scripts, settings components, and package manifest.
4. [B] requires a one-day audit before implementation because current-code claims are assumed.
5. [C] requires reconciling audit-package claims against current source.

---

# 3. Current Blurby baseline inventory

## 3.1 Provider/model abstraction

1. Current state:
   - `TtsEngine` union plus strategy modules for `web`, `kokoro`, `qwen`, `nano`, and `pocket-tts`.
   - `TtsStrategy` exposes `speakChunk`, `stop`, `pause`, `resume` or equivalent strategy surface.
   - `useNarration` does much of the provider selection and orchestration.
2. Strengths:
   - Existing strategy boundary avoids total coupling.
   - Multiple engines can coexist.
   - Provider-specific status snapshots exist.
3. Weaknesses:
   - No first-class `TTSProviderRegistry`.
   - No central capability matrix.
   - Timing truth, health, lifecycle, readiness, UI settings, packaging, and fallback policies are distributed.
4. Recommended evolution:
   - Rename/formalize `TtsStrategy` as `TTSProvider`.
   - Add `ProviderCapabilities` per strategy.
   - Add registry singleton and filter/resolve logic.
   - Keep current Kokoro behavior unchanged during the wrapper migration.

## 3.2 Kokoro integration

1. Current state:
   - `kokoro-js` / ONNX-backed local pipeline.
   - Worker-thread inference in `main/tts-worker.js`, coordinated by `main/tts-engine.js`.
   - Packaged module resolution across asar boundary.
   - q4 quantized ONNX model in [D].
   - 24 kHz mono output in [D].
   - 28 voices with `af_bella` default in [D].
   - Warm-up/preflight readiness checks.
   - Fail-closed readiness: “model-loaded” is informational; “model-ready” is readiness gate.
   - Idle unload after five minutes in [D].
   - Crash retry/backoff in [D].
   - Patched `kokoro-js` exposes duration tensor / word timestamps.
   - Zero-copy Float32Array transfer in [A]/[D].
2. Strengths:
   - Main process avoids inference blocking.
   - Mature Electron integration.
   - Real word timing exists for Kokoro.
   - Strong default local path.
3. Weaknesses:
   - Patch maintenance risk against upstream `kokoro-js`.
   - Need regression tests around timing alignment drift.
   - Single voice loaded at a time and no voice blending in [D].
   - Kokoro JS port lacks some Python/misaki contraction/heteronym richness in [D].
4. Recommendation:
   - Keep as default/timing baseline.
   - Add regression tests, normalizer, timing metadata, and provider metadata.

## 3.3 MOSS Nano

1. Current state:
   - Real ONNX sidecar path.
   - Explicit opt-in / recommended opt-in.
   - Structured lifecycle and sidecar readiness gates.
   - Segment-following only.
   - `wordTimestamps: null`.
   - Does not fabricate word timing.
   - Owner tokens/lifecycle generation guard stale sidecar starts in [D].
2. Strengths:
   - Responsible gating.
   - Synthetic/unclassified audio rejected in real mode.
3. Weaknesses/blockers:
   - No word-level timing parity.
   - Large PCM-over-IPC concern from decision log.
   - Commercial/model license tracking still needed.
4. Recommendation:
   - Keep opt-in/non-default.
   - Do not claim word-following until native timings pass gates.
   - Consider probing whether timestamps can be exposed.

## 3.4 Pocket TTS

1. Current state:
   - Opt-in sidecar/engine wrapper and renderer strategy.
   - Real sidecar scaffold exists.
   - Real adapter not configured / `runtime-adapter-not-configured` in [A].
   - Reference WAV and voice catalog shape noted in [D].
2. Strengths:
   - Isolated from Kokoro/Nano/Qwen.
   - Does not overclaim readiness.
3. Weaknesses/blockers:
   - Actual synthesis adapter missing.
   - No word timing.
   - License and voice cloning posture need care.
4. Recommendation:
   - Keep opt-in/disabled until real adapter and provider gates exist.

## 3.5 Qwen streaming

1. Current state:
   - Disabled at selectable-engine and IPC boundaries per POSTV2-ENGINE-1.
   - Runtime returns `qwen-disabled` status/error.
   - Existing streaming sidecar infrastructure includes:
     - Binary-framed PCM protocol.
     - 4-byte little-endian length prefix.
     - Type byte + payload.
     - JSON control plane.
     - Monotonic frame parsing.
     - Stall detection.
     - Cancellation guards.
     - Crash recovery.
     - CUDA vs CPU timeout buckets in [D].
2. Strengths:
   - Reusable protocol for future GPU-resident streaming engines.
   - Well-engineered despite disabled posture.
3. Weaknesses/blockers:
   - Live CUDA validation never completed.
   - No proven timing metadata.
   - Heavy sidecar/GPU packaging.
4. Recommendation:
   - Keep disabled.
   - Do not delete infrastructure.
   - Reopen only after live metrics replace pending data in decision docs.

## 3.6 Experimental model gating

1. Current state:
   - Settings/profile boundary gate.
   - IPC runtime gate.
   - Nano/Pocket readiness gates.
   - Qwen disabled in constants and IPC.
   - Status sections exist for Kokoro, Nano, Pocket, Qwen.
2. Strengths:
   - Avoids silent promotion.
   - Evidence-first posture.
3. Weaknesses:
   - No formal `ExperimentalModelGate` module.
   - Gate criteria live partly in prose, docs, constants, settings hooks, and IPC.
4. Recommendation:
   - Formalize gate criteria and expose in provider metadata/UI.

## 3.7 Text segmentation

1. Current state:
   - `Intl.Segmenter` word spans.
   - Abbreviation-aware sentence boundary logic.
   - Rolling narration planner.
   - Progressive opening ramp.
   - Sentence snapping.
   - [D] says 400-word forward window, greedy sentence-snap tolerance, min chunk size of 10 words.
   - Boundary classification: comma, clause, sentence, paragraph, none.
   - Dialogue-aware pause tuning for short quote paragraphs.
2. Strengths:
   - Stronger than regex splitters.
   - Designed for live long-form streaming/pre-generation.
3. Weaknesses:
   - No first-class durable segment IDs with structural metadata.
   - Sentence-end detection lacks full language-specific cleaner pass.
4. Recommendation:
   - Keep planner.
   - Wrap in `DocumentSegmenter` / `NarrationSegment` model.
   - Add golden segmentation/normalization tests.

## 3.8 Text normalization

1. Current state:
   - `applyPronunciationOverrides` and `overrideHash` exist.
   - Overrides participate in cache identity.
   - Otherwise text reaches Kokoro with minimal normalization.
2. Missing per [D]:
   - Currency expansion.
   - Time expansion.
   - Date expansion.
   - Abbreviation tables.
   - NFKC/ligature normalization.
   - Ordinal/cardinal disambiguation.
   - Heteronym/contraction disambiguation.
   - Comprehensive normalizer fixtures.
3. Recommendation:
   - Add `SegmentNormalizer` between planner and engine.
   - Make it versioned.
   - Preserve original/display text separately.
   - Apply pronunciation overrides in the normalizer.
   - English first; design locale-aware.
   - Add normalizer version to cache identity.

## 3.9 Audio generation

1. Current state:
   - `generationPipeline.ts` orchestrates IPC to Kokoro.
   - Progressive chunk sizing: [D] cold-start 13 words, cruise 148 words.
   - Planner-aware boundary classification and silence injection.
   - Stale output guards.
   - Backpressure/pre-fetch through generation pipeline, though buffered-seconds gate is not explicit in [D].
2. Strengths:
   - Non-blocking.
   - Progressive first-audio behavior.
   - Practical queueing and stale-output controls.
3. Weaknesses:
   - Provider-specific behavior spread through strategies.
   - Rate bucket / tempo concepts leak Kokoro-specific metadata into scheduler.
   - No explicit buffered-seconds backpressure.
4. Recommendation:
   - Keep pipeline.
   - Formalize `AudioGenerationQueue`.
   - Add `getBufferedSeconds()` budget gate.
   - Tie generation jobs to generation IDs and provider capabilities.

## 3.10 Audio caching

1. Current state:
   - Persistent Opus disk cache.
   - Manifest tracking chunks/bytes/last narrated.
   - LRU eviction.
   - Opening coverage.
   - Renderer IPC wrapper.
   - Background cache builder.
   - Rate bucket and pronunciation override hash included in renderer paths.
   - [D] says 2GB cap.
2. Strengths:
   - Stronger than external reviewed caches.
   - Opus storage major space win.
   - Correctly accounts for rate bucket and override hash in important paths.
3. Weaknesses:
   - [A] warns manifest key uses `${bookId}/${voiceId}` and splits on `/`; composite voice IDs containing slashes can corrupt eviction/cleanup identity.
   - [D] says cache is not content-addressed: identical text across books regenerates.
   - No secondary content-hash index.
   - Manifest loaded in memory; acceptable now but may need bounding later.
4. Recommendation:
   - Keep cache design.
   - Encode/structure manifest keys and add migration tests.
   - Add content-addressed secondary index keyed by normalized text + provider/model/voice/rate/override/normalizer/version.
   - Add cache schema version/migration and corruption recovery.

## 3.11 Playback scheduling

1. Current state:
   - Web Audio API scheduler.
   - `AudioBufferSourceNode` scheduling.
   - `AudioContext.currentTime` is source of truth.
   - Pre-schedules chunks for gapless playback.
   - [D] crossfade 8 ms at chunk boundaries.
   - RAF word timer.
   - Sliding-window boundary prune.
   - Tempo stretch for non-bucket speeds.
   - Future chunks can be rebuilt on rate change without restarting playback.
   - Scheduler epoch token protects stale `onended` callbacks.
2. Strengths:
   - Best-in-cohort compared to reviewed alternatives.
   - Better than HTML `<audio>` scheduling in Readest.
   - More reliable than platform TTS pause/resume.
3. Weaknesses:
   - Some Kokoro-specific metadata is still plumbed through scheduler types.
   - Rate-change refresh reallocates sources.
4. Recommendation:
   - Do not rewrite scheduler.
   - Retain as load-bearing structure.
   - Add provider-neutral wrapper and timing confidence.
   - Consider silence-aware cursor hold.

## 3.12 Timing metadata

1. Current state:
   - Kokoro word timestamps flow from patched duration tensor through IPC into scheduler.
   - Scheduler validates:
     - count matching.
     - finite non-negative values.
     - monotonicity.
     - word correspondence.
     - overshoot tolerance.
     - zero-duration cap.
   - Invalid/missing timestamps fall back to weighted heuristic.
   - Timestamp source telemetry exists in DEV.
   - Non-Kokoro providers use `wordTimestamps: null`.
2. Strengths:
   - Honest timing model.
   - Fail-closed fallback.
   - Drift validation exists.
3. Weaknesses:
   - Timing data is inline, not a durable sidecar/entity.
   - English-only Kokoro timestamp caveat.
   - `endTime` preserved but not used for silence-aware cursor hold.
4. Recommendation:
   - Add `TimingMetadataStore`.
   - Store timing truth/provenance/confidence.
   - Persist provider/model/normalizer versions.
   - Never fabricate fake word timing.

## 3.13 Highlight synchronization

1. Current state:
   - Foliate word offsets/spans map narration cursor to rendered text.
   - Scheduler truth-sync drives canonical audio cursor.
   - [D] uses intentional `NARRATION_CURSOR_LAG_MS = 350` ms.
   - Visual collapsing band overlays current ancestor and advances left edge.
   - Truth-sync every six words and on chunk boundaries.
   - `lastConfirmedAudioWordRef` is canonical; visual callbacks cannot contaminate read head.
2. Strengths:
   - Strong canonical-vs-visual separation.
   - Prevents cursor overshoot.
3. Weaknesses:
   - Seek/reopen should anchor to stable segment IDs in addition to raw word indices.
   - Lag could be adaptive by rate.
4. Recommendation:
   - Add `HighlightSyncController`.
   - Support word/sentence/segment modes based on timing confidence.
   - Add line/segment fallback for non-word-timed providers.

## 3.14 Pause/resume/seek

1. Current state:
   - `AudioContext.suspend()` for pause.
   - `AudioContext.resume()` for resume.
   - Stop increments scheduler epoch, disconnects/nulls sources.
   - Resume anchor persists across app restarts in [D].
   - Cursor anchor survives reader mode switches in [D].
2. Strengths:
   - More robust than platform TTS pause semantics.
   - Gapless resume with audio clock.
3. Weaknesses:
   - Seek inside generated chunks should be formalized around segment/timing metadata.
   - Resume after long pause may re-warm Kokoro if idle-unloaded.
4. Recommendation:
   - Treat pause/resume as provider capability.
   - Add segment-level seek contract.
   - Consider named pause reasons only if telemetry shows ambiguity.

## 3.15 Settings/UI controls

1. Current state:
   - Per-engine settings/status sections for system/Kokoro/Nano/Pocket/Qwen.
   - Voice selection.
   - WPM/rate controls.
   - Pause controls.
   - Cache toggles.
   - Narration profiles and per-book assignment.
   - Footnote mode skip/read in [D].
2. Missing:
   - Pronunciation override UI.
   - Voice-blend formula UI.
   - Per-engine-per-language voice memory.
   - MediaSession integration.
   - Diagnostics panel for power users.
3. Recommendation:
   - Derive controls from provider capabilities.
   - Add override UI and voice blending in later phases.
   - Defer MediaSession based on platform priorities.

## 3.16 Error handling, logging, diagnostics

1. Current state:
   - Engine status snapshot includes status/detail/reason/ready/loading/recoverable.
   - IPC error normalization.
   - Kokoro worker crash retry/backoff.
   - Renderer error events and fallback.
   - Sidecar lifecycle backoff.
   - `narrateDiagnostics.ts`, `narratePerf.ts`, `ttsEvalTrace.ts`.
   - Eval runner and matrix/soak options.
2. Strengths:
   - Strong evidence-first culture.
   - Structured recoverability exists.
3. Weaknesses:
   - Error taxonomy distributed and sometimes inferred from reason strings.
   - Provider diagnostics are not normalized behind a single API.
   - DEV-only fallback warnings should become trace events.
4. Recommendation:
   - First-class `NarrationDiagnostics` subsystem.
   - User-exportable bug report bundle.
   - Provider-neutral telemetry fields: generation ID, provider, cache hit/miss, enqueue/dequeue, playback start/end, boundary event, drift correction, fallback reason.

## 3.17 Tests

1. Current strengths:
   - [D] reports 181 test files and 2,397+ tests.
   - Major suites include scheduler, glide, calm narration band, planner, continuity, cursor polish, timing, Kokoro strategy, rate plan, Qwen streaming hardening, worker/engine tests, cache correctness, and mock Kokoro.
   - [A] lists broad TTS tests including Nano/Pocket and eval gates.
2. Gaps:
   - Golden text segmentation corpus.
   - Normalizer fixtures.
   - Long-form drift regression suite.
   - Provider registry tests.
   - Cache migration/key encoding tests.
   - Content-addressed cache tests.
   - Voice formula parser tests.
   - Experimental gate tests.
3. Recommendation:
   - Add golden corpus and CI/eval gates while preserving existing Kokoro tests.

## 3.18 Explicit current gaps from [D]

1. No voice blending/formula syntax.
2. No comprehensive text normalization.
3. No pronunciation override UI.
4. No heteronym/contraction disambiguation.
5. No SSML/inline tag protocol for mid-stream voice/pause changes.
6. No M4B/SRT/ASS export.
7. No language-aware multi-engine voice memory.
8. No MediaSession integration.
9. No engine startup canary probe.
10. No content-addressed audio cache.
11. No formal `TTSProviderRegistry`.

---

# 4. Cross-codebase findings by theme

## 4.1 Text segmentation and normalization

1. Best practice:
   - Preserve display/original/source text separately from normalized synthesis text.
   - Use deterministic segment IDs tied to document structure.
   - Normalize a parallel synthesis copy, never mutate displayed text.
   - Use DOM/locator-aware traversal for highlighting.
2. Evidence and patterns:
   - Abogen `Chunk` / chunk IDs / `display_text` / `normalized_text` / `original_text`.
   - Abogen Kokoro normalizer: contractions, possessives, dates, times, ranges, currency, fractions, URLs, footnotes, abbreviations, Roman numerals, addresses.
   - Coqui cleaners: `english_cleaners`, abbreviation expansion, number normalization, time/currency expansion, punctuation restore.
   - pdf-narrator `clean_pipeline`: NFKC, line joining, abbreviations, number-to-words, punctuation injection, artifact strip, whitespace collapse.
   - Readest/Foliate: SSML marks and `Intl.Segmenter` / document traversal.
3. Blurby state:
   - Strong planner and word segmentation.
   - Minimal general normalization.
4. Adoption:
   - Add `SegmentNormalizer` with versioning and golden tests.
   - Use abogen-style text layers.
   - Do not replace planner with regex splitting.
   - Avoid destructive live normalization.

## 4.2 Audio generation pipeline

1. Best practice:
   - Separate document segmentation, provider synthesis, queueing, cache lookup, and playback scheduling.
2. Evidence and patterns:
   - RealtimeTTS: `BaseEngine`, `TextToAudioStream`, `StreamPlayer`, queue/timing/callback separation.
   - Abogen: extraction → chunking → normalization → generation → subtitle/metadata → output assembly.
   - pdf-narrator: generation over text files but no live scheduler.
3. Blurby state:
   - Already has progressive generation, background cache, and scheduler.
   - Lacks provider-neutral orchestration contract.
4. Adoption:
   - Retain pipeline/scheduler.
   - Wrap as `AudioGenerationQueue` and `TTSProvider`.

## 4.3 Streaming and latency

1. Best practice:
   - Capability-driven streaming.
   - First-fragment/first-sentence generation for low TTFB.
   - Buffered-seconds backpressure.
   - Shallow prefetch for interactive reading.
   - Separate live reading from export/bulk generation.
2. Evidence and patterns:
   - RealtimeTTS `fast_sentence_fragment`, `minimum_first_fragment_length`, `buffer_threshold_seconds`, `_synthesis_chunk_generator`.
   - Readest preloads next SSML units and first marks.
   - Sioyek fast-first then good/quality replacement.
   - Blurby Qwen streaming exists but disabled pending live validation.
3. Adoption:
   - Add explicit scheduler buffered-seconds query/gate.
   - Keep Qwen disabled.
   - Optional two-engine fast-start later.

## 4.4 Playback control

1. Best practice:
   - Single controller/state machine owns play/pause/stop/restart/seek.
   - Pause/resume semantics are provider-capability-specific.
   - Sentence/segment prev-next navigation.
   - Back-to-current / media controls / visible TTS bar.
2. Evidence and patterns:
   - Readest `TTSController` state machine, mark navigation, media/session UX.
   - Sioyek line restart due to Qt pause/resume bugs.
   - Ultimate TTS Reader stop-by-process-reexec anti-pattern.
3. Blurby state:
   - Strong Web Audio pause/resume.
   - Single generic pause state.
4. Adoption:
   - Keep AudioContext-based control.
   - Add optional named pause reasons if needed.
   - Add UX polish from Readest selectively.

## 4.5 Text/audio synchronization

1. Best practice:
   - Provider-native timing where proven.
   - Honest degradation to sentence/segment following otherwise.
   - Timing confidence/provenance should be explicit.
   - Highlight mapping is a document-locator problem, not just an audio problem.
2. Evidence and patterns:
   - Kokoro timing in RealtimeTTS and Blurby patch.
   - Readest sentence/mark granularity.
   - Sioyek Qt word callbacks and alignment JSON.
   - Abogen subtitles and duration-proportional fallback.
   - ttsreader Web Speech boundary unreliability.
3. Blurby state:
   - Best-in-cohort for Kokoro word timing and Web Audio scheduler.
   - Needs provider-neutral timing store for non-Kokoro providers.
4. Adoption:
   - Add `TimingMetadataStore` and confidence levels.
   - Word mode only where validated.
   - Segment/sentence fallback elsewhere.

## 4.6 Caching and reuse

1. Best practice:
   - Cache identity includes provider, provider/model version, voice, rate/generation bucket, text/normalizer version, pronunciation override version, output format, and segment ID.
   - Eviction must not depend on lossy string splitting.
   - Content-addressed secondary index can support cross-book reuse.
2. Evidence and patterns:
   - ttsreader hashes `text+lang+voice+rate`.
   - Sioyek hashes page text and stores audio/alignment sidecars.
   - Abogen voice asset caching.
   - Readest LRU object URL/audio cache.
3. Blurby state:
   - Strong persistent Opus cache, but key hygiene/content-addressing gaps.
4. Adoption:
   - Harden keys and add schema migration.
   - Add timing JSON sidecar and checksum.
   - Add content-addressed index as secondary, not replacement.

## 4.7 Voice and model abstraction

1. Best practice:
   - Small provider surface with capability map.
   - Providers declare streaming, timing, pause, offline/network, language, voice, license, model readiness, packaging.
   - Engine instances are interchangeable to the orchestrator.
2. Evidence and patterns:
   - RealtimeTTS `BaseEngine` and fallback list.
   - Readest `TTSClient` and client-specific implementations.
   - Coqui `TTS` API/model manager and speaker/language metadata.
   - abogen voice formulas and voice cache.
3. Blurby state:
   - Informal strategy interface.
4. Adoption:
   - `TTSProvider`, `TTSProviderRegistry`, `ProviderCapabilities`.
   - Voice blending via formula parser later.
   - Per-engine-per-language voice memory later.

## 4.8 Long-form reading UX

1. Best practice:
   - Section/chapter traversal.
   - CFI/page/line/locator mapping.
   - Reject non-readable nodes.
   - Back-to-current narration UI.
   - Persistent TTS bar.
   - Remaining time display.
   - Keyboard/media controls.
   - Resume-from-last-position.
2. Evidence and patterns:
   - Readest: Foliate traversal, reject filters, media metadata, TTS bar, settings, tests.
   - Abogen: chapter markers, TOC/spine awareness.
   - pdf-narrator: TOC handling and OCR fallback.
   - Sioyek: PDF line/rectangle mapping.
3. Blurby state:
   - Strong Foliate word/highlighting integration and reader modes.
   - Needs durable segment/location records and selected UX polish.
4. Adoption:
   - Anchor narration to document sections/locators.
   - Add back-to-current/media/remaining time selectively.

## 4.9 Offline and packaging

1. Best practice:
   - Keep default runtime small and deterministic.
   - Gate heavy local models behind explicit opt-in and health checks.
   - License metadata and model TOS acceptance must be explicit.
   - Avoid requiring users to install Python/Torch/CUDA manually.
2. Evidence and patterns:
   - Coqui heavy Python/Torch and model-specific license/TOS.
   - RealtimeTTS optional dependency sprawl.
   - pdf-narrator Python/Torch/FFmpeg/eSpeak/Tesseract complexity.
   - Sioyek scripts depend on PowerShell/SoX/Aeneas/pygame/Flask.
   - Readest lower packaging friction but weaker deterministic local control.
3. Adoption:
   - Keep current sidecar/worker pattern.
   - Add provider packaging manifest fields.
   - Do not bundle Coqui/Torch as default.
   - Do not adopt broad RealtimeTTS runtime.

## 4.10 Error handling and observability

1. Best practice:
   - Structured lifecycle events.
   - Provider health.
   - Synthesis latency.
   - Cache hit/miss.
   - Queue state.
   - Boundary/timing truth.
   - Drift correction.
   - Fallback reason.
   - User-exportable diagnostics.
2. Evidence and patterns:
   - RealtimeTTS callbacks.
   - Abogen metadata/chunk markers/elapsed time.
   - Readest abort handling and race guards.
   - Blurby decision docs and eval traces.
3. Adoption:
   - Normalize provider diagnostics behind single API.
   - Add exportable diagnostics bundle.

---

# 5. Project-by-project outline

## 5.1 Abogen

1. Purpose:
   - Batch audiobook/document-to-audio generator using Kokoro and structured metadata.
   - Generates audio, subtitles, chapter markers, export artifacts.
2. Relevant reviewed files/features across sources:
   - `chunking.py`.
   - `kokoro_text_normalization.py`.
   - `book_parser.py`.
   - `subtitle_utils.py`.
   - `conversion_runner.py` / `conversion.py`.
   - `voice_cache.py`.
   - `pronunciation_store.py`.
   - `heteronym_overrides.py`.
   - `word_substitution.py`.
   - `voice_formulas.py` and `voice_formula_gui.py`.
   - `epub3/exporter.py` / EPUB3/SMIL direction.
   - FFmetadata chapter mux.
   - ASS karaoke `\kf` subtitle timing.
3. Architecture summary:
   - Extraction produces chapters/book text.
   - Chunking creates deterministic paragraph/sentence chunks.
   - Normalization/pronunciation overrides feed Kokoro/SuperTonic.
   - Audio/subtitle/metadata generated as batch artifacts.
   - Voice assets prefetched from HF with local-files-first behavior.
4. Strengths:
   - Deterministic chunk IDs.
   - Separate `original_text`, `display_text`, and `normalized_text`.
   - Rich Kokoro-specific normalization.
   - Pronunciation store and heteronym overrides.
   - Voice formulas / weighted tensor blending.
   - Chapter markers and batch metadata.
   - M4B/SRT/ASS/export feature surface.
   - HF voice prefetch and idempotent voice asset caching.
5. Weaknesses:
   - Batch/offline generation, not live Electron playback.
   - Regex/abbreviation sentence splitting weaker than Blurby planner.
   - Full chapter or whole text processing can be memory-heavy.
   - Monolithic QThread conversion in [D].
   - Hardcoded `device="cpu"` in voice blending path in [D].
   - Broad normalization can regress word offsets if copied wholesale.
6. Reusable patterns:
   - Segment/chunk ID scheme.
   - Text-layer separation.
   - Normalizer versioning.
   - Pronunciation override persistence.
   - Voice formula parser.
   - Voice asset cache/prefetch.
   - Chapter marker model.
   - EPUB3/SMIL/M4B/SRT/ASS export as future product feature.
7. Avoid:
   - Replacing live planner with regex splitting.
   - Batch generation as live narration core.
   - Multi-speaker/export complexity before product goal.
   - Hardcoded CPU fallback for blended voices.
8. Roadmap impact:
   - P1: segment metadata + normalizer + pronunciation UI.
   - P2: voice blending.
   - P3/future: export features and voice prefetch polish.

## 5.2 RealtimeTTS

1. Purpose:
   - Streaming TTS orchestration library across many engines.
2. Relevant reviewed files/features:
   - `text_to_stream.py`.
   - `stream_player.py`.
   - `engines/base_engine.py`.
   - `engines/kokoro_engine.py`.
   - `engines/moss_tts_engine.py`.
   - `engines/coqui_engine.py`.
   - `engines/faster_qwen_engine.py`.
   - `threadsafe_generators.py`.
   - `safepipe.py`.
   - lazy engine imports.
3. Architecture summary:
   - `TextToAudioStream` consumes text/fragments.
   - Pluggable engine synthesizes and pushes PCM to queue.
   - Timing information is pushed on a parallel queue/list.
   - `StreamPlayer` consumes audio and fires callbacks.
   - Engine list/fallback supported.
4. Strengths:
   - Cleanest provider abstraction in corpus.
   - Fallback engine list.
   - Timing event shape.
   - Sentence-fragment-first synthesis.
   - Buffer-threshold prefetch/backpressure.
   - Callback-rich lifecycle.
   - Subprocess/worker isolation pattern for heavy engines.
   - Voice blend formula in Kokoro engine.
   - CUDA graph warmup and sentinel speaker embedding cache in [D].
5. Weaknesses:
   - Python, PyAudio, mpv, optional dependency sprawl.
   - Playback stack not suitable for Electron.
   - NLTK/Stanza tokenizers heavy.
   - Timing may drift when trimming/post-processing not accounted for.
   - Busy-wait pause loops and in-place timing mutation in [D].
   - Engine matrix can break with upstream dependencies.
6. Reusable patterns:
   - `TTSProvider` / `BaseEngine`-style contract.
   - Audio and timing queues.
   - Buffered-seconds accounting.
   - Fallback events.
   - Voice formula parsing.
   - Lazy optional engine loading.
7. Avoid:
   - Embedding Python runtime.
   - PyAudio/mpv playback.
   - Threading model and busy-waits.
   - Letting streaming fragments define canonical document segment identity.
8. Roadmap impact:
   - P1 provider registry.
   - P2 buffered-seconds backpressure.
   - P2 voice blending.

## 5.3 Readest

1. Purpose:
   - Cross-platform ebook reader with integrated TTS.
   - Most strategically similar to Blurby in [D]/[B].
2. Relevant reviewed files/features:
   - `TTSController.ts`.
   - `TTSClient.ts`.
   - `WebSpeechClient.ts`.
   - `EdgeTTSClient.ts`.
   - `NativeTTSClient.ts`.
   - `TTSUtils.ts`.
   - `utils/ssml.ts`.
   - `useTTSControl.ts`.
   - `useTTSMediaSession.ts`.
   - `ttsMetadata.ts` and `ttsTime.ts`.
   - Foliate viewer and `foliate-js/tts.js`.
   - Android native TTS plugin.
3. Architecture summary:
   - Document-aware controller above multiple clients.
   - SSML/mark-based segmentation and highlight dispatch.
   - Provider clients speak SSML and emit boundary/mark events.
   - Controller handles state transitions, section initialization, prefetch, mark dispatch, and highlighting.
4. Strengths:
   - Clean TS provider/client interface.
   - Foliate-aware traversal and reject filters.
   - SSML mark bridge to highlighting.
   - Preload race discipline.
   - Persistent TTS bar/settings UX.
   - MediaSession integration.
   - Named pause-reason states.
   - Per-engine-per-language voice memory.
   - Tests for PDF/XHTML/document quirks.
5. Weaknesses:
   - Sentence granularity only.
   - HTML `<audio>` scheduling weaker than Blurby Web Audio.
   - Edge TTS remote/auth/ToS risks.
   - Native Android pause/resume not true resume.
   - Tauri plugin architecture not directly reusable in Electron.
   - Potential audio element churn / audible gaps in [B].
6. Reusable patterns:
   - Controller/client abstraction.
   - Foliate section traversal.
   - Reject filters for `rt`, `canvas`, `br`, annotation layers, footnotes/decorative nodes.
   - State machine and expected abort handling.
   - Back-to-current/media/session UX.
   - Voice preference keying by engine/language.
   - TTS time estimation.
7. Avoid:
   - Edge service as core offline path.
   - Synthetic `<audio>` scheduling.
   - Hard-coded reverse-engineered Edge auth token.
   - Assuming sentence-only forever.
8. Roadmap impact:
   - P2/P3 selected UX controls.
   - Investigate Foliate `tts.js`/`textWalker`, but not necessarily replace current internals.

## 5.4 Coqui TTS

1. Purpose:
   - Large Python TTS training/inference toolkit.
2. Relevant reviewed files/features:
   - `TTS/api.py`.
   - `TTS/utils/synthesizer.py`.
   - `TTS/utils/manage.py`.
   - `TTS/server/server.py`.
   - `TTS/tts/models/base_tts.py` and model factory.
   - `xtts.py` streaming/crossfade.
   - `cleaners.py` and English number/time/abbreviation modules.
   - `.models.json` / model registry and license/TOS fields.
3. Architecture summary:
   - High-level API resolves model, speaker, language, vocoder.
   - Sentence splitting and synthesis per sentence.
   - Model manager downloads and checks licenses/TOS.
4. Strengths:
   - Text front-end completeness.
   - Currency/time/date/abbreviation normalization.
   - Punctuation strip-and-restore.
   - Model abstraction and registry.
   - License/TOS awareness.
   - Multilingual/multispeaker support.
   - XTTS streaming/crossfade pattern.
5. Weaknesses:
   - Heavy Python/Torch packaging.
   - Repo maintenance/licensing concerns.
   - XTTS-v2 CPML/non-commercial according to [B]/[D].
   - No universal interactive word-timing contract.
   - CPU latency and memory burden.
   - God-object `Synthesizer`.
   - Subprocess/eSpeak/gruut/spaCy dependencies.
6. Reusable patterns:
   - Cleaner tables and normalization chain.
   - Model/license metadata.
   - Speaker/language validation.
   - Sidecar experiment only.
7. Avoid:
   - Embedding Coqui/Torch directly in Electron.
   - Using Coqui as default runtime.
   - Assuming model toolkit maturity equals interactive reader fit.
8. Roadmap impact:
   - P1 text front-end pattern.
   - P3 license metadata.
   - Phase 4+ optional sidecar research only.

## 5.5 Sioyek

1. Purpose:
   - Research PDF reader with native TTS / experimental external scripts.
2. Relevant reviewed files/features:
   - `main_widget.cpp` / reading handlers.
   - `utils.cpp` / TTS classes and word callbacks.
   - `document.cpp` / character/page iterators.
   - `coordinates.h` typed coordinate spaces.
   - Android `TextToSpeechService.java` in [C].
   - `scripts/tts/manager_server.py`, generator/aligner scripts.
3. Architecture summary:
   - Native Qt/Android path uses platform TTS callbacks.
   - Script path generates page audio and alignment files, follows by playback position.
   - Fast/low-quality audio can start while better aligned audio renders.
4. Strengths:
   - Page/line/char rectangle following.
   - Typed coordinate spaces.
   - Line-rect anchors survive zoom/reflow.
   - Alignment sidecar concept.
   - Two-engine quality swap / fast-first playback.
5. Weaknesses:
   - Platform-specific.
   - Native TTS word events unreliable after pause/resume.
   - Shell-heavy scripts; PowerShell/SoX/Aeneas/pygame/Flask/local paths.
   - Page granularity not ideal for EPUB.
   - No robust scheduler or cache compared to Blurby.
6. Reusable patterns:
   - Line/segment fallback when word timing missing.
   - Alignment sidecars as future enhanced-sync/export mode.
   - Coordinate-space discipline for PDF lane.
   - Fast-first, good-later concept.
7. Avoid:
   - Platform TTS events as primary timing truth.
   - Shell scripts as app core.
   - Pygame mixer playback.
   - Restart-line-on-resume.
8. Roadmap impact:
   - Future PDF lane and fallback highlighting.
   - Phase 3 line/segment fallback ideas.

## 5.6 PDF Narrator

1. Purpose:
   - GUI PDF/EPUB/TXT/HTML to Kokoro audiobook converter.
2. Relevant reviewed files/features:
   - `main.py`.
   - `ui.py`.
   - `extract.py`.
   - `generate_audiobook_kokoro.py`.
   - README.
3. Architecture summary:
   - Extracts text by chapters/TOC or whole text.
   - Cleans text aggressively.
   - Generates Kokoro audio chunks.
   - Concatenates/normalizes/writes WAV/MP3.
   - Supports pause/cancel via GUI events.
4. Strengths:
   - Practical PDF/EPUB extraction.
   - TOC-driven chapter splitting.
   - Header/footer filtering.
   - OCR fallback for scanned PDFs.
   - PDF scan detection heuristics.
   - `remove_overlap` for TOC chapter bleed.
   - Clean pipeline with NFKC, ligatures, abbreviations, numbers, years, initials.
   - Voice testing and CPU/GPU selection.
5. Weaknesses:
   - Batch/blocking orientation.
   - Regex split pattern and punctuation injection.
   - Destructive normalization unsuitable for exact live highlighting.
   - No word timing or live scheduler.
   - No cache identity or document sync.
   - Column-blind PDF extraction and hardcoded thresholds in [D].
6. Reusable patterns:
   - `clean_pipeline` selectively for TTS-input copy.
   - `remove_overlap`.
   - TOC and OCR heuristics.
   - Scanned-PDF sniff.
   - PDF lane fixtures.
7. Avoid:
   - File-per-chapter live core.
   - Peak-normalizing audio chunks before scheduling.
   - Hard-coded voice list.
   - Destructive displayed-text mutations.
8. Roadmap impact:
   - P1/P2 if PDF lane is active; otherwise P3/future.

## 5.7 ttsreader

1. Purpose:
   - Browser/Web Speech wrapper with server/cloud TTS buffering.
2. Relevant reviewed files/features:
   - `helpers/ttsEngine.js`.
   - `helpers/serverTts.js`.
   - `helpers/serverVoices.js`.
   - README/test pages.
3. Architecture summary:
   - Wraps `speechSynthesis` / `SpeechSynthesisUtterance`.
   - Optional server TTS endpoint returns audio blobs/MP3.
   - Buffers paragraphs/utterances by hash.
   - Workarounds for Chrome/Google voice quirks.
4. Strengths:
   - Candid Web Speech bug catalog.
   - Notes Google voice `onboundary` unreliability.
   - Chrome pause/resume workaround.
   - Silent canary probe.
   - Voice scoring heuristics.
   - Content-addressed prefetch keys.
   - Buffer next paragraphs pattern.
5. Weaknesses:
   - Browser-centric ad hoc code.
   - Global singleton / mutable state.
   - No real chunking or deterministic document model.
   - No productized word-level sync.
   - Runtime method rewriting and visible bugs in [D].
   - In-memory cache lacks durable invalidation metadata.
6. Reusable patterns:
   - Web Speech caveat list → tests/capability flags.
   - Provider flag `boundaryEventsReliable: false`.
   - Silent canary.
   - Voice scoring for fallback.
   - Content-hash prefetch as inspiration.
7. Avoid:
   - Using Web Speech `onboundary` as timing truth.
   - Globals / engine-UI bleed.
   - Runtime method rewriting.
   - Opaque server cache.
8. Roadmap impact:
   - P2 silent canary and content-addressed cache.

## 5.8 Ultimate TTS Reader

1. Purpose:
   - Minimal Windows clipboard reader using pyttsx3/SAPI and hotkey.
2. Relevant reviewed files/features:
   - `tts.py`.
   - `main.py`.
   - `gui.py`.
   - README.
3. Architecture summary:
   - Hotkey reads clipboard.
   - `engine.say()` speaks entire text.
   - Manual event loop.
   - Word callback scaffold exists but only prints.
4. Strengths:
   - Minimal platform TTS proof.
   - Hotkey concept.
   - pyttsx3/SAPI started-word event as one data point in [B]/[D].
5. Weaknesses:
   - No document model.
   - No segmentation.
   - No scheduler/cache/resume.
   - Stop by process re-exec.
   - Abandoned/stale.
6. Reusable patterns:
   - Very limited: possible clipboard/global hotkey accessibility idea.
   - Possible proof that native SAPI can expose word events, but not a product architecture.
7. Avoid:
   - Clipboard/platform voice loop as app architecture.
   - Process restart to stop.
   - Fire-and-forget entire text.
8. Roadmap impact:
   - None or optional P3 clipboard narration hotkey.

## 5.9 Markor

1. Purpose:
   - Android markdown/notes editor.
2. Review result:
   - No substantive TTS subsystem found in local artifact.
   - [B] references issue #768/Select-to-Speak as cautionary, not implementation.
   - [D] confirms absence of `TextToSpeech`/speech implementation.
3. Strengths:
   - None for Blurby TTS.
4. Weaknesses/negative lessons:
   - Do not treat feature request/discussion as code evidence.
   - Delegating entire TTS UX to platform accessibility can fail start-position and markup-cleanliness needs.
5. Roadmap impact:
   - None.

---

# 6. Recommended architecture outline

## 6.1 Core principles

1. Segment-first.
2. Provider-agnostic.
3. Timing-aware.
4. Cache-safe.
5. Capability-driven UI and fallback.
6. Non-destructive text handling.
7. Scheduler preserved as load-bearing structure.
8. Experimental providers gated by evidence, not subjective voice quality.

## 6.2 `TTSProvider`

1. Maps from current `TtsStrategy`.
2. Responsibilities:
   - Initialize/preload/warm up.
   - Report status/health.
   - List voices.
   - Synthesize segment/job.
   - Optionally stream frames.
   - Emit timing metadata if supported.
   - Stop/pause/resume if provider supports them.
3. Capability fields collected across documents:
   - `id` / engine ID.
   - label/display name.
   - streaming support.
   - pause/resume support.
   - native pause/resume support.
   - seek-within-segment/audio support.
   - word timing support.
   - sentence timing support.
   - phoneme timing support.
   - timing truth enum.
   - boundary reliability.
   - offline/online.
   - requires network.
   - requires sidecar.
   - requires GPU / optional GPU.
   - cacheable.
   - experimental/selectable.
   - supported languages.
   - sample rate.
   - speed/rate range.
   - SSML support.
   - max utterance chars.
   - voice blending support.
   - packaging status.
   - license/commercial/TOS acceptance.

## 6.3 `TTSProviderRegistry`

1. Responsibilities:
   - Register providers.
   - Get/list/filter providers.
   - Resolve provider for request.
   - Resolve fallback order.
   - Enforce capability requirements.
   - Hide experimental providers unless gate allows.
   - Drive UI selection/status.
2. Policies to encode:
   - Preferred provider if healthy.
   - Secondary provider same language/voice if available.
   - Fallback to Web/system TTS.
   - Degrade highlighting mode based on timing truth.

## 6.4 `DocumentSegmenter` / `NarrationSegment` / `DocumentSegment`

1. Responsibilities:
   - Consume EPUB/PDF/flat text structure.
   - Reject non-readable nodes.
   - Emit stable segment objects.
   - Preserve source/display/synthesis text separation.
   - Preserve locators and offsets.
2. Fields collected across documents:
   - `segmentId` / `id`.
   - `bookId` / `docId`.
   - `sectionId`, `sectionIndex`, ordinal.
   - EPUB CFI or PDF text locator or flat char offsets.
   - paragraph ID.
   - sentence index.
   - source/display/original/raw text.
   - normalized/synthesis text.
   - source character start/end.
   - word start index/word count.
   - word spans.
   - structural role/kind: heading, paragraph, sentence, dialogue, caption, footnote, table, unknown.
   - provider compatibility flags.
   - normalizer version.
   - DOM range reference for highlighting if used.
3. Stable ID schemes mentioned:
   - `chap0000_p0000_s0000` style from abogen.
   - `sha1(docId:cfi:sentenceIndex)` from [B].
   - `docId + sectionIndex + locator + ordinal + normalization seed` from [C]/[D].
4. Adoption:
   - Use deterministic IDs from document location and local ordinal, not queue order or plain text hash alone.

## 6.5 `SegmentNormalizer`

1. Responsibilities:
   - Pure function.
   - Non-destructive to displayed text.
   - Versioned.
   - Provider-agnostic core plus provider-specific final pass if needed.
   - Apply pronunciation overrides here.
   - Return normalized text and optionally trace/hash.
2. Pipeline elements collected:
   - Pronunciation overrides first.
   - NFKC normalization.
   - Ligature folding.
   - Smart quote folding.
   - Join wrapped lines.
   - Expand abbreviations and initials.
   - Spaced initial collapse.
   - Number-to-words.
   - Year-aware number conversion.
   - Currency expansion.
   - Time expansion.
   - Date expansion.
   - Ordinal/cardinal expansion.
   - Ranges/fractions/URLs/footnotes if adopting abogen breadth.
   - Sentence-end punctuation injection only for TTS copy, with caution.
   - Citation/artifact stripping.
   - Whitespace collapse.
3. Safeguards:
   - Keep display/source text separate.
   - Golden fixtures before broad rollout.
   - `normalizerVersion` in cache key.
   - Feature flag for one minor release in [D].
   - English first; locale routing for future ES/FR/JP/ZH.

## 6.6 `NarrationJob`

1. Responsibilities/fields:
   - job ID.
   - generation ID.
   - segment.
   - provider ID.
   - voice ID/formula.
   - rate/speed/pitch.
   - generation bucket.
   - pronunciation override hash/version.
   - cache key.
   - queue state.
   - cancellation signal.
   - diagnostics channel.
2. Rule:
   - Every stop/seek/rate/voice/provider change creates a new generation ID so stale synthesis results are discarded.

## 6.7 `AudioGenerationQueue`

1. Responsibilities:
   - Rolling queue of ready segments.
   - Prefetch 2–4 segments ahead in [C].
   - Prefer cache hits.
   - Cancel stale generation when generation ID changes.
   - Optionally speculative warm next visible section.
   - Gate generation on buffered seconds.
   - Do not keep generating while paused for hours.
2. Source inspirations:
   - Current Blurby `generationPipeline`.
   - RealtimeTTS buffered-seconds backpressure.
   - Readest preloading/race discipline.

## 6.8 `AudioCache`

1. Store:
   - Audio file/blob.
   - Timing JSON sidecar.
   - Metadata JSON.
   - Checksum/hash of synthesis text.
2. Recommended key components:
   - `docId`.
   - `segmentId`.
   - `providerId`.
   - `providerVersion`.
   - `modelId` / `modelVersion`.
   - `voiceId` or voice formula.
   - `rate`, `pitch`, generation/rate bucket.
   - `normalizationVersion`.
   - `pronunciationVersion` / override hash.
   - `audioFormatVersion`.
   - normalized text hash.
3. Enhancements:
   - Structured/encoded keys.
   - Schema version/migration.
   - Secondary content-addressed index.
   - Clear cache per book UI.
   - Cache growth controls.

## 6.9 `PlaybackScheduler`

1. Preserve current `audioScheduler` as core.
2. Responsibilities:
   - Schedule audio chunks/segments.
   - Maintain playhead.
   - Start/stop/pause/resume.
   - Track segment boundaries.
   - Decide when next segment starts.
   - Emit scheduler events.
   - Perform drift correction at boundaries.
   - Expose buffered seconds.
3. Do not replace with:
   - PyAudio/mpv/pygame.
   - HTML `<audio>` churn.
   - Platform TTS event loops.

## 6.10 `TimingMetadataStore`

1. Responsibilities:
   - Put/get timings by segment.
   - Find segment/word at absolute ms.
   - Store sentence and word timings separately.
   - Store provider provenance.
   - Store confidence/timing truth.
   - Store drift and post-processing validity.
   - Export SMIL if audiobook export is added.
2. Timing truth levels:
   - word-native.
   - word-derived.
   - sentence.
   - segment.
   - estimated.
   - none.
3. Required metadata:
   - segment ID.
   - provider ID.
   - timing truth.
   - sample rate.
   - duration.
   - word timestamps with confidence.
   - drift.
   - generated time.
   - provider version.
   - model version.
   - normalizer version.

## 6.11 `HighlightSyncController`

1. Responsibilities:
   - Own visual following.
   - Attach/detach from scheduler and timing store.
   - Sentence/word/off modes.
   - Segment fallback.
   - Opacity/color settings.
   - Map timing spans to document ranges via locators/offsets.
   - Degrade gracefully if timing is low-confidence.
2. Modes:
   - Word mode only when provider timing passes validation.
   - Sentence/segment mode otherwise.
   - Off mode user setting.

## 6.12 `NarrationDiagnostics`

1. Responsibilities:
   - Log namespaced events.
   - Start/end spans.
   - Export redacted report.
   - Capture provider selection, generation IDs, queue state, cache events, drift, fallback reasons.
2. Should replace:
   - Console clutter.
   - DEV-only warnings as only observability.

## 6.13 `ExperimentalModelGate`

1. Responsibilities:
   - Enable/disable experimental providers.
   - Hide providers from normal UI unless allowed.
   - Hold promotion criteria.
   - Surface unmet criteria in UI.
2. Gate criteria collected:
   - health probe pass.
   - memory threshold.
   - startup latency threshold.
   - crash count threshold.
   - explicit opt-in.
   - timing support level.
   - first-audio budget.
   - drift eval.
   - license clarity.
   - packaging status.
3. Applies to:
   - MOSS Nano.
   - Pocket TTS.
   - Qwen streaming.
   - Coqui/Python sidecars.
   - Edge/Piper/cloud providers if added.

## 6.14 Runtime topology variants

1. [A]/[D] current-ish topology:
   - Renderer owns UI, Web Audio scheduler, highlighting.
   - Main process owns IPC/cache/engine management.
   - Worker/sidecars own inference.
2. [B] proposed topology:
   - Renderer owns `<audio>` + `MediaSource` + `SourceBuffer`, highlight controller, UI.
   - Main owns registry/cache/timing store/queue/logical scheduler.
   - Worker/sidecar owns Kokoro.
   - Web Speech provider lives in renderer.
3. Conflict/resolution:
   - Preserve existing Web Audio scheduler if already stable.
   - Consider MediaSource only if product needs continuous encoded stream architecture and cross-platform validation passes.

---

# 7. Timing and highlighting outline

## 7.1 Current acceptable behavior

1. Kokoro provides native real word timestamps via patched duration tensors.
2. Scheduler validates timestamps before use.
3. Invalid/missing timestamps fall back to heuristic.
4. Nano/Pocket remain segment-following.
5. Web Speech fallback is low-confidence.
6. Highlighting maps document word offsets/spans to rendered text.

## 7.2 Minimum production behavior

1. Every scheduled chunk references stable `segmentId`.
2. Every timing record declares:
   - timing truth.
   - provider ID.
   - model/provider version.
   - normalizer version.
   - duration.
   - drift validation result.
3. Missing/invalid word timing degrades to segment/sentence highlighting.
4. Pause/resume/seek tested by provider capability.

## 7.3 Preferred future behavior

1. Persist timing metadata keyed by segment/provider/voice/rate/normalizer/override/text hash.
2. Use native word timing only if drift checks pass.
3. Use `HighlightSyncController` to choose word/sentence/segment mode.
4. Add drift diagnostics and snap at segment boundaries when divergence exceeds threshold.
5. Add silence-aware cursor hold where word `endTime` precedes next word `startTime`.

## 7.4 Segment ID and offsets

1. EPUB:
   - CFI-based locator.
   - Section index.
   - Paragraph ID.
   - Sentence/segment ordinal.
2. PDF:
   - page index.
   - text-layer node path.
   - char offsets.
   - possibly line rectangles/coordinate spaces.
3. Flat text:
   - character offsets.
4. Each segment retains raw/display/source/synthesis text and source char ranges.

## 7.5 Fallback when precise timing metadata is unavailable

1. [A]/[D]: degrade to segment or sentence highlighting; do not fabricate word following.
2. [B]: duration-proportional character allocation is possible but visibly inferior.
3. [C]: provider boundaries are enhancements; current segment highlight is safer when precision absent.
4. Resolved recommendation:
   - Default fallback: sentence/segment mode.
   - Estimated word mode only if clearly labeled low-confidence and not used as “truth.”

## 7.6 Evidence required before replacing Kokoro timing

1. 5+ minute long-form live runs with bounded drift.
2. First-audio p95 at/below Kokoro baseline or justified by quality improvement.
3. Word/sentence timing availability and monotonicity tests.
4. Pause/resume/seek regression tests.
5. Memory/CPU/GPU packaged-app profile.
6. Cache reproducibility across restart.
7. Correct highlights across Page, Focus, Flow, and Narrate modes.
8. Long-form soak tests for 10/30/60 minutes and/or 12-hour stress in [B].

---

# 8. Model and engine evaluation outline

## 8.1 Kokoro

1. Role:
   - Default/current primary/timing baseline.
2. Strengths:
   - Offline.
   - Already integrated.
   - Cacheable.
   - Word-timed through patch.
   - CPU viable.
   - Smaller than many alternatives.
   - Good combined license/packaging fit.
3. Risks:
   - Timing drift under upstream changes/text normalization.
   - Non-English timestamp reliability.
   - Voice blending compatibility needs probe.
4. Recommendation:
   - Keep default.
   - Preserve and regression-test.

## 8.2 MOSS Nano

1. Role:
   - Recommended opt-in / complementary.
2. Strengths:
   - Local/offline sidecar.
   - Real ONNX path.
3. Risks:
   - No word timing.
   - IPC/PCM concerns.
   - License/commercial clarity.
4. Recommendation:
   - Keep opt-in; no default promotion until timing parity and gates.

## 8.3 Pocket TTS

1. Role:
   - Experimental/opt-in scaffold.
2. Risks:
   - Adapter not configured.
   - No timing.
   - License/voice cloning product risks.
3. Recommendation:
   - Keep disabled/opt-in until real adapter and gates.

## 8.4 Qwen streaming

1. Role:
   - Deferred GPU/streaming engine.
2. Strengths:
   - Reusable binary frame protocol.
   - Stall/cancel/crash infrastructure.
3. Risks:
   - Live CUDA validation pending.
   - Heavy packaging.
   - Timing unproven.
4. Recommendation:
   - Keep disabled; keep infrastructure.

## 8.5 Coqui TTS / XTTS

1. Role:
   - Text-front-end/model registry donor; optional research sidecar only.
2. Strengths:
   - Voice/model breadth.
   - Cleaners.
   - License metadata pattern.
3. Risks:
   - Heavy Python/Torch runtime.
   - Model-specific license/TOS.
   - XTTS CPML/non-commercial in [B]/[D].
   - Weak interactive timing contract.
4. Recommendation:
   - Reject as default runtime.

## 8.6 RealtimeTTS

1. Role:
   - Architecture reference only.
2. Strengths:
   - Provider contract and streaming/fallback orchestration.
3. Risks:
   - Python runtime and PyAudio/multiple engines.
4. Recommendation:
   - Reimplement ideas in TypeScript; do not ship library.

## 8.7 Web Speech / system/native TTS

1. Role:
   - Final fallback / reach layer.
2. Strengths:
   - Low install cost.
   - Broad platform availability.
3. Risks:
   - Boundary events unreliable.
   - Voice quality variable.
   - Pause/resume semantics inconsistent.
4. Recommendation:
   - Fallback only.
   - Capability flag for unreliable boundaries.

## 8.8 Edge TTS / cloud TTS

1. Role:
   - Optional remote provider only, if user opts in.
2. Strengths:
   - High-quality voices.
   - TS WebSocket implementation possible.
3. Risks:
   - Network-dependent.
   - Service/proxy complexity.
   - ToS/licensing unclear.
   - Reverse-engineered token breakage in Readest.
4. Recommendation:
   - Reject as offline core.
   - Defer or gate behind explicit opt-in/BYO API.

## 8.9 Piper / lightweight local engines

1. Mentioned mainly in [B].
2. Strengths:
   - Lightweight ONNX.
   - MIT models possible.
   - Good lightweight fallback when storage-constrained.
3. Risks:
   - Usually no native word timestamps.
   - Voice quality variable.
4. Recommendation:
   - Consider Phase 4 optional secondary if quality/packaging gates pass.

## 8.10 Sioyek aligned-audio / PDF Narrator export workflows

1. Role:
   - Future enhanced sync or export modes.
2. Not default live narration.
3. Useful for:
   - Forced alignment.
   - Audiobook export.
   - PDF line following.

---

# 9. Gap matrix consolidated

## 9.1 High priority / P1

1. `SegmentNormalizer` for currency/time/date/abbrev/NFKC/ligature/number handling.
2. Pronunciation override UI and persistent store.
3. Formal `TTSProvider` contract and registry.
4. Deterministic segment IDs and source/display/normalized text records.
5. Provider capability metadata.
6. Golden segmentation/normalization fixtures.
7. Cache key encoding/safety issue validation and migration planning.
8. Timing metadata model groundwork.

## 9.2 Medium priority / P2

1. Content-addressed cache index.
2. Playback-buffered-seconds backpressure.
3. Silent canary probe.
4. Voice blending/formula parser.
5. Formal `ExperimentalModelGate`.
6. Timing/confidence store and highlight fallback modes.
7. Drift diagnostics.
8. PDF extraction/normalization fixtures if PDF lane is active.
9. Voice asset prefetch idempotency.

## 9.3 Optional / P3+

1. Per-engine-per-language voice memory.
2. MediaSession integration.
3. Named pause-reason discrimination.
4. Adaptive cursor lag.
5. M4B/SRT/ASS/EPUB3/SMIL export.
6. Global hotkey / clipboard narration.
7. Cloud/BYO API providers.
8. Piper/lightweight local alternative.
9. Forced alignment / Whisper-based alignment.

## 9.4 Deferred/blocking until evidence

1. Qwen streaming promotion.
2. MOSS Nano default promotion.
3. Pocket TTS production mode.
4. Coqui sidecar/runtime.
5. Non-Kokoro word timing claims.
6. Universal word-level highlighting.

---

# 10. Roadmap outline

## 10.1 Phase 0 — Findings and validation

1. Convert findings into actionable sprint issues/specs.
2. Validate disputed assumptions and current source.
3. Confirm priorities with user/product.
4. Cross-check baseline claims.
5. Re-run current TTS test slice.
6. Benchmark current pipeline on representative EPUBs in [B].
7. Catalog current segmentation/caching/playback/sync.
8. No behavior/source changes initially.
9. Exit criteria:
   - Sprint queue/specs exist.
   - Baseline ambiguity closed.
   - Current behavior measurable and documented.

## 10.2 Phase 1 — Core abstraction, segmentation, normalization

1. Add/rename `TTSProvider`.
2. Add `ProviderCapabilities`.
3. Add `TTSProviderRegistry`.
4. Add `NarrationSegment` / `DocumentSegment` stable model.
5. Add `SegmentNormalizer` English implementation.
6. Apply pronunciation overrides in normalizer.
7. Add `normalizerVersion` to cache identity.
8. Preserve Kokoro output/behavior.
9. Add provider registry and golden segmentation/normalization tests.
10. Acceptance:
    - UI can query capabilities.
    - Segment IDs deterministic across runs.
    - Existing Kokoro tests pass.

## 10.3 Phase 2 — Cache and playback scheduler / infrastructure polish

1. Harden cache identity and key encoding.
2. Add cache schema version/migration.
3. Include segment/provider/model/normalizer/voice/rate/override identities.
4. Add secondary content-addressed cache index.
5. Add `getBufferedSeconds()` and generation backpressure.
6. Add silent canary probe.
7. Keep scheduler behavior stable.
8. Tests:
   - cache invalidation.
   - migration.
   - LRU eviction.
   - opening coverage.
   - scheduler regression.
9. Acceptance:
   - old cache readable or safely invalidated.
   - no composite-key corruption.
   - no scheduler regression.

## 10.4 Phase 3 — Timing and highlighting correctness / UX

1. Add `TimingMetadataStore`.
2. Store timing truth/confidence/provenance.
3. Add `HighlightSyncController`.
4. Connect word/sentence/segment modes to provider capabilities.
5. Add drift diagnostics and boundary correction.
6. Formalize seek-within-segment where feasible.
7. Add Readest-style reader controls/back-to-current/media improvements selectively.
8. Acceptance:
   - Kokoro remains word-followed.
   - Nano/Pocket remain segment-followed.
   - Invalid timing never produces fake word highlights.

## 10.5 Phase 4 — Model/provider expansion and user-visible features

1. Harden `KokoroProvider`.
2. Add voice formula parser and tensor blend.
3. Add bounded LRU for blended tensors.
4. Add `ExperimentalModelGate` with criteria UI.
5. Add license-aware provider descriptors.
6. Consider optional providers (Edge/Piper/cloud/BYO API) behind opt-in.
7. Keep Qwen disabled unless gates pass.
8. Acceptance:
   - Voice formula persists and blends audibly.
   - Experimental criteria surfaced.
   - Provider expansion cannot affect stable path.

## 10.6 Phase 5 — Production hardening

1. Add long-form stress tests: 10/30/60-minute and possibly 12-hour runs.
2. Add real EPUB/PDF regression fixtures.
3. Add crash/restart telemetry.
4. Add user bug-report diagnostics bundle.
5. Add cache growth controls.
6. Add package validation and CPU/memory budgets.
7. Document provider support matrix.
8. CI/eval gates:
   - p95 first audio threshold.
   - drift threshold.
   - cache cap.
   - fallback timing.
9. Acceptance:
   - TTS responsive across long sessions.
   - provider failures explainable.
   - cache bounded.
   - Kokoro behavior unchanged.

---

# 11. Test strategy outline

## 11.1 Unit tests

1. Audio scheduler:
   - word timing drift.
   - chunk-boundary callbacks.
   - pause/resume gaps.
   - tempo/rate changes.
   - silence hold/adaptive lag new cases.
2. Narration planner:
   - mixed paragraphs.
   - dialogue.
   - quotes.
   - abbreviations.
   - headings/footnotes/tables.
3. Pause detection:
   - clause/sentence/paragraph classification.
   - future locale corpora.
4. Strategy/provider contract:
   - mock provider with all capability combinations.
   - every provider satisfies `TTSProvider`.
5. Cache:
   - position keys.
   - content keys.
   - provider/model/voice/rate/override/normalizer changes.
   - corruption/migration.
6. Segment normalizer:
   - currency.
   - time.
   - dates.
   - abbreviations.
   - initials.
   - URLs.
   - decimals.
   - citations.
7. Voice formula parser:
   - whitespace.
   - invalid/negative weights.
   - unknown voices.
   - tensor shape.
8. Experimental gate:
   - provider criteria.
   - promotion blocked if unmet.
9. Diagnostics/perf:
   - telemetry drift.
   - perf mark leaks.

## 11.2 Integration tests

1. Engine + worker:
   - crash injection.
   - model load failure.
   - idle unload race.
   - timeout injection.
2. Kokoro strategy + scheduler:
   - mid-stream rate changes.
   - voice changes.
   - no >100 ms gap on rate change in [D].
3. Qwen:
   - stall injection.
   - mid-stream cancel.
   - still gated.
4. MOSS Nano:
   - stale-start race.
   - owner-token mismatch.
5. Provider fallback:
   - Kokoro fails → Web Speech within target.
   - primary hangs/errors/silence.
6. Long-form:
   - OOM/cache growth/drift.
   - 10/30/60 minute EPUBs.
   - 50k/150k/300k words in [A].

## 11.3 Golden/regression corpora

1. Public-domain EPUB excerpts.
2. Children’s book / fiction / technical / sci-fi / non-fiction / historical samples in [B].
3. Dialogue-heavy sections.
4. Code blocks/lists/headings.
5. Footnotes.
6. Tables.
7. OCR-like PDF text.
8. Scanned/native PDFs.
9. CJK / non-English cases later.
10. Fixed expected segment IDs, word offsets, normalized text hashes.

## 11.4 Eval gates

1. First-audio p50 advisory.
2. First-audio p95 hard gate around 900 ms in [D].
3. Drift over 5 minutes gate around 200 ms in [D].
4. Cache size after corpus/books.
5. Heuristic fallback rate telemetry.
6. Long-form nightly soak for expensive tests.
7. CI-uploadable JSON eval trace artifacts.

---

# 12. Risks and open questions

## 12.1 Technical/runtime risks

1. Long-form stability cannot be proven by static review.
2. Timing drift under:
   - upstream `kokoro-js` changes.
   - unusual normalization.
   - rate changes.
   - long sessions.
3. Sidecar/runtime packaging for Nano, Pocket, Qwen, Coqui.
4. Python/Torch/ONNX behavior under packaged Electron/asar/antivirus/process cleanup.
5. CPU/memory load for Coqui/Qwen and low-end devices.
6. Cache growth and eviction/invalidation bugs.
7. UI responsiveness if IO/inference leaks into renderer.
8. Regression against current Kokoro behavior during abstraction rollout.
9. MediaSource stability if adopting [B] topology.
10. Voice tensor blending may produce unusable output; needs probe.
11. `normalizerVersion` invalidation needs telemetry.

## 12.2 Product/UX risks

1. Word-level highlighting promise may be overbroad.
2. Provider-specific pause semantics vary.
3. 350 ms cursor lag may need rate/user testing.
4. Heuristic fallback may be poor for non-English.
5. Web Speech `onboundary` reliability must be detected per platform.
6. PDF mapping is hardest structural problem.
7. Background pre-render can waste CPU; [B] recommends wait for first Play.
8. Diagnostics UI could be useful but adds complexity.

## 12.3 Licensing/commercial risks

1. Coqui model-specific license/TOS variance.
2. XTTS-v2 CPML/non-commercial in [B]/[D].
3. MOSS-Nano commercial clarity.
4. Edge TTS ToS/commercial use uncertainty.
5. License fields required for all provider/model descriptors.
6. User consent for model downloads/voice packs.

## 12.4 Source-confidence risks

1. [B] current Blurby claims are assumed due to inaccessible repo.
2. [C] current Blurby claims rely on audit package docs, not direct current source.
3. [A]/[D] direct code claims still static; runtime validation pending.
4. Markor/Sioyek discussions may not have been deeply analyzed in [C].

---

# 13. Adopt / reject / defer decision index

## 13.1 Adopt or evolve

1. Preserve Kokoro scheduler/generation core.
2. Formal `TTSProvider` contract.
3. `TTSProviderRegistry`.
4. Provider capabilities and license metadata.
5. `NarrationSegment` / `DocumentSegment` stable model.
6. `SegmentNormalizer`.
7. Pronunciation override UI/store.
8. Timing metadata store.
9. Highlight sync controller.
10. Cache key hardening and content-addressed index.
11. Buffered-seconds backpressure.
12. Silent canary probe.
13. Voice formula parser/blending.
14. Experimental model gate.
15. Readest-style controls and Foliate traversal lessons.
16. RealtimeTTS-style queue/fallback events.
17. Abogen-style raw/normalized text records.
18. Sioyek line/segment fallback idea.
19. Diagnostics export.
20. Golden corpora and CI eval gates.

## 13.2 Reject or avoid

1. Full rewrite.
2. Replacing Kokoro as primary without evidence.
3. RealtimeTTS as runtime/library dependency.
4. Coqui/Torch as embedded default runtime.
5. Edge/cloud TTS as offline core.
6. Browser/native TTS boundary events as timing truth.
7. Web Speech as primary premium narration.
8. PyAudio/mpv/pygame playback stacks.
9. Synthetic `<audio>` element scheduling where Web Audio already works.
10. Regex-only splitting as primary segmentation.
11. Destructive live text normalization.
12. Restart-line-on-resume.
13. Process re-exec as stop.
14. Hardcoded `device="cpu"` blend fallback.
15. Runtime method rewriting as state model.
16. Shell-heavy generation scripts as core.
17. Treating Markor feature request as code evidence.
18. Promoting experimental engines based only on voice quality.
19. SSML as internal segment payload per [D].
20. Deleting Qwen streaming infrastructure.

## 13.3 Defer

1. Qwen streaming until live CUDA metrics.
2. Pocket TTS until real adapter/gates.
3. Coqui until sidecar spike proves packaging/license/latency/memory/timing.
4. MOSS-Nano default promotion until word timing parity and gates.
5. EPUB3/SMIL/M4B/SRT/ASS export unless audiobook export becomes product goal.
6. MediaSession until mobile/platform priority.
7. Android/native plugin patterns until mobile shell.
8. Language-aware voice memory until multi-language roadmap.
9. PDF text-cleaning patterns until PDF lane sprint.
10. Forced alignment until enhanced-sync/export feasibility spike.

---

# 14. Source-specific unique contribution index

## 14.1 Unique or strongest contributions from [A]

1. Direct static baseline with classification legend.
2. Explicit statement that external repos are not inherently better designs.
3. Full current Blurby baseline table.
4. Provider/capability registry as biggest formalization gap.
5. Cache key slash-splitting bug risk.
6. MOSS Nano segment-only honesty and large PCM IPC concern.
7. Pocket real adapter not configured.
8. Qwen disabled pending decision doc live CUDA validation.
9. `TimingTruth` enum.
10. `TTSProviderCapabilities` with packaging status, GPU/sidecar flags, cacheability, boundary reliability.
11. `NarrationSegment`, `NarrationJob`, `TimingMetadata` interfaces.
12. Model/engine evaluation framework including Kokoro, Nano, Pocket, Qwen, Coqui, RealtimeTTS, system TTS, Edge, Piper, pyttsx3.
13. Roadmap phases 0–5 with component risks.
14. Tests and risk list emphasizing cache key hardening, timing truth, provider diagnostics.
15. Decision: preserve Web Audio scheduler/generation core and add metadata layers.

## 14.2 Unique or strongest contributions from [B]

1. Explicit repo-access caveat and `[Blurby-assumed]` labeling.
2. Strongest “Keep Kokoro incumbent” rationale with CPU viability, size, Apache-2.0, English timestamps.
3. Strongest recommendation to adopt Readest architecture wholesale.
4. Strongest recommendation to port pdf-narrator `clean_pipeline` verbatim.
5. Kokoro out-of-process options:
   - Python sidecar/FastAPI-style.
   - `kokoro-onnx` + `onnxruntime-node` worker.
6. Foliate `tts.js` segmentation claim to eliminate much of segmentation work.
7. Sentence-granularity as production target, word-level as additive.
8. Typed timing metadata artifact as central differentiator.
9. Two-engine quality swap: Web Speech immediately, Kokoro in parallel, swap on boundary.
10. Do not bundle PyTorch.
11. MediaSource/one `<audio>`/SourceBuffer topology.
12. EPUB3 Media Overlay / SMIL export emphasis.
13. Broader provider list: Edge TTS, Piper, cloud APIs/BYO API, OpenAI/ElevenLabs/Azure.
14. Extensive test suggestions: 10-EPUB corpus, 12-hour narration, 20 EPUB + 5 PDF regression set.
15. Runtime validation concerns: Kokoro-ONNX drift, non-English timing, Web Speech boundary matrix, MediaSource stability, Edge TOS, code signing sidecar.

## 14.3 Unique or strongest contributions from [C]

1. Cautious reliance on audit package docs rather than source.
2. Strong “provider-independent narration core” with five hard requirements:
   - deterministic segment IDs.
   - cache keys with normalization/provider/model versions.
   - cancel-safe generation IDs.
   - queue-based scheduling with prefetch depth.
   - timing metadata separated from rendering.
3. Clear segment-first/provider-agnostic/timing-aware conclusion.
4. Strong emphasis on locator-first sync and document mapping.
5. Sentence-level deterministic scheduling as baseline and word-level only when evidence strong.
6. Destructive text normalization as strongest anti-pattern.
7. Cache key formula including doc/segment/provider/model/voice/rate/pitch/normalization/pronunciation/audio format.
8. `SegmentLocator` union: EPUB CFI, PDF text node paths, flat text offsets.
9. Fallback chain: preferred provider → secondary → browser/system → segment-only.
10. Risk that precise Kokoro timing fitness remains open.
11. PDF mapping as hardest structural problem.
12. Provider-specific pause semantics as critical open issue.
13. Diagnostics as first-class subsystem.

## 14.4 Unique or strongest contributions from [D]

1. Most detailed direct-code baseline, v1.75.1, POSTV2-ENGINE-1.
2. Strongest assertion that Blurby is materially ahead of every reviewed codebase for live narration.
3. Specific baseline details:
   - 181 test files and 2,397+ tests.
   - q4 Kokoro ONNX, 28 voices, `af_bella` default, 24 kHz mono.
   - fail-closed model-ready gate.
   - 5-minute idle unload.
   - progressive 13-word cold chunks and 148-word cruise chunks.
   - 8 ms crossfade.
   - 350 ms cursor lag.
   - truth sync every six words.
   - 2GB cache cap.
   - Qwen frame protocol and 8s stall timeout.
4. Explicit missing-capability list.
5. Detailed gap matrix with severity/priority.
6. SegmentNormalizer as biggest opportunity.
7. Pronunciation override UI as second biggest opportunity.
8. Voice blending as low-risk/high perceived value.
9. Text front-end from Coqui and abogen as most valuable external lift.
10. PDF narration lane as weakest format lane.
11. Readest as strategically informative but Blurby ahead where they diverge.
12. Qwen sidecar protocol as reusable stable risk.
13. “No P0 items; Blurby production-ready today” in gap matrix.
14. Detailed proposed TS interfaces and component map.
15. Detailed test/CI gates and risk/mitigation tables.
16. Explicit “what this review does not recommend,” including no SSML internal payload and no removal of Qwen infra.

---

# 15. Final synthesized target state

Blurby should become a **segment-first, provider-agnostic, timing-aware reading narrator** that preserves its existing Kokoro/Web Audio foundation and adds typed metadata/control layers around it.

## 15.1 Load-bearing pieces to preserve

1. Kokoro worker integration.
2. Web Audio scheduler.
3. Real word timestamp validation path.
4. Progressive generation pipeline.
5. Opus disk cache.
6. Existing diagnostics/eval culture.
7. Experimental-model caution and gates.

## 15.2 New layers to add first

1. `TTSProvider` + `TTSProviderRegistry`.
2. `NarrationSegment` / `DocumentSegment`.
3. `SegmentNormalizer`.
4. Hardened `AudioCache` identity.
5. `TimingMetadataStore`.
6. `HighlightSyncController`.
7. `ExperimentalModelGate`.

## 15.3 First implementation bundle

1. Provider capabilities object on every current strategy.
2. Registry wrapper with no behavior change.
3. Stable segment IDs from current planner/pipeline.
4. English `SegmentNormalizer` behind flag.
5. `normalizerVersion` in cache key.
6. Golden tests for segmentation/normalization.
7. Cache key encoding/migration tests.
8. Kokoro regression suite run before and after.

## 15.4 Long-term differentiator

The differentiator is not “more engines”; it is **truthful synchronized reading**:

1. Stable document segments.
2. Typed audio and timing sidecars.
3. Provider capability truth.
4. Word-level highlight only when validated.
5. Safe degradation to sentence/segment following.
6. Cache reuse that respects normalization/model/provider versions.
7. Diagnostics that make drift/fallbacks explainable.
