# MOSS vs Kokoro Listening Review

## Status

- Sprint owner: `MOSS-2`
- Review status: `PENDING`
- Comparison rule: use the same passage text for MOSS and Kokoro before recording a judgment.
- Required listeners: `Pending`

## Passage Slate

| Passage | Source / Fixture | MOSS run | Kokoro run | Notes |
|---|---|---|---|---|
| Short smoke | Pending | Pending | Pending | Quick sanity pass for startup and basic prosody. |
| Punctuation-heavy | Pending | Pending | Pending | Stress commas, semicolons, quotes, parentheses, dashes, and sentence endings. |
| Dialogue | Pending | Pending | Pending | Check speaker turns, interruption feel, and continuity across quoted speech. |
| Dense philosophy paragraph | Pending | Pending | Pending | Check sustained abstract prose, clause grouping, and listener fatigue. |
| Full EPUB section | Pending | Pending | Pending | Check live-book feasibility over a realistic section boundary. |

## Listener Worksheet

| Listener | Host | Passage | Engine | Prosody | Punctuation handling | Dialogue continuity | Fatigue | Artifacts / noise | Startup wait perception | Continuity | Overall preference | Notes |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Pending | Pending | Short smoke | MOSS | Pending | Pending | Pending | Pending | Pending | Pending | Pending | Pending | Pending |
| Pending | Pending | Short smoke | Kokoro | Pending | Pending | Pending | Pending | Pending | Pending | Pending | Pending | Pending |
| Pending | Pending | Punctuation-heavy | MOSS | Pending | Pending | Pending | Pending | Pending | Pending | Pending | Pending | Pending |
| Pending | Pending | Punctuation-heavy | Kokoro | Pending | Pending | Pending | Pending | Pending | Pending | Pending | Pending | Pending |
| Pending | Pending | Dialogue | MOSS | Pending | Pending | Pending | Pending | Pending | Pending | Pending | Pending | Pending |
| Pending | Pending | Dialogue | Kokoro | Pending | Pending | Pending | Pending | Pending | Pending | Pending | Pending | Pending |
| Pending | Pending | Dense philosophy paragraph | MOSS | Pending | Pending | Pending | Pending | Pending | Pending | Pending | Pending | Pending |
| Pending | Pending | Dense philosophy paragraph | Kokoro | Pending | Pending | Pending | Pending | Pending | Pending | Pending | Pending | Pending |
| Pending | Pending | Full EPUB section | MOSS | Pending | Pending | Pending | Pending | Pending | Pending | Pending | Pending | Pending |
| Pending | Pending | Full EPUB section | Kokoro | Pending | Pending | Pending | Pending | Pending | Pending | Pending | Pending | Pending |

## Feasibility Decision

Select one live-book feasibility decision after paired listening and warm-run timing evidence:

- `stream live`
- `pre-buffer only`
- `cache-ahead only`
- `not viable`
- `needs more evidence`

Decision: `needs more evidence`

Rationale: `Pending paired MOSS vs Kokoro listening review.`

## Hardware And Runtime Reminder

Do not demote Nano from one slow run. If MOSS is too slow after warmup, try native ARM64 clang or WSL2 before making the feasibility decision.
