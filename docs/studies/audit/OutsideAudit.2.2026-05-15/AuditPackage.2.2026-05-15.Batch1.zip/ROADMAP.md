# Blurby — Development Roadmap

**Last updated**: 2026-05-15 PM2 — Findings integration from cross-codebase TTS literature review (2026-05-11, 765 lines) and Kokoro TTS implementation review (2026-05-15, 382 lines). TTS-CACHE-HARDEN-1 added (cache-hit timing parity, type harmonization, IPC validation). Conveyor reshaped: ENGINE-DORMANCY-1 → TTS-INTEGRATE-1 → TTS-CACHE-HARDEN-1 → TTS-EVENT-SYNC-1 → NORMALIZER-ENRICH-1 → TTS-RENDER-MAP-1 → TTS-PIPELINE-1 → TTS-ARCH-DOC-1.
**Current branch**: `main`
**Current state**: v1.75.1 stable, with package metadata aligned to v1.75.1. EINK-6A, EINK-6B, GOALS-6B, MOSS-NANO-13a, MOSS-NANO-13B, MOSS-NANO-13c, MOSS-NANO-13d, MOSS-NANO-13e, POCKET-TTS-1, POLISH-1, RELEASE-1, POSTV2-REL-1, POSTV2-ENGINE-1, POSTV2-NARR-1, POSTV2-REVIEW-1, KOKORO-DEEPEN-1, KOKORO-DEEPEN-2, KOKORO-DEEPEN-3, TTS-REGISTRY-1, TTS-NORMALIZE-1, and TTS-CACHE-TIMING-1 have landed in the Desktop v2.0/post-v2 remediation conveyor. TTS-SYNC-1 is complete and pushed on `sprint/tts-sync-1-highlight-controller` but not yet merged to canonical `main`; stacked TTS-DIAG-1 is complete and pushed on `sprint/tts-diag-1-diagnostics-bundle` but likewise not yet merged. TTS-INTEGRATE-1 prepared the combined integration branch in `C:\tmp\Blurby-tts-integrate-1`, but it is blocked by the full-suite MOSS Nano probe lane and has not been committed, pushed, or merged. QWEN-STREAM-4 closed with ITERATE and Qwen remains disabled. MOSS-NANO-13d produced the first real app-selected Nano four-mode evidence artifact and the gate passed cleanly with decision `NANO_RECOMMENDED_OPT_IN`. MOSS-NANO-13e records that as the bounded product decision: Nano is recommended opt-in, Kokoro remains default/available, and Qwen is retired for Desktop v2 and remains disabled. POCKET-TTS-1 adds Pocket TTS as an available opt-in engine with sidecar, IPC/preload, renderer strategy, settings/preview selection, and no public voice-cloning UX in v2.0. TTS-REGISTRY-1 centralizes provider capability and settings copy truth for Web Speech, Kokoro, disabled Qwen, MOSS-Nano, and Pocket TTS; playback strategy selection remains unchanged. TTS-NORMALIZE-1 adds a pure spoken-text normalization layer and lazy cache invalidation identity while preserving original display/highlight words. TTS-CACHE-TIMING-1 adds structured cache keys and timing sidecars while preserving legacy cache safety. The approved post-v2 TTS investment path remains Kokoro-centered architecture hardening: pipeline integration, readiness probes, registry dispatch, and architecture docs without reopening default-engine churn.
**Governing roadmap**: This file is the single source of truth. Phase overview archived from `docs/project/ROADMAP_V2_ARCHIVED.md`.
**Finish line**: TTS Architecture Complete — every implicit TTS architecture decision made explicit, tested, and debuggable with Kokoro as the sole active engine. Provider registry, segment normalization, cache/timing sidecars landed; MOSS-Nano and Pocket TTS placed in dormancy (disabled at settings boundary, same pattern as Qwen); remaining work: engine dormancy enforcement, integrate sync/diagnostics branches, cache/pipeline hardening (findings-driven), event-driven word boundary sync (research-driven), normalizer enrichment (abogen-informed), pre-built word position index (sioyek-inspired), pipeline integration tests, and architecture decisions document. When this phase completes, KOKORO-EXPORT-1 can produce audiobook/subtitle artifacts without foundational work. Android, Cloud Sync, RSS/News remain deferred. Qwen retired/disabled; MOSS-Nano dormant/disabled; Pocket TTS dormant/disabled; Kokoro sole active engine.
**Roadmap reviews**: 2026-05-02 AM (initial ceremony, baseline) → 2026-05-02 PM (scope expanded for MOSS-NANO) → 2026-05-04 PM (13d evidence closeout; 13e product-decision rescope) → 2026-05-10 PM (Abogen Kokoro review; Kokoro Deepening Program approved after POSTV2 review) → 2026-05-11 PM (TTS synthesis review; Kokoro-centered architecture conveyor promoted) → 2026-05-14 PM (TTS Architecture Complete finish line; adversarial review of TTS literature; 18 sprints archived; 7-sprint conveyor established) → 2026-05-15 PM (roadmap review ceremony; TTS-ARCH-DOC-1 full spec; eager-spec buffer 7/7; 87% complete; GREEN) → **2026-05-15 PM2 (findings integration; TTS-CACHE-HARDEN-1 added; 8-sprint conveyor; eager-spec buffer 8/8; 63% complete; GREEN)**. Latest assessment: `docs/project/roadmap-reviews/2026-05-15-pm2-assessment.md`. Latest plan: `docs/project/roadmap-reviews/2026-05-15-pm2-plan.md`. Phase brief: `docs/project/roadmap-reviews/2026-05-15-pm2-phase-brief.md`.

> **Navigation:** Forward-looking sprint specs below. Completed sprint full specs archived in three files: `docs/project/ROADMAP_ARCHIVE.md` (legacy, Phases 1–6), `docs/project/ROADMAP_ARCHIVE_2026-05-02.md` (2026-05-02 roadmap review), and `docs/project/ROADMAP_ARCHIVE_2026-05-14.md` (2026-05-14 roadmap review — EINK-6A/6B, GOALS-6B, MOSS-NANO-13a–13e, POCKET-TTS-1, POLISH-1, KOKORO-DEEPEN-1/2/3, TTS-REGISTRY-1, TTS-NORMALIZE-1, TTS-CACHE-TIMING-1). TTS-SYNC-1 closeout: `docs/Close-Outs/CloseOut.TTS-SYNC-1.2026-05-15.md`; TTS-DIAG-1 closeout: `docs/Close-Outs/CloseOut.TTS-DIAG-1.2026-05-15.md`; TTS-INTEGRATE-1 closeout: `docs/Close-Outs/CloseOut.TTS-INTEGRATE-1.2026-05-15.md`. Phase 1 fix specs in `docs/audit/AUDIT 1/AUDIT 1. STEP 2 TEAM RESPONSE.md`.
>
> **Sprint closeout convention:** Unless a sprint explicitly says otherwise, every successful CLI sprint auto-merges as part of closeout: stage specific files, commit on the sprint branch, merge to `main` with `--no-ff`, push, then update governance docs to reflect the landed state.

---

## Execution Order

```
Phase 1: Stabilization (AUDIT-FIX 1A–1F) ── COMPLETE (v1.4.14)
    │
    ▼
Phase 2: EPUB Content Fidelity ── COMPLETE (v1.5.1)
    │
    ▼
Phase 3: Flow Mode Redesign ── COMPLETE (v1.6.1)
    │
    ▼
Phase 4: Blurby Readings ── COMPLETE (v1.9.0)
    │
    ▼
Phase 5: Read Later + Chrome Extension
  ├── 5A ✅ E2E + Queue (v1.10.0)
  └── 5B → EXT-5B: Pairing UX ✅
    │
    ▼
Phase 6: TTS Hardening & Stabilization ── COMPLETE (v1.37.1)
  ├── TTS-6C→6S + HOTFIX-11 ✅ (v1.14.0–v1.28.0)
  ├── TTS-7A→7R + EXT-5C + HOTFIX-12 ✅ (v1.29.0–v1.37.1)
  │
  │  Desktop v2.0 Conveyor (active — see § Desktop v2.0)
  ├── EINK-6A: E-Ink Foundation ✅
  ├── EINK-6B: E-Ink Reading Ergonomics ✅
  └── GOALS-6B: Reading Goal Tracking ✅
    │
    ▼
SELECTION-1: Word Anchor Contract (BUG-151/152/153 absorbed) ✅
    │
HOTFIX-14: Import & Connection Fixes (BUG-155/156/157/158) ✅
    │
HOTFIX-15: Narration Cursor Polish (BUG-159/160/161) ✅
    │
    ├───────────────────────────────────┐
    ▼                                   ▼
Track A: Flow Infinite Reader    Track B: Chrome Extension Enrichment
  ├── FLOW-INF-A: Reading Zone ✅   ├── EXT-ENR-A: Resilient Connection ✅
  ├── FLOW-INF-B: Timer Cursor ✅  ├── EXT-ENR-B: Auto-Discovery Pairing ✅
  └── FLOW-INF-C: Cross-Book ✅     └── EXT-ENR-C: In-Browser Reader (optional)
    │                                   │
    └──────────────┬────────────────────┘
                   │
    NARR-TIMING: Real Word Timestamps ✅ (v1.44.0)
                   │
    STAB-1A: Startup & Flow Stabilization ✅ (v1.45.0)
                   │
    PERF-1: Full Performance Audit & Remediation ✅ (v1.47.0)
                   │
    REFACTOR-1A: ReaderContainer Decomposition ✅ (v1.48.0)
                   │
    REFACTOR-1B: Component & Style Cleanup ✅ (v1.49.0)
                   │
    TEST-COV-1: Critical Path Test Coverage + Security ✅ (v1.50.0)
                   │
    NARR-LAYER-1A: Narration as Flow Layer — Foundation ✅ (v1.51.0)
                   │
    NARR-LAYER-1B: Narration as Flow Layer — Consolidation ✅ (v1.52.0)
                   │
    TTS-EVAL-1: Flow/Narration Sync and Audio Quality Harness ✅ (v1.53.0)
                   │
    TTS-EVAL-2: TTS Evaluation Matrix & Soak Runner ✅ (v1.54.0)
                   │
    TTS-EVAL-3: TTS Quality Gates & Release Baseline ✅ (v1.55.0)
                   │
    TTS-HARDEN-1: Kokoro Bootstrap & Engine Recovery ✅ (v1.56.0)
                   │
    TTS-HARDEN-2: Narration Handoff Integrity & Extraction Dedupe ✅ (v1.57.0)
                   │
    TTS-RATE-1: Pitch-Preserving Tempo for Kokoro ✅ (v1.58.0)
                   │
    EPUB-TOKEN-1: Dropcap + Split-Token Word Stitching ✅ (v1.59.0)
                   │
    TTS-CONT-1: Readiness-Driven Continuity ✅ (v1.60.0)
                   │
    TTS-RATE-2: Segmented Live Rate Response ✅ (v1.61.0)
                   │
    TTS-START-1: Startup Parity & Opening Cache Contract ✅ (v1.62.0)
                   │
    READER-4M-1: Infinite-Scroll Surface Recovery & Explicit Mode Foundation
                   │
    QWEN-PROT-2: Qwen Sidecar Runtime & Live Prototype Playback
                   │
    QWEN-DEFAULT-1: Flip the Product Default to Qwen
                   │
    QWEN-HARDEN-1: Startup, Playback, and Decision-Quality Evidence
                   │
    QWEN-PROVISION-1: Deterministic Provisioning and Supported-Host Policy
                   │
    QWEN-STREAM-1: Streaming Sidecar Foundation (Lane D — parallel-safe) ✅ (v1.71.0)
                   │
    QWEN-STREAM-2: Accumulator + Strategy + Live Playback ✅ (v1.73.0)
                   │
    QWEN-STREAM-3: Streaming Hardening + Evidence + Decision Gate ✅ (v1.74.0)
                   │
    QWEN-STREAM-4: Live Validation + Promotion Decision ✅ (v1.75.0, ITERATE)
      ├── *Historical posture (as of QWEN-STREAM-4 close, v1.75.0):* Qwen was the default narration engine; Kokoro was the deprecated legacy fallback; streaming Qwen lane closed at ITERATE rather than PROMOTE.
      ├── *Current posture (as of v1.75.1, post MOSS-NANO-13e):* Qwen is **retired for Desktop v2 and disabled**; Kokoro is the **default and operational floor**; MOSS-Nano is **recommended opt-in** from 13d's clean `NANO_RECOMMENDED_OPT_IN` provenance gate and 13e's product decision closeout. This is not a default-engine change.
      └── See `docs/governance/QWEN_SUPPORTED_HOST_POLICY.md` for current Qwen disable rationale and `docs/testing/MOSS_DECISION_LOG.md` for the latest engine-posture decisions.
                   │
    MOSS-0: Flagship Feasibility And Host Truth ✅
                    │
    MOSS-1: CPU-Only Runtime Bring-Up Outside Blurby ✅
                    │
    MOSS-2: Live-Book Flagship Feasibility And Decision Evidence ✅
                    │
    MOSS-SPEED-1: Flagship Runtime Performance Rescue ✅ (PAUSE_RUNTIME_UNSTABLE)
                    │
    MOSS-RCA-1: Flagship Runtime Root-Cause Autopsy ✅ (KEEP_PAUSED_ROOT_CAUSE_CONFIRMED)
                    │
    MOSS-RUNTIME-1: Make Flagship Runtime Real ✅ (KEEP_PAUSED_RUNTIME_CONFIRMED)
                    │
    MOSS-HOST-1: Native/WSL Runtime Escape Hatch ✅ (KEEP_PAUSED_HOST_CONFIRMED)
                    │
    MOSS-HOST-2: WSL ARM64 Evidence Normalization ✅ (KEEP_PAUSED_HOST_CONFIRMED)
                    │
    MOSS-NANO-1: CPU Realtime Candidate Bring-Up ✅ (ITERATE_NANO_RUNTIME)
                    │
    MOSS-NANO-2: Runtime Latency Rescue ✅ (KEEP_KOKORO_ONLY)
                    │
    MOSS-NANO-3: In-Process Runtime Reuse And First-Audio Truth ✅ (ITERATE_NANO_RESIDENT_RUNTIME)
                    │
    MOSS-NANO-4: Resident Runtime Optimization + Promotion Retest ✅ (ITERATE_NANO_RESIDENT_RUNTIME)
                    │
    MOSS-NANO-5B: Precompute + Adjacent Continuity Closure ✅ (ITERATE_NANO_RESIDENT_RUNTIME)
                    │
    MOSS-NANO-5C: Segment-First Soak Gate ✅ (PROMOTE_NANO_TO_SOAK_CANDIDATE_WITH_SEGMENT_FIRST_GATE)
                    │
    MOSS-NANO-6B: Resident Soak Memory / Lifecycle Closure ✅ (ITERATE_NANO_RESIDENT_RUNTIME)
                    │
    MOSS-NANO-6C: Memory / Tail-Latency / Lifecycle Fix ✅ (ITERATE_NANO_RESIDENT_RUNTIME)
                    │
    MOSS-NANO-6D: Bounded Resident Lifecycle / Process Recycling ✅ (ITERATE_NANO_RESIDENT_RUNTIME)
                    │
    MOSS-NANO-6E: Shutdown / Restart Lifecycle Proof ✅ (ITERATE_NANO_RESIDENT_RUNTIME)
                    │
    MOSS-NANO-6F: Full Bounded Soak Promotion Confirmation ✅ (PROMOTE_NANO_TO_APP_PROTOTYPE_CANDIDATE_WITH_BOUNDED_LIFECYCLE)
                    │
    MOSS-NANO-7: Sidecar Contract + IPC Prototype ✅ (PROMOTE_NANO_TO_STRATEGY_PROTOTYPE)
                    │
    MOSS-NANO-8: Narration Strategy + Segment Timing ✅ (PROMOTE_NANO_TO_CONTINUITY_PROTOTYPE)
                    │
    MOSS-NANO-9: Cache/Prefetch + Continuity Handoffs ✅ (PROMOTE_NANO_TO_EXPERIMENTAL_UI_CANDIDATE)
                    │
    MOSS-NANO-10: Settings UX + Engine Selection ✅ (PROMOTE_NANO_TO_PRODUCTIZATION_GATE)
                    │
    MOSS-NANO-11: Productization Gate + Default Decision ✅ (NANO_EXPERIMENTAL_ONLY / KEEP_KOKORO_DEFAULT)
                    │
    MOSS-NANO-12: Live Four-Mode Evidence Capture ✅ (NANO_EXPERIMENTAL_ONLY)
                    │
    MOSS-3: Legacy flagship sidecar lane (SUPERSEDED/PAUSED)
                    │
    MOSS-4: Live Narration Strategy And Engine Selection (PAUSED)
                    │
    MOSS-5: Timing Truth And Segment-Following Narrate (PAUSED)
                    │
    MOSS-6: Cache, Prewarm, And Long-Form Continuity (PAUSED)
                    │
    MOSS-7: Productization Gate And Promotion Decision (PAUSED)
      ├── Kokoro: sole active engine. All TTS energy directed to Kokoro optimization (quality, timing, reliability).
      ├── Nano: dormant/disabled at settings boundary as of ENGINE-DORMANCY-1 (2026-05-15). Can be reactivated by changing registry posture.
      └── Pocket TTS: dormant/disabled at settings boundary as of ENGINE-DORMANCY-1 (2026-05-15). Can be reactivated by changing registry posture.
                   │
    READER-4M-2: Standalone Narrate Mode & Four-Button Controls ✅ (v1.69.0)
                   │
    READER-4M-3: Global Word Anchor & Cross-Mode Continuity ✅ (v1.72.0)
                   │
    ── TTS Architecture Completion (active conveyor — Kokoro-only) ──
                   │
    ENGINE-DORMANCY-1: Disable MOSS-Nano & Pocket TTS (same pattern as Qwen)
                   │
    TTS-INTEGRATE-1: Merge TTS-SYNC-1 + TTS-DIAG-1 to main (unblocked by dormancy)
                   │
    TTS-CACHE-HARDEN-1: Cache/Pipeline Hardening (findings: impl review A8 + lit review §4.6)
                   │
    TTS-EVENT-SYNC-1: Event-Driven Word Boundary Sync (research: readest + RealtimeTTS + sioyek)
                   │
    NORMALIZER-ENRICH-1: Kokoro Text Normalization Gap Fill (research: abogen)
                   │
    TTS-RENDER-MAP-1: Pre-Built Word Position Index (research: sioyek)
                   │
    TTS-PIPELINE-1: Pipeline Integration Tests & Fixture Expansion
                   │
    TTS-ARCH-DOC-1: TTS Architecture Decisions Document
                   │
                   ▼
        KOKORO-EXPORT-1: Long-Form Audio Export (optional future)
                   │
                   ▼
        Track C: Android APK
          ├── APK-0: Modularization (prerequisite)
          ├── APK-1: WebView Shell + Local Library
          ├── APK-2: All Reading Modes
          ├── APK-3: Bidirectional Sync
          └── APK-4: Mobile-Native Features
                   │
                   ▼
        Phase 7: Cloud Sync Hardening (parallel with APK-3)
                   │
                   ▼
        Phase 8: RSS/News Feeds
```

---

## Phases 2–5 — COMPLETE

> All Phase 2–5 sprint specs archived to `docs/project/ROADMAP_ARCHIVE.md`. Summary below.

| Phase | Sprints | Final Version | Key Deliverables |
|-------|---------|---------------|------------------|
| 2: EPUB Fidelity | EPUB-2A, EPUB-2B | v1.5.1 | Format preservation, image extraction, DOCX/URL→EPUB, single rendering path |
| 3: Flow Mode | FLOW-3A, FLOW-3B | v1.6.1 | Infinite scroll, FlowScrollEngine, dead code removal |
| 4: Readings | READINGS-4A, 4B, 4C | v1.9.0 | Card metadata, queue, author normalization, metadata wizard |
| 5: Chrome Extension | EXT-5A, EXT-5B + TTS Smoothness | v1.11.0 | E2E pipeline tests, 6-digit pairing, background cache wiring |

---

## Phase 6 — TTS Hardening & Stabilization + Follow-On Hotfixes

> All TTS-6 and TTS-7 sprint specs archived to `docs/project/ROADMAP_ARCHIVE.md`. Summary below.

| Lane | Sprints | Versions | Key Deliverables |
|------|---------|----------|------------------|
| TTS-6 | TTS-6C→6S + HOTFIX-11 | v1.14.0–v1.28.0 | Native-rate buckets, startup hardening, pronunciation overrides, word alignment, accessibility, profiles, portability, runtime stability, performance budgets, session continuity, diagnostics, cursor sync |
| TTS-7 (stabilization + hotfix) | TTS-7A→7L | v1.29.0–v1.33.7 | Cache correctness, cursor contract (dual ownership), throughput/backpressure, integration verification, proactive entry-cache coverage + cruise warm, clean Foliate DOM probing, first-chunk IPC verification, visible-word/startup fixes, Foliate follow-scroll unification + exact miss recovery, final Foliate section-sync / word-source dedupe / initial-selection protection, EPUB global word-source promotion, and exact text-selection mapping. TTS hotfix lane CLOSED at v1.33.7. |

**Architecture post-stabilization:** Narration state machine, cache identity contract (voice + override hash + word count), cursor ownership (playing = TTS owns, paused = user owns), pipeline pause/resume (emission gating), backpressure (TTS_QUEUE_DEPTH), narration start <50ms per microtask. Documented in TECHNICAL_REFERENCE.md § "Narrate Mode Architecture."

**Closeout note:** Live testing on 2026-04-04 showed that cold-start narration on freshly opened EPUBs still had page-jump and ramp-up continuity regressions after `TTS-7E`. `TTS-7F` closed the reactive-cache side of that gap, and `TTS-7G` verified that `BUG-117` (910ms first-chunk IPC handler) was already resolved by prior work. `TTS-7H` fixed the frozen-start-index and section-fallback pieces, `TTS-7I` unified follow-scroll ownership and exact miss recovery, `TTS-7J` resolved section-sync blink, word-source duplication, and initial-selection overwrite, `TTS-7K` promoted full-book EPUB words as the active source of truth, and `TTS-7L` closed the final selection-path gap by preserving exact word identity across click and native text selection. Phase 6 TTS is now fully stabilized and closed at `v1.33.7`.

> All TTS-7E through TTS-7R, EXT-5C, and HOTFIX-12 sprint specs archived to `docs/project/ROADMAP_ARCHIVE.md`.

---


## Completed Work Summary

> Full specs for completed sprints are archived across `docs/project/ROADMAP_ARCHIVE.md`, `docs/project/ROADMAP_ARCHIVE_2026-05-02.md`, and `docs/project/ROADMAP_ARCHIVE_2026-05-14.md`.

| Sprint | Version | Date | Result | Archive |
|--------|---------|------|--------|--------|
| TTS-DIAG-1 | — | 2026-05-15 | Provider-neutral `tts-diagnostics-v1` narration diagnostics bundle added on pushed stacked branch `sprint/tts-diag-1-diagnostics-bundle` (`c97e446`). Bundle captures provider capabilities, engine/voice/rate, segment IDs, original/normalized hashes, cache key components, timing sidecar summaries, scheduler truth events, highlight sync decisions, and relevant errors while stripping/rejecting raw text and audio-shaped payloads. Canonical `main` merge pending until TTS-SYNC-1 lands. | [Closeout](docs/Close-Outs/CloseOut.TTS-DIAG-1.2026-05-15.md) |
| TTS-SYNC-1 | — | 2026-05-15 | Timing metadata and highlight sync policy centralized on pushed branch `sprint/tts-sync-1-highlight-controller` (`142dc24`). `TimingMetadataStore` stores trusted/heuristic/missing timing metadata; `HighlightSyncController` allows word sync only for trusted word-native timing and downgrades heuristic/missing timing to chunk/segment decisions with no invented active word. Canonical `main` merge pending because main worktree is dirty. | [Closeout](docs/Close-Outs/CloseOut.TTS-SYNC-1.2026-05-15.md) |
| TTS-CACHE-TIMING-1 | — | 2026-05-13 | Structured v2 TTS cache identity and `.timing.json` sidecars added while preserving legacy v1 cache reads. New entries carry schema/versioned provider, voice, rate, model, source/normalized hashes, normalizer version, pronunciation override hash, document locator, chunk ID, sample rate, and timing truth. | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-14.md) |
| TTS-NORMALIZE-1 | — | 2026-05-13 | Deterministic spoken segment normalization added with original/normalized metadata, versioned hashes, golden fixtures, and Kokoro cache identity participation while preserving original display/highlight words. | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-14.md) |
| TTS-REGISTRY-1 | — | 2026-05-12 | Provider capability truth added for Web Speech, Kokoro, disabled Qwen, MOSS-Nano, and Pocket TTS. Settings/status surfaces read scoped provider labels, posture, and readiness hints from the registry. Playback behavior and engine posture unchanged. | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-14.md) |
| KOKORO-DEEPEN-3 | — | 2026-05-11 | Weighted Kokoro voice formulas are non-viable on Blurby's current `kokoro-js` / ONNX runtime. Valid single voices pass; weighted formula strings are rejected as unknown voice IDs; no public voice-mixing UX or runtime replacement was introduced. | `docs/testing/kokoro-voice-mixing-evidence.md`; durable closeout landed |
| KOKORO-DEEPEN-2 | — | 2026-05-11 | Kokoro-backed Narrate now uses shared natural chunks, light chunk highlight, trusted-timestamp-only bold word highlight, and chunk-only fallback when timing is missing. | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-14.md) |
| KOKORO-DEEPEN-1 | — | 2026-05-11 | Kokoro readiness/preflight truth added across main process, IPC/preload, renderer settings, shared types, tests, and setup/troubleshooting docs while preserving Kokoro default playback semantics. | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-14.md) |
| POSTV2-REVIEW-1 | — | 2026-05-11 | Post-v2 remediation and CHUNK-SYNC Flow visual work reviewed, committed, merged, and pushed; governance advanced to the Kokoro Deepening lane. | `docs/Close-Outs/CloseOut.POSTV2-AUDIT-REMEDIATION.2026-05-04.md`; active review closeout |
| EINK-6B | v1.75.2 | 2026-05-02 | E-ink Flow now advances by instant 20-line chunks instead of smooth/per-line scroll; Focus phrase grouping is shared/tested for 2-3 word bursts when `einkMode` + `einkPhraseGrouping` are enabled; adaptive ghosting refresh accumulates content-change load while preserving manual page-turn interval fallback. Verification: focused EINK/Flow slice 5 files / 93 tests, full `npm test` 151 files / 2407 tests, `npm run build`, `npm audit --audit-level=high`, `git diff --check`. | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-14.md) |
| EINK-6A | v1.75.1 | 2026-05-02 | E-ink display mode decoupled from theme; `einkMode` schema/defaults/migration added; behavioral CSS now keys off `[data-eink="true"]`; greyscale palette remains optional under `[data-theme="eink"]`. Verification: focused EINK/NARR tests 36 pass, full `npm test` 150 files / 2397 tests, `npm run build`, `npm audit --audit-level=high`, `git diff --check`. | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) (full spec migrated 2026-05-02 PM) |
| SELECTION-1 | v1.38.0 | 2026-04-06 | Word anchor contract, BUG-151/152/153 resolved | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| HOTFIX-14 | v1.38.2 | 2026-04-06 | URL extraction + connection fixes, BUG-155/156/157/158 | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| NARR-CURSOR-1 | v1.40.0 | 2026-04-07 | Collapsing narration cursor | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| HOTFIX-15 | v1.43.1 | 2026-04-07 | Narration cursor polish, BUG-159/160/161 | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| STAB-1A | v1.45.0 | 2026-04-07 | Startup & flow stabilization, BUG-162/163/164/165 | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| PERF-1 | v1.47.0 | 2026-04-07 | Full performance audit & remediation | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| REFACTOR-1A | v1.48.0 | 2026-04-07 | ReaderContainer decomposition, 5 custom hooks | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| REFACTOR-1B | v1.49.0 | 2026-04-07 | Component & style cleanup, CSS split | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| TEST-COV-1 | v1.50.0 | 2026-04-16 | Critical path test coverage + security hardening | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| NARR-LAYER-1A | v1.51.0 | 2026-04-16 | Narration as flow layer foundation | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| NARR-LAYER-1B | v1.52.0 | 2026-04-16 | Narration as flow layer consolidation | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| TTS-EVAL-1 | v1.53.0 | 2026-04-16 | Flow/narration sync and audio quality harness | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| TTS-EVAL-2 | v1.54.0 | 2026-04-16 | TTS evaluation matrix & soak runner | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| TTS-EVAL-3 | v1.55.0 | 2026-04-16 | TTS quality gates & release baseline | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| TTS-HARDEN-1 | v1.56.0 | 2026-04-16 | Kokoro bootstrap truth & engine recovery | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| TTS-HARDEN-2 | v1.57.0 | 2026-04-17 | Narration handoff integrity & extraction dedupe | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| TTS-RATE-1 | v1.58.0 | 2026-04-17 | Pitch-preserving tempo for Kokoro | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| EPUB-TOKEN-1 | v1.59.0 | 2026-04-17 | Dropcap + split-token word stitching | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| FLOW-INF-A | v1.41.0 | 2026-04-07 | Reading zone & visual pacing | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| FLOW-INF-B | v1.42.0 | 2026-04-07 | Timer cursor & pacing feedback | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| EXT-ENR-A | v1.39.0 | 2026-04-07 | Resilient extension connection | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| EXT-ENR-B | v1.43.0 | 2026-04-07 | Auto-discovery pairing | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| NARR-TIMING | v1.44.0 | 2026-04-07 | Real word-level timestamps from Kokoro TTS | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| TTS-CONT-1 | v1.60.0 | 2026-04-17 | Readiness-driven section & cross-book continuity | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| TTS-RATE-2 | v1.61.0 | 2026-04-17 | Segmented live Kokoro rate response | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| TTS-START-1 | v1.62.0 | 2026-04-17 | Startup parity & opening cache contract | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| READER-4M-2 | v1.69.0 | 2026-04-18 | Standalone narrate mode & four-button controls | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| READER-4M-3 | v1.72.0 | 2026-04-19 | Global word anchor & cross-mode continuity | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| QWEN-STREAM-1 | v1.71.0 | 2026-04-18 | Streaming sidecar foundation | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| QWEN-STREAM-4 | v1.75.0 | 2026-04-21 | Live validation + promotion decision (ITERATE) | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| MOSS-NANO-6F | — | 2026-05-01 | Full bounded soak promotion confirmation | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| MOSS-HOST-1 | — | 2026-04-27 | Native/WSL runtime escape hatch | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| MOSS-HOST-2 | — | 2026-04-27 | Evidence normalization + governance closeout | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| MOSS-NANO-1 | — | 2026-04-28 | CPU realtime candidate bring-up | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| MOSS-NANO-2 | — | 2026-04-28 | Runtime latency rescue | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| MOSS-NANO-3 | — | 2026-04-28 | In-process runtime reuse & first-audio truth | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| MOSS-NANO-4 | — | 2026-04-29 | Resident runtime optimization + promotion retest | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| MOSS-NANO-5B | — | 2026-04-29 | Precompute + adjacent continuity closure | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| MOSS-NANO-5C | — | 2026-04-29 | Segment-first soak gate | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| MOSS-NANO-6E | — | 2026-04-30 | Shutdown/restart lifecycle proof | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| MOSS-NANO-6D | — | 2026-04-30 | Bounded resident lifecycle / process recycling | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| MOSS-NANO-6C | — | 2026-04-30 | Memory / tail-latency / lifecycle fix | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| MOSS-NANO-6B | — | 2026-04-29 | Resident soak memory / lifecycle closure | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| MOSS-NANO-7 | — | 2026-04-30 | Sidecar contract + IPC prototype | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| MOSS-NANO-8 | — | 2026-04-30 | Narration strategy + segment timing | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| MOSS-NANO-9 | — | 2026-05-01 | Cache/prefetch + continuity handoffs | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| MOSS-NANO-10 | — | 2026-05-01 | Settings UX + engine selection | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| MOSS-NANO-11 | — | 2026-05-01 | Productization gate + default decision | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| MOSS-NANO-12 | — | 2026-05-02 | Live four-mode evidence capture | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| MOSS-RCA-1 | — | 2026-04-27 | Flagship runtime root-cause autopsy | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| MOSS-RUNTIME-1 | — | 2026-04-27 | Make flagship runtime real | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| MOSS-0 | — | 2026-04-26 | Flagship feasibility & host truth | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| MOSS-1 | — | 2026-04-26 | CPU-only runtime bring-up outside Blurby | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| MOSS-2 | — | 2026-04-26 | Flagship quality & performance benchmark | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| MOSS-SPEED-1 | — | 2026-04-27 | Flagship runtime performance rescue | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| READER-4M-1 | v1.63.0 | 2026-04-18 | Infinite-scroll surface recovery + explicit four-mode foundation | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| QWEN-PROT-1 | v1.64.0 | 2026-04-18 | Qwen engine surface + unavailable-state foundation | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| QWEN-PROT-2 | v1.65.0 | 2026-04-18 | Qwen sidecar runtime + live prototype playback | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| QWEN-STREAM-2 | v1.73.0 | 2026-04-20 | StreamAccumulator + streaming strategy + live playback | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| QWEN-STREAM-3 | v1.74.0 | 2026-04-20 | Streaming hardening + evidence + decision gate | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-02.md) |
| GOALS-6B | — | 2026-05-02 | Reading goal tracking: daily pages, daily minutes, weekly books; settings create/edit/delete; library widget; progress tracking; streak display. | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-14.md) |
| MOSS-NANO-13a | — | 2026-05-03 | Real sidecar adapter: stub replaced with Python subprocess adapter for ONNX synthesis. | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-14.md) |
| MOSS-NANO-13b | — | 2026-05-03 | Engine hardening: timeout enforcement, scope-change invalidation, cache key length-fingerprint. | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-14.md) |
| MOSS-NANO-13c | — | 2026-05-03 | Live evidence schema v2 + producer + gate provenance validation. | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-14.md) |
| MOSS-NANO-13d | — | 2026-05-04 | Live four-mode capture: real app-selected Nano evidence, gate PASS, decision NANO_RECOMMENDED_OPT_IN. | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-14.md) |
| MOSS-NANO-13e | — | 2026-05-04 | Recommended opt-in product decision closeout. Nano recommended opt-in; Kokoro default; Qwen disabled. | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-14.md) |
| POCKET-TTS-1 | — | 2026-05-04 | Pocket TTS engine integration: sidecar, IPC, strategy, settings; available opt-in third engine. | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-14.md) |
| POLISH-1 | — | 2026-05-04 | Desktop v2 polish bundle: TTS settings release posture, E-Ink switches, Goals empty states. | [Archive](docs/project/ROADMAP_ARCHIVE_2026-05-14.md) |
| SK-HYG-1 | — | 2026-05-02 | Roadmap hygiene & queue recovery (governance only). Archive-forward discipline, queue GREEN, Standing Rules, Desktop v2.0 conveyor. | [Review artifacts](docs/project/roadmap-reviews/) |
| BRAND-HYG-1 | — | 2026-05-02 | Shelved / no-op. Expected brand theme edits not present in checkout. | [Review artifacts](docs/project/roadmap-reviews/) |


## Track B: Chrome Extension Enrichment (EXT-ENR)

> **Vision:** The Chrome extension connection becomes effortless and resilient. No manual code entry on reconnect, no dropped connections on sleep/wake, and the app actively invites pairing when it senses an incoming connection attempt.

### Current State (v1.38.2)

- **WebSocket server** (`main/ws-server.js`, 529 lines) — localhost port 48924, custom RFC 6455, pairing token auth via `safeStorage`. HOTFIX-14: auth-filtered `getClientCount()`, 15s heartbeat, 5s UI polling.
- **Chrome extension** (`chrome-extension/`, in-repo) — service-worker.js (592 lines), popup.js (238 lines), popup.html, manifest.json. Flat 5s reconnect, fire-and-forget article send, no pending persistence.
- **Pairing flow** — 6-digit short code with 5min TTL, long-lived token stored in safeStorage (server) + chrome.storage.local (extension). Token survives app restart.
- **Article import** — `add-article` message type, HTML→EPUB conversion, hero image extraction, auto-queue. No delivery confirmation.
- **Known pain points (post-HOTFIX-14):** Flat 5s reconnect (no backoff), pending articles lost on service worker kill, no delivery confirmation, unbounded EADDRINUSE retry, no auth timeout, binary connected/disconnected UI.

### Investigation Gate — Track B: ✅ CLEARED

All three investigation areas resolved:
- **WebSocket lifecycle:** Fully traced. `_clients` Set: add at line 144 (pre-auth), delete on socket close (152), error (157), WS close frame (174), heartbeat fail (466), heartbeat error (473). `getClientCount()` now auth-filtered (HOTFIX-14).
- **Extension source code:** Located at `chrome-extension/` in-repo. Full reconnect logic, state vars, message flow traced.
- **IPC event emission:** Renderer polled via `get-ws-short-code` IPC every 15s (ConnectorsSettings). Push events `ws-connection-attempt` / `ws-pairing-success` now emitted by server (EXT-ENR-B, v1.43.0) — renderer subscribes via `onWsConnectionAttempt` / `onWsPairingSuccess` preload listeners.


### Sprint EXT-ENR-C: In-Browser Reader (Optional/Future)

**Goal:** Standalone RSVP speed-reader in the Chrome extension popup — read articles without Blurby app running.

**Deliverables:**
1. Popup RSVP view (400x500px) — play/pause, WPM slider (100-1200), progress bar
2. Readability extraction in extension — extract article text from current tab
3. Reading queue in extension — `chrome.storage.local`, 50 articles max, 5MB limit
4. Sync with desktop — when Blurby is running, sync queue bidirectionally

**Note:** This is a lower priority enhancement. EXT-ENR-A and EXT-ENR-B address the core pain points. This sprint is documented for completeness but can be deferred.

**Key files:** Chrome extension source (separate repo/directory)

**Tier:** Full | **Depends on:** EXT-ENR-B

---

## Track C: Android APK (APK)

> **Vision:** Blurby on Android — sideloaded APK first, Play Store later. All readings available, reading position synced bidirectionally, new readings addable from mobile, all four reading modes working.

### Prerequisites & Architecture Decision

**Framework decision needed:** Two specs exist:
- `docs/superpowers/specs/.Archive/2026-03-27-android-app-design.md` — React Native + Expo monorepo (better native feel, larger effort)
- `docs/superpowers/specs/.Archive/phase-10-android-app.md` — Capacitor wrapper (max code reuse, faster to ship)

**Recommendation:** Capacitor for sideload MVP. Reasons: (1) reuses existing React code directly, (2) foliate-js already runs in WebView, (3) faster path to testable APK, (4) can always migrate to React Native later if WebView performance is insufficient.

**Mandatory prerequisite:** Modularization — extract platform-independent core from Electron coupling. See APK-0 below.

### Investigation Gate — Track C (Cowork — before any APK dispatch)

| Area | What We Know | What We Don't Know | Investigation Action |
|------|-------------|-------------------|---------------------|
| Framework decision | Two specs exist (RN vs Capacitor). Recommendation: Capacitor. | **User hasn't confirmed.** Also: has Capacitor been tested with foliate-js in a WebView? Does the EPUB rendering actually work? | **Cowork: Decision + POC.** Get user confirmation on Capacitor. Then scaffold minimal Capacitor project, load foliate-js in WebView, open an EPUB. If it works → proceed. If not → re-evaluate. |
| Coupling audit | 5 problem areas identified at high level (TTS worker, auth, sync, file I/O, IPC). | **Exact coupling depth.** How many `require('electron')` calls exist? How many `fs.` calls? Which renderer code accidentally imports Node modules? What's the true scope of modularization? | **Cowork: Deep audit.** Grep for all Electron-specific imports across the codebase. Map every coupling point with file:line. Estimate LOC per abstraction layer. Produce a scoped modularization plan that CLI can execute module-by-module. |
| Mobile TTS | Kokoro uses Node worker with ONNX. Model is ~80MB. | **Does ONNX Runtime work in Capacitor WebView?** Can we use WebAssembly ONNX runtime instead of Node? What's the performance on ARM? | **Cowork: Research.** Check ONNX Runtime Web (WASM) compatibility. Test if Kokoro model loads in browser context. If not, TTS on mobile may need a different approach (Web Speech API fallback, or native ONNX via Capacitor plugin). |
| Cloud sync on mobile | Sync engine is `main/sync-engine.js`, main-process-driven with `fs.promises`. | **Can the sync protocol run in a WebView?** The transport (OneDrive/Google Drive HTTP APIs) could work from browser context, but the file storage layer assumes Node `fs`. | **Cowork: Map sync dependencies.** Identify which sync-engine functions are pure logic (portable) vs platform-bound (Node fs). Estimate extraction effort. |

**Dispatch readiness:** NOT READY. Framework POC, coupling audit, and TTS feasibility all needed before APK-0 can be spec'd to CLI-ready detail.

### Sprint APK-0: Modularization (Prerequisite)

**Goal:** Extract a platform-independent core from the Electron-coupled codebase.

**Responsibility:** Cowork audits and specs each abstraction layer → CLI executes module-by-module extraction.

**Problem areas identified by 3rd-party audit:**
1. **Kokoro TTS worker** (`main/tts-worker.js` L5-L37) — Node-specific module resolution hacks
2. **Auth** (`main/auth.js` L294-L304) — depends on Electron `BrowserWindow` for OAuth popup
3. **Sync engine** (`main/sync-engine.js`) — main-process-driven, uses `fs.promises` directly
4. **File I/O** — all via Node `fs`, no abstraction layer
5. **IPC** — tight coupling between `preload.js` bridge and main-process handlers

**Deliverables (pending investigation gate):**
1. Storage abstraction — interface for file read/write/list/delete
2. Auth abstraction — interface for OAuth flows
3. TTS abstraction — interface for Kokoro model loading and inference
4. Sync transport abstraction — decouple sync logic from Node fs
5. Shared types and constants — extract to `shared/` directory

**Estimated effort:** 2-3 sprints (each sub-module is a separate CLI dispatch)

**Tier:** Full | **Depends on:** Investigation gate cleared

---

### Sprint APK-1: WebView Shell + Local Library

**Goal:** Sideloadable APK that opens Blurby's React UI in a WebView.

**Responsibility:** Cowork specs (after APK-0 modularization lands) → CLI executes scaffolding and integration.

**Investigation gate:** Blocked on APK-0 completion + Capacitor POC from Track C investigation gate.

**Deliverables:**
1. Capacitor project scaffolding — Android project, WebView configuration, build pipeline
2. Local library storage — SQLite or JSON file via Capacitor Filesystem
3. EPUB rendering — foliate-js in WebView (validated by POC)
4. File import — Android file picker + share sheet
5. APK build — signed debug APK for sideloading

**Tier:** Full | **Depends on:** APK-0

---

### Sprint APK-2: All Reading Modes

**Responsibility:** Cowork specs (after APK-1, with mobile gesture design) → CLI executes.

**Investigation gate:** Blocked on APK-1. Touch gesture mapping needs design decisions after seeing the WebView shell.

**Deliverables:**
1. Touch gesture mapping — swipe for page turn, tap zones for mode controls
2. Focus mode — RSVP display adapted for mobile viewport
3. Flow mode — infinite scroll with touch scroll detection
4. Narrate mode — Kokoro TTS via approach determined in investigation gate
5. Bottom bar adaptation — mobile-friendly control layout

**Tier:** Full | **Depends on:** APK-1

---

### Sprint APK-3: Bidirectional Sync

**Responsibility:** Cowork specs (sync protocol design, informed by Phase 7 if available) → CLI executes.

**Investigation gate:** Blocked on APK-2. Sync protocol depends on modularization outcome from APK-0.

**Deliverables:**
1. Cloud sync integration — OneDrive/Google Drive via Capacitor HTTP + OAuth
2. Bidirectional position sync — CFI-based with last-write-wins timestamps
3. Library sync — three-tier storage (metadata local, content on-demand, user-pinned)
4. Settings sync — theme, WPM, voice preferences
5. Conflict resolution — per-field last-write-wins

**Tier:** Full | **Depends on:** APK-2

---

### Sprint APK-4: Mobile-Native Features

**Responsibility:** Cowork specs → CLI executes.

**Investigation gate:** Blocked on APK-3. Native features depend on what the platform supports after integration.

**Deliverables:**
1. Share sheet integration — "Share to Blurby" from Chrome, other apps
2. Notification for reading goals/streaks (if GOALS-6B is implemented)
3. Background TTS playback — audio continues when backgrounded
4. Deep links — `blurby://open/{docId}`
5. Offline-first — graceful degradation when no network

**Tier:** Full | **Depends on:** APK-3

---

## Idea Themes (Roadmap Placeholders)

> Ideas grouped by theme in `docs/governance/IDEAS.md`. Each theme maps to potential future sprints. Not yet spec'd — reviewed at phase pauses.

| Theme | Key Ideas | Roadmap Alignment |
|-------|-----------|-------------------|
| **A: Infinite Reader** | Reading zone, cross-book flow, paragraph jumps | → Track A (FLOW-INF) above |
| **B: Chrome Extension** | Auto-discovery, resilient connection, in-browser reader, RSS | → Track B (EXT-ENR) above |
| **C: Android & Mobile** | APK wrapper, position sync, share sheet, Chromecast | → Track C (APK) above |
| **D: Reading Intelligence** | Goals, streaks, analytics, AI recommendations | GOALS-6B active (Desktop v2.0 conveyor); rest backlog |
| **E: Content & Formats** | Chapter detection, auto TOC, OCR PDFs | Backlog (Phase 10+) |
| **F: Library & UX Polish** | 3-line cards, auto-clear dots, vocab builder, annotation export | Backlog (fold into any sprint) |
| **G: Settings & Ctrl+K** | Combine settings pages, all settings searchable | Backlog (small wins) |
| **H: Reading Tweaks** | Space bar mode, arrow speed, voice cloning, AI summaries | Backlog (bundleable) |
| **I: Branding** | Remove [Sample], Blurby icon, brand theme, window controls | Backlog (cosmetic, anytime) |
| **J: Social** | Reading clubs, shared lists, group discussions | Someday (needs server) |
| **K: E-Ink** | Display mode decoupling, e-ink reading ergonomics | Done for Desktop v2.0 (EINK-6A/6B complete) |

---

## TTS Architecture Completion — Active Conveyor Belt

> **Finish line:** TTS Architecture Complete — make every implicit TTS architecture decision explicit, tested, and debuggable. Desktop v2.0 was achieved; this phase makes the TTS system export-ready.
> **Conveyor sequence:** ~~TTS-SYNC-1~~ PASS/pushed → ~~TTS-DIAG-1~~ PASS/pushed → ENGINE-DORMANCY-1 (dispatch-ready) → TTS-INTEGRATE-1 (unblocked by dormancy) → TTS-CACHE-HARDEN-1 (findings-driven) → TTS-EVENT-SYNC-1 → NORMALIZER-ENRICH-1 → TTS-RENDER-MAP-1 → TTS-PIPELINE-1 → TTS-ARCH-DOC-1.
> **Queue rule:** No exploratory TTS/model or non-desktop expansion work until this conveyor completes. Default engine remains Kokoro; Qwen is retired for Desktop v2 and remains disabled.

### Standing Rules All Skeletons Inherit

1. **PR-2 / PR-3 / POSTV2 type gate:** After any code change run `npm run typecheck` and `npm test`; after any UI/dependency change run `npm run build`.
2. **PR-7:** CSS custom properties for all theming — no inline styles.
3. **PR-10:** All JSON writes must be atomic (write-tmp + rename).
4. **PR-12:** Context for cross-cutting concerns (settings, toasts, theme); props for direct parent-child data.
5. **PR-17:** Never drive imperative DOM animations from React useEffect — use a plain class.
6. **PR-26:** Settings that control a runtime engine must have explicit sync bridges.
7. **SRL-012:** For Full-tier sprints, Solon and Plato tasks MUST be marked parallel-eligible.
8. **Queue depth ≥3:** If queue drops below 3 after completion, stop and backfill before next dispatch.
9. **Spec-compliance before quality:** Each task gets Solon check (does it match spec?) before Plato check (is it well-built?).
10. **Dispatch sizing:** 40 tool-use ceiling per wave. Sprints with 5+ implementation tasks must be pre-split into waves.

Deviation protocol: a skeleton may override a standing rule only by naming the rule and justifying the waiver in its spec.

### Architecture Decisions (Resolved)

#### AD-1: Segment Identity vs Cache Identity

Two distinct identity concepts exist in the TTS pipeline:

**Cache identity** (`TtsCacheIdentityV2.chunkId`): `${bookId}:${startIdx}:${normalizationHash}`. This is normalization-sensitive by design — when `TTS_NORMALIZER_VERSION` changes (e.g., NORMALIZER-ENRICH-1 adds transforms), the same text at the same position gets a new `chunkId`, triggering re-generation. This is correct for cache invalidation but WRONG for durable references (export, subtitles, highlight persistence, bookmarks).

**Segment anchor** (`NarrationSegmentAnchor`): `{ bookId: string, startIdx: number, endIdx: number }`. This is the content-stable identity — it identifies "words 150-175 of this book" regardless of normalizer version, voice, or provider. It does not change when normalization, caching, or audio generation changes. TTS-EVENT-SYNC-1 introduces this type; TTS-PIPELINE-1 validates it end-to-end.

Evidence: `kokoroStrategy.ts:168` constructs `chunkId` as `` `${bookId}:${startIdx}:${normalization.normalizationHash}` ``. The `normalizationHash` (computed at `segmentNormalizer.ts:367-374`) includes `TTS_NORMALIZER_VERSION`, `locale`, `sourceTextHash`, `normalizedTextHash`, `pronunciationOverrideHash`, and transform IDs. Any normalizer change produces a different hash → different `chunkId` → cache miss → correct behavior for audio caching, incorrect behavior for segment persistence.

**Decision:** Both identity types coexist. `chunkId` remains the cache key. `NarrationSegmentAnchor` is the durable reference. Export/subtitle/bookmark features (KOKORO-EXPORT-1, deferred) consume `NarrationSegmentAnchor`, not `chunkId`.

#### AD-2: Three-Level Timing Hierarchy

Timing information exists at three deliberate levels of abstraction:

1. **Provider capability** — `TtsProviderTimingTruth` (`src/types/ttsProvider.ts:4-8`): `"word-native" | "segment-following" | "unreliable-boundary" | "none"`. This is the provider's inherent timing quality. Set once in the registry. Kokoro = `"word-native"`, Web Speech = `"unreliable-boundary"`, dormant sidecar engines = `"segment-following"`.

2. **Cache identity** — `TtsCacheIdentityV2.timingTruth` (`src/types/ttsCache.ts:23`): Records which timing truth was active when the chunk was generated and cached. Ensures cache reads know what quality of timing data to expect in the sidecar. Same enum as (1).

3. **Per-chunk classification** — `TtsTimingSidecar.timingClassification` (`src/types/ttsCache.ts:47`): `"trusted" | "heuristic"`. Derived binary decision: "given the provider's truth level AND the actual timestamp data for this specific chunk, can the highlight controller use word-level sync?" Computed by `classifyTiming()` — `"trusted"` requires `timingTruth === "word-native"` AND `wordTimestamps` is non-empty AND `wordTimestamps.length === chunkEndIdx - chunkStartIdx`.

These are NOT redundant. Each serves a different consumer: (1) → settings UI / provider selection, (2) → cache integrity / sidecar expectations, (3) → highlight controller sync-mode decisions. TTS-CACHE-HARDEN-1 makes `classifyTiming()` the single derivation point for (3), ensuring no parallel classification logic exists.

#### AD-3: Transform Contract Constraint

`TransformFn = (text: string) => string` (`segmentNormalizer.ts:48`). All transforms must be **word-count-preserving or word-count-expanding** — no N:1 contractions (multiple input words → one output word). This constraint ensures the diff-based `normalizedToOriginalMap` (TTS-EVENT-SYNC-1) can produce correct mappings without per-transform alignment provenance.

Evidence: all 12 current transforms (`segmentNormalizer.ts:348-363`) are 1:1 (same word count) or 1:N (expansion, e.g., "$5" → "five dollars"). NORMALIZER-ENRICH-1 transforms (fractions, decimals, ranges, URLs) are also expansive. If a future transform requires N:1 contraction, the transform contract must be upgraded to a result-object returning alignment info — but this is not anticipated in the current conveyor.

#### AD-4: Provider Evolution Contract

When a dormant engine is reactivated or a new engine is added, it must implement `ProviderCapabilities` (`src/types/ttsProvider.ts:16-35`). The critical fields for TTS architecture integration are:

- `timingTruth`: determines highlight sync mode (word-native → event-driven, segment-following → chunk-synced fallback)
- `cacheable`: determines whether audio is persisted to disk cache with timing sidecars
- `providesWordTimings`: whether the engine returns `wordTimestamps` on generated chunks
- `emitsWordBoundaryEvents` (added by TTS-EVENT-SYNC-1): whether the engine drives word-boundary callbacks

**Fallback behavior when capabilities are absent:**
- No word boundary events → highlight controller falls back to chunk-synced mode (`highlightSyncController.ts:75-83`)
- No word timestamps → timing sidecar records `timingClassification: "heuristic"`, controller uses chunk-synced mode
- Not cacheable → chunks are generated fresh each time, no sidecar, no parity concern

**Language independence of alignment maps:** `normalizedToOriginalMap` maps token positions, not language features. The map is `number[]` where `map[normalizedTokenIndex] = originalWordIndex`. This works for any language whose normalizer produces the same word-count-preserving/expanding transform constraint (AD-3).

### Cross-Sprint Type-Flow Matrix

Shows which types flow between sprints and which sprint produces each type consumed downstream.

```
Sprint 1: ENGINE-DORMANCY-1
  Produces: Updated registry entries (selectable: false, disabledReason, statusKind: "disabled")
  Consumed by: All downstream (test stability, single-engine path)

Sprint 2: TTS-INTEGRATE-1
  Produces: HighlightSyncController + TimingMetadataStore on main
  Consumed by: TTS-CACHE-HARDEN-1 (parity verification), TTS-EVENT-SYNC-1 (event trigger target)

Sprint 3: TTS-CACHE-HARDEN-1
  Produces: ScheduledChunk + {timingTruth?, chunkId?} | classifyTiming() helper | IPC shape guard
  Consumed by: TTS-EVENT-SYNC-1 (trusts cached chunks carry timing), TTS-PIPELINE-1 (parity test)
  Integration gate: cached chunk → scheduler → highlightSyncController produces same decision as fresh chunk

Sprint 4: TTS-EVENT-SYNC-1
  Produces: normalizedToOriginalMap | NarrationSegmentAnchor type | word-boundary event contract | emitsWordBoundaryEvents capability
  Consumed by: NORMALIZER-ENRICH-1 (map must survive new transforms), TTS-RENDER-MAP-1 (anchor for position index), TTS-PIPELINE-1 (end-to-end chain)
  Integration gate: normalizer → alignment map → word-boundary event → highlight controller decision chain

Sprint 5: NORMALIZER-ENRICH-1
  Produces: 8+ new transforms (all word-count-expanding per AD-3) | updated normalizerVersion
  Consumed by: TTS-RENDER-MAP-1 (richer normalized text), TTS-PIPELINE-1 (fixture expansion)
  Constraint: normalizedToOriginalMap.length must still === normalizedTokenCount after new transforms

Sprint 6: TTS-RENDER-MAP-1
  Produces: WordPositionIndex (word → rendered DOM position) | NarrationSegmentAnchor → visual range mapping
  Consumed by: TTS-PIPELINE-1 (position lookup in integration test), TTS-ARCH-DOC-1 (documented)

Sprint 7: TTS-PIPELINE-1
  Produces: End-to-end integration test | NarrationSegment domain type assessment | 15+ golden fixtures
  Consumed by: TTS-ARCH-DOC-1 (test evidence), KOKORO-EXPORT-1 (export-readiness proof)

Sprint 8: TTS-ARCH-DOC-1
  Produces: Architecture decisions document | error taxonomy | findings provenance
  Consumed by: Future audits, onboarding, export planning
```

### Dissolved Sprints

| Sprint | Dissolved | Reason |
|--------|-----------|--------|
| TEST-HARNESS-1 | 2026-05-15 | **Superseded.** The probe failures that motivated this sprint are addressed differently: ENGINE-DORMANCY-1 disables sidecar engines, making Nano probes irrelevant to `npm test`. The eval harness is already stable for the Kokoro-only path. TTS-INTEGRATE-1's integration worktree verified full tests pass (2603/2606) with only pre-existing Nano performance-class failures — evidence that the harness itself is sound. |
| TTS-CANARY-1 | 2026-05-15 | Sidecar readiness probes serve no purpose when MOSS-Nano and Pocket TTS are dormant/disabled; Kokoro readiness is already verified at startup via `KOKORO-DEEPEN-1`. |
| TTS-REGISTRY-DISPATCH-1 | 2026-05-15 | Registry-driven strategy dispatch adds no value with a single active engine; the registry exists (`TTS-REGISTRY-1`) but dispatch routing is unnecessary until a second engine is reactivated. |

> **Dormancy rationale note:** Engine dormancy is a **strategic focus choice**, not a research finding that MOSS-Nano or Pocket TTS are technically invalid. Both engines passed their respective evaluation gates (MOSS-Nano: `NANO_RECOMMENDED_OPT_IN` from 13d; Pocket TTS: functional opt-in from POCKET-TTS-1). Dormancy is motivated by: (a) test instability from MOSS Nano probes blocking TTS-INTEGRATE-1, (b) maintenance surface reduction during Kokoro-focused architecture work, and (c) the product decision to ship one polished engine rather than three partially-maintained ones. Dormancy is **reversible** — reactivation requires only changing registry posture and re-enabling settings selection. No production code is deleted. The research findings support "do not promote sidecar engines to default" and "keep evidence gates"; dormancy extends that to "temporarily disable at settings boundary for focus."

---

#### Sprint ENGINE-DORMANCY-1: Disable MOSS-Nano And Pocket TTS At Settings Boundary

**What:** Disable MOSS-Nano and Pocket TTS at the settings/selection boundary and IPC runtime entry points, following the same pattern already established for Qwen. All TTS energy is redirected to making Kokoro optimal.

**Why:** MOSS-Nano and Pocket TTS are currently live and selectable — their registry entries have `selectable: true` and no `disabledReason`. This sprint is a real product-posture change, not cleanup of already-dormant engines. Disabling them at the settings boundary removes maintenance surface area and test instability (the MOSS Nano probe failures that block TTS-INTEGRATE-1), unblocks the integration merge, and redirects all TTS energy to Kokoro narration quality, timing accuracy, and reliability.

**Prerequisites:** None — can run immediately on `main`.

**Done when:**
1. MOSS-Nano and Pocket TTS registry entries have `selectable: false`, `disabledReason` set to a dormancy explanation, and `statusKind` reflecting unavailable state — matching the Qwen disable pattern.
2. MOSS-Nano and Pocket TTS are unselectable in TTSSettings — same UX pattern as Qwen (greyed out with status text explaining dormancy).
3. IPC runtime entry points for `tts-nano-*` and `tts-pocket-*` return unavailable with `reason: "engine-dormant"` and do not start sidecar runtimes.
4. Existing Nano/Pocket profiles in user settings gracefully migrate to Kokoro on next settings load (same migration pattern as Qwen profiles in POSTV2-ENGINE-1).
5. `tests/mossNanoProbe.test.js` performance thresholds are either skipped when engine is dormant or moved behind an explicit opt-in flag — they must not block default `npm test`.
6. No Nano/Pocket production code is deleted — dormancy is a settings/selection gate, not a code removal. The engines can be reactivated by changing registry posture.
7. `npm test` passes (full suite), `npm run typecheck` passes, `npm run build` passes.

**Effort:** S (~1). Settings boundary + IPC guards + test skip — no architectural changes.

**Roster:** Hermes (registry/settings/IPC guards) • Hippocrates (test verification) • Solon (spec compliance).

**Source:** 2026-05-15 strategic pivot to Kokoro-only focus; POSTV2-ENGINE-1 Qwen-disable pattern as reference implementation.

##### Grounding evidence (current state)
- **MOSS-Nano registry** (`ttsProviderRegistry.ts:95-122`): `selectable: true`, `disabledReason: null`, `statusKind: "sidecar"`, `timingTruth: "segment-following"`. Must change to: `selectable: false`, `disabledReason: "engine-dormant"`, `statusKind: "disabled"`.
- **Pocket TTS registry** (`ttsProviderRegistry.ts:124-151`): `selectable: true`, `disabledReason: null`, `statusKind: "sidecar"`. Same target state.
- **Qwen reference pattern** (`ttsProviderRegistry.ts:66-93`): `selectable: false`, `disabledReason: "retired-desktop-v2"`, `statusKind: "disabled"`. This is the exact pattern to replicate.
- **IPC guard reference:** `main/ipc/tts.js` — Qwen handlers return `{ error: "qwen-disabled" }`. Replicate for `tts-nano-*` and `tts-pocket-*` with `"engine-dormant"`.

##### Implementation detail
- **Edit sites:** `src/utils/ttsProviderRegistry.ts` (update MOSS-Nano and Pocket TTS entries); `src/components/settings/TTSSettings.tsx` (dormancy UX); `main/ipc/tts.js` (IPC guards for nano/pocket handlers); `src/hooks/useNarration.ts` (profile migration on load); `tests/mossNanoProbe.test.js` (skip or opt-in gate).
- **Reference:** POSTV2-ENGINE-1 Qwen-disable pattern — `grep` for `qwen-disabled` across `main/ipc/tts.js`, `src/utils/ttsProviderRegistry.ts`, and `src/hooks/useNarration.ts` to see the exact boundary.
- **Tests:** Existing settings/provider tests updated; no new test file needed — this is a posture change, not new functionality.
- **Branch:** `sprint/engine-dormancy-1-kokoro-only`.
- **Commit hygiene:** explicit-stage; do not delete any Nano/Pocket production code.

-