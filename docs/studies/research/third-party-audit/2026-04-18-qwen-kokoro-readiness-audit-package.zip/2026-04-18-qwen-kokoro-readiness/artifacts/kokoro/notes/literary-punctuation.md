# Engine Scan Review Template

## Run Metadata
- Candidate: kokoro
- Fixture: literary-punctuation
- Host: windows-cpu
- Runtime shape: node worker + kokoro-js + onnxruntime-node
- Audio file: audio/literary-punctuation.wav

## Hard Gates
- Commercial posture: pass
- Local/offline: pass
- Disclaimer/watermark risk: none documented

## Scoring (1-5)
- Punctuation prosody: pending-manual-audition
- Long-sentence cadence: pending-manual-audition
- Dialogue handling: pending-manual-audition
- Long-form continuity: pending-manual-audition
- Seam audibility: pending-manual-audition
- Voice fatigue: pending-manual-audition
- Runtime practicality: 5

## Notes
- What sounded natural: Not scored in this automated dispatch; file captured successfully for later listening review.
- What broke: Nothing at generation time on this host once the standard Blurby model cache was reused.
- Did it beat Kokoro here: Baseline control.
- Duration ms: 27100
- Wall seconds: 11.15
- Usable window chars: 1413
