# Engine Scan Review Template

## Run Metadata
- Candidate: kokoro
- Fixture: continuous-chapter-passage
- Host: windows-cpu
- Runtime shape: node worker + kokoro-js + onnxruntime-node
- Audio file: audio/continuous-chapter-passage.wav

## Hard Gates
- Commercial posture: pass
- Local/offline: pass
- Disclaimer/watermark risk: none documented

## Scoring (1-5)
- Punctuation prosody: pending-manual-audition
- Long-sentence cadence: pending-manual-audition
- Dialogue handling: pending-manual-audition
- Long-form continuity: pending-manual-audition
- Seam audibility: pending-manual-audition
- Voice fatigue: pending-manual-audition
- Runtime practicality: 5

## Notes
- What sounded natural: Not scored in this automated dispatch; file captured successfully for later listening review.
- What broke: Nothing at generation time on this host once the standard Blurby model cache was reused.
- Did it beat Kokoro here: Baseline control.
- Duration ms: 25575
- Wall seconds: 11.14
- Usable window chars: 9503
